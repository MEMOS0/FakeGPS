#define AppName "FakeGPS"
#define AppVersion "0.2.1"
[Setup]
AppId={{FAF652D1-EB9F-4AD9-A426-CB4B110CE00A}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={localappdata}\Programs\FakeGPS
DefaultGroupName=FakeGPS
OutputDir=..\release
OutputBaseFilename=FakeGPS-Setup-0.2.1-windows-x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\FakeGPS.exe
CloseApplications=yes
LicenseFile=..\LICENSE
[Files]
Source: "..\dist\FakeGPS\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{group}\FakeGPS"; Filename: "{app}\FakeGPS.exe"
Name: "{userdesktop}\FakeGPS"; Filename: "{app}\FakeGPS.exe"; Tasks: desktopicon
[Tasks]
Name: desktopicon; Description: "Create a desktop shortcut"; Flags: unchecked
[Run]
Filename: "{app}\FakeGPS.exe"; Description: "Open FakeGPS"; Flags: nowait postinstall skipifsilent
; No Apple drivers, DDI images, pairing records, or signing certificates are redistributed.
; App-owned favorites and logs are preserved on uninstall.
