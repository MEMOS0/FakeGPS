# Run on the target OS. PyInstaller is not a Windows/macOS cross-compiler.
import os
import sys
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_dynamic_libs, collect_submodules, copy_metadata

root = Path(SPECPATH).parent
portable = os.environ.get("FAKEGPS_PORTABLE") == "1"
datas = collect_data_files("fakegps") + copy_metadata("pymobiledevice3", recursive=True)
binaries = []
# tunnel_service imports pytun_pmd3 even for userspace tunnels. Its Windows
# module loads Wintun dynamically by package-relative path at import time.
if sys.platform == "win32":
    binaries += collect_dynamic_libs("pytun_pmd3")
    datas += collect_data_files("pytun_pmd3", includes=["wintun/LICENSE.txt"])
notices = root / "packaging" / "notices"
if notices.exists():
    datas.append((str(notices), "notices"))
hidden = [
    "pymobiledevice3.remote.native_tunnel", "pymobiledevice3.remote.userspace_tunnel",
    "pymobiledevice3.remote.rsd_tunnel", "pymobiledevice3.osu.os_utils",
    "pymobiledevice3.remote.core_device.core_device_service",
    "pymobiledevice3.remote.core_device.location_service",
    "pymobiledevice3.services.mobile_image_mounter",
]
# These packages resolve platform/protocol modules lazily. Include their modules/data.
for package in ("pytcp", "pmd_net_proto", "pmd_net_addr", "zeroconf", "developer_disk_image",
                "pymobiledevice3.remote.core_device"):
    hidden += collect_submodules(package, on_error="warn once")
    datas += collect_data_files(package)
a = Analysis([str(root / "packaging" / "entrypoint.py")], pathex=[str(root / "app")],
             binaries=binaries, datas=datas, hiddenimports=hidden,
             excludes=["PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets", "IPython", "xonsh", "pytest"],
             noarchive=False)
pyz = PYZ(a.pure)
if portable:
    exe = EXE(pyz, a.scripts, a.binaries, a.datas, [], name="FakeGPS", debug=False,
              strip=False, upx=False, console=False, disable_windowed_traceback=False)
else:
    exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name="FakeGPS", debug=False,
              strip=False, upx=False, console=False, disable_windowed_traceback=False)
    collection = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="FakeGPS")
    if sys.platform == "darwin":
        app = BUNDLE(collection, name="FakeGPS.app", bundle_identifier="local.fakegps.desktop",
                     info_plist={"CFBundleName": "FakeGPS", "CFBundleShortVersionString": "0.1.0",
                                 "NSHighResolutionCapable": True,
                                 "NSLocalNetworkUsageDescription": "Find and connect to your paired iPhone for developer location simulation."})
