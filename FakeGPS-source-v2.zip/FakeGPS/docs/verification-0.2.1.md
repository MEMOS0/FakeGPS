# FakeGPS 0.2.1 Walk/Drive verification

Date: 2026-09-06

## What was executed in this environment

- Controller + movement regression suite: 30 passed.
- Python compileall across app/tests/scripts/packaging: passed.
- Coordinate/routing stress: 20,000 random coordinate pairs; all generated distances and interpolated coordinates remained finite and in range.
- Concurrency stress: 50 separate routes × 10 rapid pause/resume cycles; no deadlock, and each route kept a single connect/release lifecycle.
- Repeated CoreDevice payload boundary: 50 sequential LocationService invoke calls against one mocked open service; payload/action identifiers stayed correct.
- Stop during a 2-second scheduler tick wakes immediately instead of waiting for the tick timeout.
- Pause during a 2-second scheduler tick wakes immediately; paused time does not advance route distance.
- Pause/Stop arriving while set_location I/O is still in flight are preserved and acted on after the invoke returns.
- Route failure after successful location updates releases the transport and preserves the last successfully sent point as uncertain active state.
- Dateline interpolation test verifies 179.9°E -> 179.9°W crosses near ±180°, not through 0°.
- Provider-snapped road geometry is wrapped with the exact user-selected start and destination so a route does not begin/end with an unexplained snap teleport.
- Duplicate road-geometry points are removed and malformed/negative route duration is ignored.
- Offline/provider failure path returns an explicit straight-line fallback.
- Unsafe routing provider URLs (HTTP, file://, credential-bearing HTTPS) are rejected.

## Added CI GUI checks

The source now also contains Qt tests for:

- Walk UI start -> active -> pause -> resume -> stop.
- Drive mode button text and speed range.
- Route lookup locks map/search inputs until the route is ready.

The current container does not have PySide6 or pymobiledevice3 installed and outbound pip access is disabled, so those Qt/adapter tests could not be re-executed locally here. `scripts/project.py release` runs the complete pytest suite before packaging, therefore the native Windows/macOS GitHub Actions build will fail before producing installers if these GUI/adapter tests fail.

## Physical-device boundary

A single CoreDevice `setsimulatedlocation` action is already physically verified on iPhone 14 / iOS 18.7.8 / Windows USB in the project history. This verification pass did not have access to that iPhone, so repeated Walk/Drive updates over one live LocationService session are protocol-tested and state-machine-tested, but still require a final physical acceptance run on the phone.

Recommended physical acceptance:

1. Teleport and confirm Apple Maps moves.
2. Walk a 100-300 m real pedestrian route at 5 km/h for at least 60 seconds.
3. Pause for 15 seconds and confirm the dot remains stationary.
4. Resume and confirm it continues from the same point without jumping.
5. Stop mid-route and confirm the last simulated point remains.
6. Drive a 1-3 km road route at 30, 50 and 80 km/h.
7. Disconnect USB during/after static simulation only; movement itself intentionally needs the CoreDevice session open.
8. Return to real location and confirm Apple Maps reacquires GPS.
