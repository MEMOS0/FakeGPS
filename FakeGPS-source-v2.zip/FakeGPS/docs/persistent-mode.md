# CoreDevice disconnect-safe location mode

## Verified result

This project has one physical verification, performed on **iPhone 14 / iOS
18.7.8 / Windows / USB** with Developer Mode enabled and a Personalized DDI
mounted. FakeGPS opens a temporary pymobiledevice3 userspace tunnel and sends:

```text
service: com.apple.coredevice.locationservice
feature: com.apple.coredevice.feature.simulatelocation
action:  com.apple.coredevice.action.setsimulatedlocation
input:   { latitude: <float>, longitude: <float> }
```

The action returned `{}` and Apple Maps immediately moved. The Python process
ended, the userspace tunnel closed, USB was disconnected, Wi-Fi was disabled,
Apple Maps was force-closed/reopened over 5G, and Windows was shut down. The
selected location remained active.

This is an observed result, not an Apple persistence contract. It is recorded
as `verified_iPhone14_windows_usb` only for 18.7.8 in `compatibility.json`.

## Product flow

1. Pair/trust the selected device locally through lockdown.
2. Require Developer Mode to be on; FakeGPS never turns it off.
3. Check the `Personalized` image and call upstream `auto_mount()` if needed.
4. Open `UserspaceRsdTunnel` and require the advertised CoreDevice service and
   simulated-location feature.
5. Invoke `setsimulatedlocation` and require a non-null CoreDevice output.
6. Close LocationService, RSD and tunnel. Closing FakeGPS never sends clear.

The old DVT long-lived set session and its Developer Mode OFF handoff UI are no
longer used for setting a location.

## Reboot and reset

Not yet verified: iPhone reboot, turning Developer Mode off, other iPhone
models, other iOS versions and a CoreDevice clear operation.

`RETURN TO REAL LOCATION` temporarily opens the known DVT
`stopLocationSimulation` path as a reset fallback. It is deliberately isolated
from the CoreDevice set flow. It is not represented as a verified CoreDevice
clear action and its response does not prove a fresh real GPS fix. If it fails,
restart the iPhone and check Apple Maps.

## Why a CoreDevice clear action is not shipped yet

The currently bundled pymobiledevice3 `LocationService` exposes scenario
enumeration but does not expose a clear method. No current public source
verified in this change provided the exact Xcode/devicectl action identifier
and payload for `devicectl device simulate location clear`. FakeGPS therefore
does not invent an action identifier or silently send a guessed request.

## Hardware regression checklist

For every additional model/iOS build, record device model, iOS build, DDI
build, transport, action output and each of these checks:

1. Set visibly distant location and check the Apple Maps blue dot.
2. Wait for FakeGPS to close its tunnel, then unplug USB.
3. Disable Wi-Fi and test over cellular.
4. Force-close/reopen Maps.
5. Shut down Windows and check after five minutes.
6. Test explicit reset, then a separate iPhone reboot test.

Only an exact version/model repetition should be promoted from probe-supported
to verified in the compatibility database.
