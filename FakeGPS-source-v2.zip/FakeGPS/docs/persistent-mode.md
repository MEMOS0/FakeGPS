# Persistent Mode — sonuç, deney ve açık sorular

5 Eylül 2026 itibarıyla bu projede **hiçbir iOS sürümü için fiziksel persistence doğrulanmadı**. Code path'in mevcut olması, kullanıcı toggle bildirimi veya DVT set çağrısının dönmesi; kablo çıkarıldıktan, bilgisayar kapandıktan ve 5G'ye geçildikten sonra konumun kaldığını kanıtlamaz.

## 1. Normal DVT neden bağlantı sonrası temizlenebilir?

Kaynakta bir DTX instrument session'ı açılıyor ve set sonrası oturum açık tutuluyor. Özel bir “persist forever” parametresi bulunmuyor. `LocationSimulation` sınıfında iki temel işlem set ve clear; firmware'in session disconnect sırasında uyguladığı cleanup ayrı bir cihaz davranışı. Host'tan açık clear gönderilebilir; host clear göndermese bile iOS session sonunu farklı ele alabilir.

Oturumun sona ermesinin location override lifetime'ını etkilemesi **çıkarım**; kernel veya locationd iç durumu bu ortamda incelenmedi. “Tam olarak şu flag tutuluyor/temizleniyor” iddiası yok. Kaynak: [DVT CLI lifecycle](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/cli/developer/dvt/simulate_location.py), [location instrument](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/services/dvt/instruments/location_simulation.py), [GeoPort reset issue](https://github.com/davesc63/GeoPort/issues/134).

## 2. Developer Mode OFF workaround ne yapıyor?

Topluluk anlatımı: Developer Mode ON → simulated coordinate set → mevcut mavi noktayı doğrula → hâlâ bağlıyken Developer Mode switch OFF → reboot yapmadan ayır. Öne sürülen sonuç, location override'ın bağlantı sonrasındaki cleanup'tan sağ çıkmasıdır.

**Mekanizma doğrulanmış değil.** Bunun kalıcı disk kaydı yazdığı, locationd'yi dondurduğu veya resmî persistence özelliğini aktive ettiği söylenemez. Apple belgesi kapatma için restart içeriyor; yeniden başlatılmadan ekrandaki switch'in görüntüsü ile etkin runtime state aynı olmak zorunda değil. Telefon reboot gerektiriyorsa bu deneyde başarı varsayılmaz.

Kaynaklar: [Apple Developer Mode](https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device) — OFFICIAL; [GeoPort yorum #2808513895](https://github.com/davesc63/GeoPort/issues/134#issuecomment-2808513895) — COMMUNITY REPORT; [location-changer README](https://github.com/matt-ceran/location-changer/blob/51998fa1a9324761621313951d29a83c2fe7f9e6/README.md) — exact-version sonucu UNVERIFIED.

## 3. Reboot neden state'i temizliyor?

Session'a bağlı volatile developer override'ın restart'ta kaybolması makul açıklamadır; burada **çıkarım** olarak tutulur. Upstream proje anlatımlarında reboot reset yolu olarak bildirilir. Apple'ın her patch için bu özel workaround'ı kapsayan “reboot kesin şu simulated state'i temizler” kontratı bulunmadı. Test E'nin beklenen sonucu gerçek konuma dönüş; test sonucu yerine beklenen sonuç yazılmaz.

Restart sonrası ilk konum fix'i gecikebilir veya Maps cache'i eski noktayı gösterebilir. Mavi noktanın yenilenmesi ve mümkünse timestamp/sourceInformation gösteren kendi küçük test uygulamasıyla kontrol gerekir. Bir adres pini veya arama sonucu asla GPS doğrulaması sayılmaz.

## 4. Hangi sürümlerde doğrulandı, hangilerinde sorun var?

| iOS | Normal-mode dış kanıt | Disconnect / persistence kanıtı | FakeGPS statüsü |
| --- | --- | --- | --- |
| 17.0–17.3.1 | DVT yolu var; no-root transport sınırlı, upstream CLI privileged fallback kullanıyor. | Exact-patch ölçüm yok. | Transport kısıtlı, hardware unverified. |
| 17.6.1 | LocWarp normal çalışma bildirimi. | Offline 24 saat persistence kanıtı yok. | Unverified. |
| 18.1.1 / 18.3.1 / 18.6.2 / 18.7.1 / 18.7.7 / 18.7.8 | LocWarp topluluk/geliştirici normal sonuç listesi. | iOS 18 reset issue; toggle-off birkaç saat iddiasının exact patch'i yok. | Persistent unverified. |
| 18.7.9 / 18.7.10 | Apple sürüm notlarında var. | Bu incelemede exact-patch location testi bulunmadı. | Normal ve persistent hardware unverified. |
| 26.2 / 26.3.1 / 26.4 / 26.4.2 | LocWarp normal çalışma raporları. | Kalıcılık süre ölçümü yok. | Persistent unverified. |
| 26.4.1 | LocWarp olumlu normal rapor; GeoPort #188 olumsuz örnek. | Çelişki çözülmüş değil. | Normal de koşullara bağlı; persistent unverified. |
| 26.5 | LocWarp geliştirici günlük test ortamı. | Bilgisayar kapalı 24 saat ölçüm yok. | Persistent unverified. |
| 26.6 / 26.6.1 | Apple sürüm notlarında var. | Bu incelemede exact-patch location testi bulunmadı. | Normal ve persistent hardware unverified. |

Kaynak listesi ve seviyeleri `ios-research.md` içindedir. Aynı iOS numarasıyla başka uygulamanın çalışması FakeGPS test sonucu değildir. `app/fakegps/data/compatibility.json` bu ayrımı korur. İleride `tested` kaydı eklemek için telefon modeli, iOS build, Windows/macOS build, pymobiledevice3 sürümü, DDI build'i ve A–F sonuç dosyası birlikte tutulmalıdır.

## 5. Developer Mode toggle otomatikleştirilebilir mi?

İncelenen `AmfiService` reveal/enable/accept sunuyor; desteklenen bir OFF yöntemi bulunmuyor. Enable, cihaz restart'ına ve sonraki onaya uzanabilir; passcode set ise `DeviceHasPasscodeSetError` üretebilir. Bu uygulama passcode kaldırmaz/istemaz, enable-post-restart onayını taklit etmez; yalnızca menüyü görünür yapmayı ve kullanıcı yönergelerini sunar.

`devmodectl` ile lab otomasyonu Apple'ın anlattığı bir özellik olsa da herhangi bir iPhone'un Developer Mode'unu kapatıp konumu donduran genel bir public API olarak ele alınamaz. Kaynak: [AMFI kaynak](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/services/amfi.py), [WWDC22](https://developer.apple.com/videos/play/wwdc2022/110344/).

## 6. Developer Mode OFF iken DVT stop çağrısı?

Stop aynı developer service erişimine ihtiyaç duyar. Etkin Developer Mode kapalıysa yeni DVT bağlantısı kurulmasına güvenilemez. Önceden kurulmuş session'ın switch değişimi ile ne zaman sonlandığı da sürüme göre test edilmelidir. UI bu durumda “reset başarılı” demez. Telefonu bağlamak tek başına kapalı developer service'i açmaz.

MVP reset'i yeniden bağlanıp normal DVT clear yolunu dener. Başarısızsa manuel restart yönergesi gösterir. Developer Mode tekrar açılırken gereken reboot zaten mevcut override'ı sonlandırabilir; bunu ayrı bir “rebootsuz reset” saymıyoruz.

## 7. Reboot olmadan başka documented reset servisi var mı?

İncelenen kapsamda, **modern iOS'ta Developer Mode kapalıyken bu state'i güvenilir şekilde temizleyen belgelenmiş alternatif bulunmadı**. Bu bir evrensel yokluk ispatı değildir.

Eski [`com.apple.dt.simulatelocation`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/services/simulate_location.py) yolu clear opcode'u içeriyor ancak bu da `start_lockdown_developer_service` kullanıyor; iOS 17+ için CLI ayrı DVT yolunu öneriyor. Bunu Developer Mode engelini aşan reset diye sunmak yanlış olur. [`DiagnosticsService.restart()`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/services/diagnostics.py) yeniden başlatma işlemidir, rebootsuz çözüm değildir. MVP bilinçli olarak telefonda kullanıcı tarafından restart önerir; tek tuşla habersiz reboot gerçekleştirmez.

Uçak modu, Location Services toggle veya Maps'i kapatıp açmak bu incelemede garantili clear yöntemi olarak doğrulanmadı. Test D'de değişken olarak ölçülür. location daemon öldürme, exploit veya güvenlik mekanizması atlatma denenmedi.

## 8. UI'nın kanıt kuralları

Set başarıyla döndüğünde kullanıcı Maps'teki mavi noktayı doğrular. Ardından switch/reboot durumunu bildirir. Readback OFF ise “OFF bildiriliyor”; readback yapılamıyorsa “okunamadı”; ON ise sihirbaz devamı durdurulur ve switch'in runtime'a henüz uygulanmamış olabileceği söylenir. Hiçbiri “persistent tested” anlamına gelmez.

Handoff tamamlanınca host kaynakları kapatılır ve açık clear gönderilmez. Oturum kapanırken iOS resetlerse deney başarısızdır. Telefonu dışarı götürmek veya desktop'u kapatmak için teknik bir yasak konmuyor; uygulama bunun ardından durum gözlemleyemediğini açıkça yazar. Normal kapanış ve experimental handoff kapanışı ayrı testlerle korunur.

## 9. Ölçüm standardı

Her trial'dan önce real-location baseline ve reboot sonrası baseline alın. Normal session'ın açık kaldığı A testi kontrol grubudur. B testinde sadece kabloyu çıkar; C'de aynı cihaz/sürümle toggle yöntemi uygula. C'de host tamamen kapatılmalı: sadece USB çıkarmak, aynı Wi-Fi'dan hâlâ bağlı kalmadığını kanıtlamaz. Beş dakika, bir saat, altı, on iki ve yirmi dört saatte yeni mavi nokta okumasını kaydet.

Bir kez başarılı sonuç, aynı exact build için bile garantili ürün desteği değildir. En az üç bağımsız trial, kontrollü arka plan koşulları ve reboot reset sonucu olmadan `tested` etiketi ekleme. Gözlemlenemeyen zaman aralığı “passed” olarak doldurulmaz. Kontrol listesi `test-plan.md`, boş kayıt tablosu `manual-results.csv` içindedir.
