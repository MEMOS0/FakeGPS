# Mimari ve tasarım kararları

## İş parçacığı sınırı

Qt widgets, map painter, Qt network tile manager ve Store GUI thread'ine aittir. `Runner` bir asyncio event loop'u ayrı thread'de yaşatır. DeviceBackend, Controller ve Geocoder işleri bu loop'a `run_coroutine_threadsafe` ile gönderilir. Sonuçlar Qt signal ile GUI'ye taşınır; worker widget değiştirmez.

Controller'daki lock set/reset/shutdown işlemlerini sıraya koyar. Qt “busy” durumu ikinci kullanıcı mutasyonunu önler. Discovery salt okunurdur ve aktif bir mutasyon sırasında periyodik başlatılmaz. Ağ araması ile map indirmesi device oturumunu kapatmaz. Eksik Personalized DDI, pymobiledevice3'ün in-process `auto_mount()` yöntemi ile otomatik hazırlanır.

```mermaid
flowchart TD
    UI["Native Qt pencere"] --> Worker["Asyncio worker"]
    UI --> Map["Qt harita ve HTTPS tiles"]
    Worker --> Controller["Controller state machine"]
    Worker --> Search["Photon arama"]
    Controller --> Backend["Backend protokolü"]
    Backend --> Real["pymobiledevice3 adapter"]
    Backend --> Mock["Açık demo backend"]
    Real --> Phone["Pairing izni verilmiş iPhone"]
```

## Kaynak sahipliği

`DeviceBackend.stack`, lockdown → userspace tunnel/RSD → CoreDevice `LocationService` kaynaklarını tutar. `AsyncExitStack` ters sırada kapatır. Kurulum yarıda kalırsa edinilmiş kaynaklar temizlenir. Başarılı setin ardından Controller açıkça `release()` çağırır; bu iPhone 14 / iOS 18.7.8 testindeki geçici tunnel yaşam döngüsüdür.

`release()` yalnızca host kaynaklarını kapatır. **Clear çağrısı içermez.** Uygulama kapanışı da clear göndermez. Reset, doğrulanmış bir CoreDevice clear action bulunana kadar ayrı kısa ömürlü DVT fallback'i kullanır.

## Durumların anlamı

| State | Kanıt / izin verilen davranış |
| --- | --- |
| `IDLE` | Seçilmiş/aktif simülasyon yok. |
| `PREPARING` | Pairing/tunnel veya set isteği sürüyor; başarı henüz bilinmiyor. |
| `ACTIVE` | Set API çağrısı başarıyla döndü; Maps readback kullanıcıya ait. |
| `PERSISTENCE_SETUP` | Aktif set sonrası fiziksel adımlar bekleniyor. |
| `PERSISTENCE_UNVERIFIED` | Kullanıcı fiziksel adımları bildirdi; kalıcılık ölçülmedi. |
| `DISCONNECTED` | Aktif normal oturuma erişim kayboldu; konum bilinmiyor. |
| `RESET_SENT` | Stop isteği gönderildi; selector reply/gerçek GPS readback garantisi yok. |
| `ERROR` | Yapılamayan işlem; önceki simülasyon hâlâ var olabilir. |

```mermaid
stateDiagram-v2
    [*] --> Idle
    Idle --> Preparing: Set
    Preparing --> Active: API döndü
    Preparing --> Error: Hata
    Active --> Setup: Persistent seçildi
    Setup --> Unverified: Fiziksel adımlar bildirildi
    Active --> Disconnected: Transport kaybı
    Active --> ResetSent: Stop gönderildi
    Unverified --> ResetSent: Yeniden bağlan ve stop
    Disconnected --> ResetSent: Yeniden bağlan ve stop
    Unverified --> Error: Reset başarısız
    Error --> Preparing: Tekrar dene
```

## Gerçek transport seçimi

iOS 17.4+ için CoreDeviceProxy üzerinden userspace yolunu tercih eden upstream abstraction kullanılır. macOS native yolu `PreferredRsdTunnel` tarafından seçilir. CLI'nin iOS 17.0–17.3.1 için yaptığı privileged tunneld fallback'i bu uygulamada yoktur; bu aralık ancak upstream no-root RemotePairing koşulları sağlanırsa çalışabilir. Windows kernel TUN driver kurucusu geliştirilmedi.

Wi-Fi desteğinin kapsamı: usbmux listesinde `Network` olarak zaten görülebilen paired cihazlar seçilebilir. Uygulama yeni RemotePairing kaydını sıfırdan Wi-Fi üzerinden kuran bir onboarding sihirbazı içermez. Wi-Fi ile bilgisayara bağlı normal session ve bilgisayar tamamen kapalı persistence farklıdır. Sonraki sürümde bağımsız RemotePairing keşfi eklenebilir; ilk MVP'nin başarı ölçümü USB'dir.

## Güvenlik sınırı

Uygulamaya ait HTTP/WebSocket kontrol endpoint'i, JS bridge veya dışarıdan gelen URL ile location komutu yoktur. Qt ekranı sadece Python Controller'a çağrı yapar. Web sayfasındaki bir JS koduna helper token dağıtılmaz; browser yoktur.

Upstream userspace tunnel'ın **iç relay** ayrıntısı farklıdır: Unix socket olan platformlarda özel geçici dizin; Windows'ta `127.0.0.1` üzerinde kısa ömürlü ham TCP relay vardır. Bu bir JSON/HTTP konum kontrol API'si değildir ve `0.0.0.0` üzerinde açılmaz. Upstream relay uygulama seviyesinde authentication eklemiyor; kötü niyetli başka yerel süreçlere karşı ayrı bir sandbox sınırı değildir. Buna “hiç socket yok” veya “authenticated helper” demiyoruz. Public yayın öncesi yerel saldırgan threat model'i için upstream relay'e auth/OS ACL geliştirmesi değerlendirilebilir. Remote tunneld HTTP API'si başlatılmaz veya LAN'a açılmaz.

App tek-instance `QLockFile` kullanır. Bunun amacı kaynak çakışmasını azaltmaktır, güvenlik sınırı oluşturmak değildir. Pairing sırları, UDID ve koordinatlar rutin developer loglarına yazılmaz; recovery için UDID ve seçilmiş nokta kullanıcıya özel settings dosyasında saklanır. Bu dosya şifreli değildir.

## Ağ ve hata sınırları

Keşif beş saniye, device info dört saniye, pairing bağlantısı sekiz saniye, tunnel otuz beş saniye, DVT on beş saniye, set/stop on saniye limitlidir. DDI indirmesinde request/connect timeout ve dosya boyutu/toplam süre sınırı vardır. Qt tile istekleri 10 saniye timeout ve dört eşzamanlı istek kullanır. Aramada iki MB cevap sınırı, altı sonuç sınırı, sıra kilidi ve cache vardır.

Uygulama yeniden açıldığında journal doğrulanmış aktif session'a dönüştürülmez. Kullanıcı kaydı, sadece geçmiş denemeyi gösterir. Eski cihazın UDID'si ile yeni bağlı cihaz eşleşmeden recovery reset'i gönderilmez. Normal oturum sürerken başka telefona geçiş engellenir.

## Neden CLI subprocess yok?

Pinlenen API ile tüm kritik işler async olarak çağrılabilir. CLI output parsing, global process öldürme, ekstra console pencereleri ve dağıtım içindeki Python executable yolunu seçme gereği kaldırıldı. PyInstaller'ın onefile bootloader'ı kendi extraction child sürecini kullanabilir; “Task Manager'da hiçbir süreç görünmeyecek” diye bir vaadimiz yok. GUI windowed çalışır; terminal penceresi açılmaz.

## Paketleme ve genişleme

Windows onedir+Inno Setup tercih edilir. macOS app/DMG native host üzerinde hazırlanır. PyInstaller spec network/protocol lazy importlarını ve compatibility data'sını toplar. Uygulama launcher'ı `packaging/entrypoint.py` içinden absolute import kullanır; paketin `__main__.py` dosyasını doğrudan çalıştırıp relative import hatası üretmez.

Gelecek GPX scheduler aynı Controller lock'u üzerinden bir time source ve cancellable producer ile tasarlanabilir. Kullanıcı reset'i route task'ını durdurmadan set çağrılarına devam etmemelidir. Çoklu cihaz desteği, upstream userspace tunnel'ın süreç başına tek-tunnel kısıtı nedeniyle sadece Controller'a liste eklemek değildir; ayrı süreç veya desteklenen native tunnel modeli gerekir.
