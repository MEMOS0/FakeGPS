# Windows ve macOS artifact üretimi

Bu teslimatta native Windows/macOS binary bulunmaz. Mevcut Linux host bu platformları
çalıştıramaz ve PyInstaller cross-compiler değildir. Aşağıdaki otomasyon hazırlanmıştır.

## GitHub Actions

1. Kaynak repository'yi kendi GitHub repository'nize aktarın.
2. Actions → Native builds and tests → Run workflow çalıştırın.
3. Windows ve macOS işlerinin başarıyla tamamlanmasını bekleyin.
4. `FakeGPS-windows-2022` ve `FakeGPS-macos-14` artifact'lerini indirin.

Workflow Python/runtime paketlerini yalnızca build makinesine kurar. Windows işi
Inno Setup installer, taşınabilir klasör ZIP'i ve tek portable EXE üretir. macOS işi
.app içeren DMG üretir. GUI ve gerçek backend import smoke kontrolleri çalıştırılır.
Bu workflow bu oturumda uzak sunucuda çalıştırılmadı; ilk native çalıştırma platforma
özgü bağımlılık sorunları ortaya çıkarabilir.

## Yerel build makinesi

Windows: Python 3.12 x64 ve Inno Setup 6 ile `python scripts/project.py release`.
Tek dosya için `python scripts/project.py portable`.
macOS: Python 3.12 ile `python scripts/project.py release`.
Son kullanıcının bu komutları çalıştırması gerekmez.

Windows paketinde pymobiledevice3'ün import ettiği `pytun_pmd3` için Wintun DLL ve
onun redistribution lisansı bulunur. Apple Mobile Device sürücüsü/Apple Devices
paketi dağıtılmaz; gerekiyorsa uygulama resmi Apple sayfasını açar. Userspace
tunnel yolu seçilir; uygulama kernel network adapter kurulumu başlatmaz.

Çıktılar unsigned'dır. Üretim yayınından önce code signing/notarization, GPL
corresponding-source yükümlülükleri, Qt lisans bildirimleri ve temiz makine testleri
tamamlanmalıdır. `packaging/notices` actual build ortamından yeniden oluşturulur.
