# Donanım kabul testi — A–F kontrol listesi

Bu dosya test planıdır. **iPhone 14 / iOS 18.7.8 / Windows USB CoreDevice set akışı fiziksel olarak doğrulandı.** Kayıt şablonu `manual-results.csv`; boş alanlar başarı anlamına gelmez. Sonraki ölçümler exact patch/build ile ayrı kaydedilmelidir.

## Her trial için kaydet

- Trial kimliği, tarih/saat, test eden kişi; UDID veya pairing sırlarını paylaşma.
- Telefon modeli, iOS sürümü **ve build numarası**.
- Windows/macOS sürümü ve build, host CPU mimarisi.
- FakeGPS sürümü/commit, pymobiledevice3 sürümü, DDI build'i.
- Apple Devices/iTunes sürümü, driver durumu, USB kablo tipi, Network/USB transport.
- Developer Mode switch görünümü ve etkin status sorgusu sonucunu ayrı kaydet.
- Wi-Fi/5G, Low Power Mode, ekran kilidi, reboot olayları ve host'un güç durumu.
- İstenen koordinat, **gözlenen mevcut mavi nokta**, mümkünse timestamp/accuracy/sourceInformation.
- Pass / Fail / Not run / Inconclusive; hata başlığı ve redakte edilmiş app logu.

Apple Maps'te Milano arama pininin görünmesi test başarısı değildir. Locate-me düğmesiyle mevcut konum mavi noktasını kontrol et. Bir test uygulaması varsa Core Location timestamp, horizontalAccuracy ve isSimulatedBySoftware alanını gözle; gizleme veya değiştirme yapma. Cache'lenmiş eski fix ile yeni ölçümü ayır.

## Ön hazırlık

1. Gerçek konumu dış mekânda veya GPS alabilen yerde doğrula.
2. Telefonu yeniden başlat, kilidi aç ve Maps konumunu tekrar kontrol et.
3. Apple Devices/Finder cihazı görüyor mu kontrol et.
4. FakeGPS'i standart kullanıcı olarak aç. Terminal penceresi çıkmamalı.
5. Cihazı bağla, Trust isteğini telefonda yanıtla.
6. Developer Mode kapalıysa uygulamanın yönergesini ve reveal düğmesini dene.
7. Developer Mode'u telefon üzerinden aç/restart/onayla; passcode kaldırma gerekmeden devam edebilmeli.
8. DDI eksikse GUI hazırlama düğmesi veya yerel Xcode klasörüyle tamamla.
9. Source/demo ve frozen/real modları karıştırma. DEMO başlıklı ekran fiziksel test kanıtı olarak kullanılamaz.

## TEST A — Normal location ve reset

1. Telefon gerçek İstanbul konumundayken USB ile bağla.
2. Aramada “Duomo di Milano” bul veya preset Milan seç: 45.4642, 9.1900.
3. SET LOCATION'a bas. Başarılı CoreDevice `setsimulatedlocation` çağrısı sonrası aktif durum görünmeli.
4. Apple Maps'te mevcut mavi noktayı kontrol et; zaman ve koordinatı kaydet.
5. Uygulamayı/USB'yi açık tutarak 1 ve 5 dakika sonra yeniden kontrol et.
6. RETURN TO REAL LOCATION'a bas.
7. Stop request sent mesajı görünmeli. Gerçek İstanbul fix'inin geri geldiğini telefonda doğrula.
8. En az üç tekrar yap; bağlantı ve DDI her seferinde sıfırdan gerekmemeli.

Pass: gerçek cihaz Milano'yu gösterdi, clear sonrası yeni gerçek GPS fix'i geldi. Yalnızca app mesajı veya log pass değildir.

## TEST B — Sadece disconnect kontrol grubu

1. Taze gerçek baseline'dan Milano set et, Maps'te doğrula.
2. Developer Mode ON kalsın.
3. USB kablosunu çıkar. Telefonun Wi-Fi bağlantısını ve bilgisayarın açık olduğunu kaydet.
4. 0, 1, 5, 15 dakika sonra mavi noktayı kontrol et.
5. Sonra bilgisayar Wi-Fi'ını kapat; yeniden ölç. USB'yi çıkarmak Wi-Fi session'ın bittiğini tek başına kanıtlamaz.
6. FakeGPS “Device Disconnected / unknown” göstermeli; gerçek konum geri geldi diye otomatik iddia etmemeli.
7. Reconnect + reset'i ve alternatif manuel restart'ı ayrı trial'larda dene.

Sonuç bir destek vaadi değildir; normal session cleanup'ın kontrol ölçümüdür.

## TEST C — CoreDevice disconnect-safe regression

1. Taze reboot ve gerçek konum baseline'ı al.
2. Developer Mode ON, USB bağlı, host ve telefon çevrimiçi olsun.
3. Milano set et; mevcut mavi noktayı doğrula.
4. FakeGPS'in set sonrası tunnel'ı kapattığını ve `Location active — you may disconnect` mesajını gösterdiğini kaydet.
5. Developer Mode **ON kalsın**; kapatma/reboot bu testin parçası değildir.
6. USB'yi çıkar.
9. Bilgisayar Wi-Fi'ını kapat, sonra bilgisayarı tamamen shutdown et.
10. Telefonun Wi-Fi'ını kapat ve LTE/5G üzerinde mavi noktayı ölç.
11. **5 dakika, 1 saat, 6 saat, 12 saat, 24 saat** checkpoint'lerini kaydet.
12. Her checkpoint'te gerçek yeni location fix'i alındığından emin ol; zamanı belirsiz görüntüyü inconclusive işaretle.
13. Reboot ile kurtarma testine geç.

Bir checkpoint'te real location'a dönülürse dönüş zamanı aralığını kaydet. Uygulamanın handoff mesajı başarı kanıtı sayılmaz. 24 saat geçmeyen trial için 24h sütununu boş/not run tut.

## TEST D — Mobility ve radyo değişiklikleri

Her değişkeni mümkünse ayrı trial'da ölç; tek trial'da hepsini yapmak nedeni belirsiz bırakır.

| Değişken | Ölçüm |
| --- | --- |
| Telefon Wi-Fi OFF → LTE/5G | Önce/sonra yeni konum fix'i, doğruluk ve zaman. |
| Başka Wi-Fi'a katıl | Host ağına dönmeden ölç. |
| Ekran kilitle / 10 dakika bekle / aç | Uyku sonrası yeni fix ile kıyasla. |
| Fiziksel hareket | Güvenli yürüyüş, cihazı gerçek konumda en az 200 m taşı; navigasyon için simülasyona güvenme. |
| Uçak modu aç/kapat | Bağlantı geri geldikten sonra yeni fix'i ölç. |
| Low Power Mode | Aynı başlangıç koşullarıyla ayrı trial. |
| Uygulama kapat/aç (Maps) | Cache ile yeni Core Location sonucunu ayır. |

## TEST E — Reboot reset

1. Persistence sonucu mevcutken telefonun seçili simulated konumunu kaydet.
2. Telefonu kullanıcı olarak restart et.
3. Kilidi aç, GPS fix'i alabilen ortamda Maps'i aç.
4. Beklenen: gerçek konuma dönüş. Sonucun geliş süresini kaydet.
5. Geri dönmez veya yeni fix alınamazsa fail/inconclusive; otomatik tested etiketi ekleme.

## TEST F — Sürüm matrisi

Her satır için A, B, C, D, E'yi aynı build'le uygula. iOS downgrade edilebildiği varsayılmıyor; mevcut cihaz laboratuvarındaki sürümler kullanılır.

| Hedef | Normal | Disconnect | Persistent 24h | DVT reset | Reboot reset |
| --- | --- | --- | --- | --- | --- |
| 17.0–17.3.1 | Not run / transport sınırlı | Not run | Not run | Not run | Not run |
| 17.6.1 | Not run | Not run | Not run | Not run | Not run |
| 18.7.8 / iPhone 14 | CoreDevice verified | USB/5G/Windows shutdown verified | CoreDevice verified | DVT fallback needs repeat | Not run |
| 18.7.10 | Not run | Not run | Not run | Not run | Not run |
| 26.2 | Not run | Not run | Not run | Not run | Not run |
| 26.4.1 | Not run / çelişkili dış rapor | Not run | Not run | Not run | Not run |
| 26.5 | Not run | Not run | Not run | Not run | Not run |
| 26.6.1 | Not run | Not run | Not run | Not run | Not run |

Bu tablo FakeGPS'in gerçek test durumudur. Dış projelerin sonuçları `persistent-mode.md` içindeki ayrı tabloda yer alır.

## Hata enjeksiyonu ve cihaz seçimi

- Telefon yokken Set disabled; gerçek backend kendiliğinden demo'ya geçmemeli.
- İki iPhone takılı: kullanıcı seçene kadar hiçbirine set gönderilmemeli.
- USB ve Network ile aynı UDID: tek cihaz gösterilmeli.
- Pairing Trust reddedilsin: sade Trust Required, crash/başarılı aktif durumu olmamalı.
- Telefona kilit koy, setup ortasında kilitle; Unlock yönergesi veya temiz bağlantı hatası beklenir.
- DDI'yi bulunamayan, bozuk veya build uyumsuz dosyayla dene; sahte Ready üretmemeli.
- Tunnel kurulurken kabloyu çıkar; kısmi kaynaklar kapanmalı.
- Set isteği yollanırken disconnect: belirsiz journal korunmalı, reset başarı iddiası olmamalı.
- Persistent handoff sonrası app kapat/aç: eski state gözlem sonucu diye geri yüklenmemeli.
- Başka iPhone bağla: önceki cihazın recovery reset'i yeni telefona gönderilmemeli.
- Aktif normal modda app close: clear denenmeli; deliberate handoff close: clear gönderilmemeli.
- İnternet yok: harita/arama hata mesajı, koordinatla seçim çalışmaya devam etmeli.

## Windows / macOS paket kabulü

1. Python ve Node olmayan temiz hedef sistem kullan.
2. Installer standart kullanıcı olarak kurulsun; uygulama ve Start Menu ikonu açılsın.
3. Apple driver yokken resmî kurulum bağlantısı çıkmalı; üçüncü taraf driver indirilmemeli.
4. Apple Devices yüklendikten sonra uygulamayı yeniden açıp discovery yap.
5. Terminal penceresi çıkmadığını gözle. Task Manager'da uygulama sürecinin görünmesi normaldir.
6. Harita, arama, Unicode yer adı, Home/favorites ve yeniden açılma persistence'ını test et.
7. Standart kullanıcı permissions; Windows Defender/SmartScreen sonucu kaydet. İmzasız binary uyarısı varsa gizleme.
8. Portable exe'yi boşluk/Türkçe karakter içeren dizinde çalıştır.
9. 100%, 150%, 200% DPI ve küçük ekran testleri; button/status kesilmemeli.
10. macOS arm64/x64 ayrı test, signing/notarization sonucunu açık kaydet.
11. Uninstall/reinstall kullanıcı favorites'ını korumalı; pairing kayıtları silinmemeli.
12. Ağ listener'ları incelensin: app HTTP kontrol sunucusu yok; upstream relay yalnızca loopback/özel Unix socket.

Release kabulü için en az Test A ve E gerçek cihaz üzerinde başarılı olmalıdır. Persistence'i tested olarak tanıtmak için exact build üzerinde C/D'nin tekrarlanabilir sonuçları gerekir. Test olmayan alanlar tested diye işaretlenmez.
