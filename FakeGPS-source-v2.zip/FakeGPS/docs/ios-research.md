# iOS / upstream implementation araştırması

Araştırma tarihi: **5 Eylül 2026**. Beş repository shallow clone edilip gerçek Python/Swift kaynakları incelendi. Snapshot commit'leri `source-snapshots.json` içinde; aşağıdaki code link'leri bu commit'lere sabitlendi. Çalışma ortamına ayrıca PyPI'den `pymobiledevice3 11.3.1` kuruldu ve kullanılan Python sınıfları import edildi. Fiziksel telefon testi yapılmadı.

## Kanıt seviyeleri

| Etiket | Anlam |
| --- | --- |
| OFFICIAL | Apple veya ilgili altyapının resmî belgesi; kapsamı kadar kesin. |
| SOURCE CODE VERIFIED | İlgili fonksiyonun kaynak dosyası okundu; telefon üzerinde çalışma kanıtı değildir. |
| DEVELOPER TEST | Geliştiricinin kendi cihazında çalıştığına dair beyan; bağımsız tekrar yok. |
| COMMUNITY REPORT | Issue/discussion içinde kullanıcı sonucu; exact build/donanım eksik olabilir. |
| UNVERIFIED | Savunulabilir fiziksel sonuç veya yeterli kaynak yok. |

## Güncel sürümler

5 Eylül'de açılan [Apple iOS 26 release notes](https://support.apple.com/123075) 26.6.1'i, [iOS 18 release notes](https://support.apple.com/121161) 18.7.10'u listeliyor. Bunlar **OFFICIAL sürüm varlığı kanıtı**; location simulation desteği kanıtı değil. Daha eski indekslenmiş güvenlik sayfası özetlerinden “26.5.1 en güncel” sonucu çıkarılmadı. Cihaz modeline göre dağıtım uygunluğu ayrıca değişebilir.

Upstream ana dalı iOS 27 hazırlığı da içeriyor; bu uygulama test edilmemiş yeni major'lara otomatik supported etiketi vermez. 27.x, 16.x ve daha eskiler şu MVP'de engellenir. 17.x kabul edilir ancak erken 17 aralığının transport kısıtı aşağıdadır.

## pymobiledevice3: gerçek protokol zinciri

**SOURCE CODE VERIFIED — pairing / lockdown.** [`lockdown.py`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/lockdown.py) içindeki `create_using_usbmux` serial, connection_type, autopair ve pair_timeout parametreleri alıyor. Cihazın pairing kaydı/host session'ı bu katmanda ele alınıyor. Keşif ile pairing işlemini ayırdık. [usbmux.py](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/usbmux.py) listesinde `MuxDevice.connection_type` USB veya Network olabilir; UDID bazında tekilleştirme gerekir.

**SOURCE CODE VERIFIED — transport.** [`remote/rsd_tunnel.py`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/remote/rsd_tunnel.py) içindeki `PreferredRsdTunnel` macOS'ta native remoted, diğer platformlarda `UserspaceRsdTunnel` seçiyor. [`remote/userspace_tunnel.py`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/remote/userspace_tunnel.py) `_create_no_root_tunnel_provider`, önce `CoreDeviceTunnelProxy.create(lockdown)` dener; `com.apple.internal.devicecompute.CoreDeviceProxy` iOS 17.4+ yoludur. Servis yoksa bonjour üzerinden RemotePairing koşullarına düşer. `create_using_usbmux` başarısızsa yalnızca bu sınıfı çağırmak, her Wi-Fi cihazını sıfırdan keşfetmeye yetmez.

**SOURCE CODE VERIFIED — RSD ve DVT.** [`remote_service_discovery.py`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/remote/remote_service_discovery.py) servis keşfi/port bilgisi ve remote bağlantı provider'ını sağlar. [`dvt_provider.py`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/services/dvt/instruments/dvt_provider.py) RSD tarafında `com.apple.instruments.dtservicehub`, eski lockdown tarafında `com.apple.instruments.remoteserver.DVTSecureSocketProxy` kullanır. `DvtProvider` DTX connection/context yöneticisidir. Bunlar yeniden implement edilmedi.

**SOURCE CODE VERIFIED — location.** [`location_simulation.py`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/services/dvt/instruments/location_simulation.py) kanal kimliği `com.apple.instruments.server.services.LocationSimulation`; set selector'ı `simulateLocationWithLatitude:longitude:`; clear selector'ı `stopLocationSimulation`. Clear tanımı `expects_reply=False` içerir. [`cli/developer/dvt/simulate_location.py`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/cli/developer/dvt/simulate_location.py) set sonrası DVT ve location context'lerini açık tutup kullanıcıyı bekler. Dolayısıyla set çağrısı bitti diye tüm context'leri hemen kapatmak normal-mode tasarımımız değildir.

**SOURCE CODE VERIFIED — personalized DDI.** [`mobile_image_mounter.py`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/services/mobile_image_mounter.py) iOS 17+ için Personalized image seçer. Mount, build manifest ve trust cache kullanır; mevcut personalization manifest yoksa TSS yoluna başvurur. Bu dosyanın mount başarısı her iOS patch için test değildir. İncelenen upstream otomatik fetch helper'ı `DeveloperDiskImageRepository` aracılığıyla maintainer'ın GitHub reposundan dosya alır; “Apple'ın resmî download API'si” diye sunulmuyor. FakeGPS bounded downloader aynı repository abstraction'ını kullanır, expected build uyuşmazlığını reddeder ve local Xcode klasörü alternatifi sunar. Image payload dağıtılmaz.

**SOURCE CODE VERIFIED — AMFI.** [`amfi.py`](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/pymobiledevice3/services/amfi.py) `com.apple.amfi.lockdown` içinde reveal=0, enable=1, accept=2 işlemlerini gösterir. Enable akışı reboot ve passcode engeline sahip olabilir. İncelenen sınıfta disable Developer Mode metodu yoktur. Uygulama sadece reveal'i kullanır.

**OFFICIAL — Developer Mode.** [Apple Developer Mode belgesi](https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device) kullanıcıya telefondaki toggle/restart/onay akışını anlatır; kapatma akışı da restart içerir. [WWDC22 oturumu](https://developer.apple.com/videos/play/wwdc2022/110344/) lab otomasyonunu ve `devmodectl` yaklaşımını açıklar. Bunların hiçbiri persistent Core Location API garantisi değildir.

## Beş proje karşılaştırması

| Proje ve incelenen dosya | Kaynakta görülen yaklaşım | FakeGPS kararına etkisi |
| --- | --- | --- |
| [GeoPort `src/main.py`](https://github.com/davesc63/GeoPort/blob/d38c7c550512d3d1e0e6c49de59a695d417bc5f0/src/main.py) | Flask routes; USB/remote/Wi-Fi tunnel yönetimi; RSD üzerinden eski `DvtSecureSocketProxyService` ile location set/clear; AMFI enable akışı. | Başlangıç referansı; eski senkron API'ler kopyalanmadı. Passcode kaldırmayı önermedik. |
| [iOS-GPS-Spoofer `SpoofSession.swift`](https://github.com/SegFault42/iOS-GPS-Spoofer/blob/6dc4bfedfddecb8b93a600e0b3c81cf885ff83f3/Sources/SpooferCore/SpoofSession.swift) | Swift GUI, `pymobiledevice3 mounter` ve DVT CLI çocuk süreçleri; set oturumunu açık tutma, stop sırasında ayrı clear, reconnect supervision. | Session lifetime ve temiz stop ayrımı; bizim doğrudan Python API tercihimiz ayrı süreç gerektirmedi. |
| [location-changer `fakeloc.py`](https://github.com/matt-ceran/location-changer/blob/51998fa1a9324761621313951d29a83c2fe7f9e6/fakeloc.py) | Python macOS menu-bar, subprocess `developer dvt simulate-location set/clear`; dışarıda çalışan tunnel önkoşulu. | Kullanıcı dostu küçük ürün fikri; terminal/tunneld önkoşulu benimsenmedi. |
| [LocWarp `device_manager.py`](https://github.com/keezxc1223/locwarp/blob/271779bef895c2443ebde4cdbe3e35bbf72be6de/backend/core/device_manager.py) | USB/Network discovery, per-device connection tablosu, DVT/tunnel yönetimi. | UDID tekilleştirme ve transport durumlarını ayrı izleme. |
| [LocWarp `location_service.py`](https://github.com/keezxc1223/locwarp/blob/271779bef895c2443ebde4cdbe3e35bbf72be6de/backend/services/location_service.py) | Async `LocationSimulation`, lazy connect, connection factory ile yeniden kurulum. | Güncel async API kullanımı doğrulandı; MVP reconnect ile otomatik reapply yapmıyor. |

GeoPort ve location-changer kaynakları güncel kütüphaneye taşınmış gibi kabul edilmedi. README claim'i ile source implementation farkları özellikle not edildi. Bu projelerin kodu uygulamaya kopyalanmadı.

## Normal-mode dış test kanıtları

**DEVELOPER TEST:** [LocWarp README](https://github.com/keezxc1223/locwarp/blob/271779bef895c2443ebde4cdbe3e35bbf72be6de/README.en.md) kendi günlük ortamını iPhone 16 Pro Max / iOS 26.5 / Windows 11 Pro olarak bildiriyor. Aynı README daha eski 17/18/26 patch sonuçlarını toplulukla birlikte listeliyor. Bunlar **COMMUNITY REPORT** düzeyinde ikinci el normal-mode verileridir; persistence sütununa taşınmadı.

**COMMUNITY REPORT — karşı örnek:** [GeoPort #188](https://github.com/davesc63/GeoPort/issues/188), iOS 26.4.1 üzerinde Windows başarılı gibi görünürken telefon konumunun değişmediğini bildiriyor. Aynı patch'in başka uygulamada çalışması bu sonucu silmez. Driver, DDI ve session farklılıkları olabilir; buradan “iOS 26.4.1 tamamen çalışır/çalışmaz” çıkarımı yapılmıyor.

**COMMUNITY REPORT:** [pymobiledevice3 discussion #1463](https://github.com/doronz88/pymobiledevice3/discussions/1463) iOS 26 location simulation bağlamında DVT CLI yolunu tartışır. Standalone offline persistence için 24 saatlik ölçüm değildir.

## Persistence kanıtı ve çelişki

[GeoPort #134](https://github.com/davesc63/GeoPort/issues/134) yorumları REST API üzerinden de okundu. Maintainer'ın [27 Mart 2025 yorumu](https://github.com/davesc63/GeoPort/issues/134#issuecomment-2757074737), iOS 18'de reset davranışını bildiriyor ve workaround olmadığını söylüyor. Bir kullanıcının [16 Nisan 2025 yorumu](https://github.com/davesc63/GeoPort/issues/134#issuecomment-2808513895), bağlıyken Developer Mode kapatılıp ayrılınca birkaç saat kalabildiğini iddia ediyor. Exact iOS patch, cihaz, tam adımlar ve bağımsız 24 saat log yok. Bu rapor **COMMUNITY REPORT**, sürüm bazında doğrulama **UNVERIFIED**.

[location-changer README persistence bölümü](https://github.com/matt-ceran/location-changer/blob/51998fa1a9324761621313951d29a83c2fe7f9e6/README.md) aynı toggle yöntemini anlatıyor; aynı belgenin farklı bölümünde kapatmanın reboot yaptığını söyleyen ifade de var. Test harness'i veya exact-version ölçüm dosyası yok. Bu nedenle yalnızca README iddiasından tested compatibility üretilmedi. Find My'a ilişkin o projedeki iddialar FakeGPS'in kapsamına alınmadı.

## İşletim sistemi ve paketleme kaynakları

Windows için [Apple Devices bağlantı belgesi](https://support.apple.com/108392) ve [tanınmayan cihaz sorun giderme](https://support.apple.com/108643), Apple Devices/iTunes görünürlüğü, Trust, kablo ve driver güncelleme akışlarını destekler (**OFFICIAL**). Bu kaynaklar üçüncü taraf driver yeniden dağıtım izni olarak yorumlanmaz.

Upstream'in [iOS 17+ tunnel rehberi](https://doronz88.github.io/pymobiledevice3/guides/ios17-tunnels/) no-root 17.4+ USB ile erken 17 privileged varsayılanını ayırır. Bu repo `PreferredRsdTunnel` kullanıyor; CLI fallback mantığı birebir aynısı değildir. Windows raw relay loopback'tedir; app-level HTTP helper başlatılmaz.

[PyInstaller operating-mode belgesi](https://pyinstaller.org/en/stable/operating-mode.html) hedef OS üzerinde paketleme ve onefile extraction davranışını açıklar. Linux çıktısı Windows exe diye yeniden adlandırılmadı. Kaynak lisansı [pymobiledevice3 LICENSE](https://github.com/doronz88/pymobiledevice3/blob/3ae93aa4aafac3d95057c70face03438ab5d1e95/LICENSE) ve kurulu distribution metadata'sından kontrol edildi: GPL-3.0-or-later.

## Harita servisleri

[OSM tile policy](https://operations.osmfoundation.org/policies/tiles/) için görünür attribution, uygulama User-Agent'i, yedi gün cache ve viewport-only fetch uygulandı. Canlı servis headless pan/zoom testine maruz bırakılmadı. [Photon projesi](https://github.com/komoot/photon) public demo'yu makul hacimli kullanıma açıyor; kapasite/availability garantisi vermiyor. Sağlayıcı değiştirilebilir; geniş dağıtımda self-hosted Photon veya uygun servis gerekir.

[Nominatim policy](https://operations.osmfoundation.org/policies/nominatim/) uygulamanın toplam trafiği için limit, cache, kimlik ve autocomplete yasağı içeriyor. Çok sayıda masaüstü kopyasında yalnızca istemci başına 1 req/s koymanın uygulama genelinde uyumu garanti etmeyeceği için public Nominatim varsayılanı seçilmedi.
