# Bilinen sınırlamalar

1. **Windows/macOS native binary bu ortamda üretilmedi.** PyInstaller spec, Inno Setup ve CI workflow hazır; Linux build doğrulaması onların yerini almaz.
2. **Fiziksel iPhone testi yok.** Gerçek adapter mevcut ve mock transport ile API sırası test edildi. Core Location çıktısı görülmedi.
3. **Offline persistence garanti değil.** Sihirbaz bilinen topluluk adımlarını yönetir; hiçbir patch hardware-tested olarak işaretli değildir.
4. **Developer Mode OFF otomatik değil.** Menü reveal var; off, passcode/reboot işlemleri telefonda kullanıcıya aittir. Status ON kalırsa deney devamı durur.
5. **Reset readback yok.** DVT clear reply beklemiyor; UI sadece stop isteğinin gönderildiğini söyler. Gerçek nokta telefonda doğrulanır.
6. **iOS 17.0–17.3.1 sınırlı.** Uygulama root/admin tunneld kurmaz. Mevcut no-root RemotePairing koşulları yoksa bağlantı başarısızdır.
7. **Wi-Fi kapsamı sınırlı.** usbmux Network üzerinden görülebilen zaten-paired cihazlar; bağımsız Wi-Fi RemotePairing onboarding/recovery yok.
8. **Aynı anda bir aktif cihaz.** Çoklu görünür cihazlar arasından seçim var; paralel simülasyon yok.
9. **Otomatik reconnect/reapply yok.** Bağlantı kaybı sonrası istenmeyen yeniden spoof önlenir; kullanıcı set/reset'i tekrar başlatır.
10. **DDI hazırlığı ağ/disk koşullarına bağlı.** Upstream mirror ve Apple personalization erişimi gerekebilir. Image payload ve Apple driver pakete eklenmez. Lokal Xcode image klasörü alternatifi var.
11. **Provider SLA yok.** OSM/Photon public servisleri küçük MVP kullanımı içindir. Geniş dağıtımda kapasitesi sağlanmış provider'a geçilmelidir.
12. **Map raster, route yok.** MapLibre/WebEngine yok; GPX, hız, walking/driving sonraki sürüme bırakıldı. Haritadan seçimde reverse-geocoding yapılmaz; kullanıcı koordinat/Selected location görür, arama sonucunda adres etiketi vardır.
13. **Disk cache ve loglar kullanıcı verisidir.** Favorites, recent ve recovery journal şifreli değildir. Uygulamayı paylaşırken kullanıcı app-data dizinini paylaşma.
14. **Upstream internal relay Windows'ta ham loopback TCP kullanır.** App-level HTTP endpoint yoktur; ancak bu relay diğer kötü niyetli yerel süreçlerden izolasyon garantisi vermez.
15. **Signing/notarization yapılmadı.** Windows SmartScreen itibarı, macOS Developer ID ve notarization gerçek yayıncı altyapısı gerektirir.
16. **Transitive dependency çözümlemesi platforma bağlı.** Çalışılan Linux ortamı kaydedildi; Windows/macOS lock ve wheel uygunluğu native CI sonucu ile kesinleşir.
17. **Linux son kullanıcı hedefi değildir.** Bu minimal ortamda Qt EGL/OpenGL sistem kütüphaneleri test için ayrı sağlandı; Linux build yalnızca geliştirme doğrulamasıdır.

Find My/MDM/Activation Lock/anti-cheat/fraud bypass veya simulated-location tespitini gizleme özelliği yoktur. Bunlar sonraki sürüm planı da değildir.
