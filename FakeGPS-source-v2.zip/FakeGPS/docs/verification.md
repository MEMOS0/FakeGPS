# Doğrulama kaydı — 2026-09-05

Bu kayıt gerçek çalıştırmaları, hazırlanan fakat çalıştırılmayan hedeflerden ayırır.

| Kontrol | Sonuç | Kapsam |
|---|---|---|
| Unit + CoreDevice adapter integration + Qt GUI | 44 passed | Python 3.12.13, Linux, Qt offscreen |
| Ruff | All checks passed | Uygulama, script ve test Python dosyaları |
| PyInstaller onedir build | Başarılı | Linux ELF; Windows PE veya macOS Mach-O değildir |
| Python wheel + sdist | Başarılı | Geliştirici dağıtımı; standalone uygulama değildir |
| Frozen `--check-backend` | Önceki build Exit 0 | Yeni CoreDevice hidden-import seti Windows CI'da yeniden doğrulanmalı |
| Frozen `--demo --smoke-test` | Exit 0 | Qt pencere açılışı, mock set/reset akışı |
| Native UI screenshot | Üretildi | `demo-preview.png`; demo haritası gerçek tile değildir |
| Windows installer/portable | ÇALIŞTIRILMADI | Spec, Inno Setup ve native CI hazır |
| macOS .app/.dmg | ÇALIŞTIRILMADI | Native CI ve build script hazır |
| Fiziksel iPhone/Core Location | Başarılı | iPhone 14, iOS 18.7.8, Windows USB; CoreDevice set `{}` ve Apple Maps değişimi |
| Disconnect-safe test | Başarılı | Process/tunnel close, USB çıkarma, Wi-Fi off, 5G, Maps reopen ve Windows shutdown sonrası retained |
| iPhone reboot / Developer Mode off | ÇALIŞTIRILMADI | Persistence iddiası yok |
| Canlı OSM/Photon uçtan uca GUI | ÇALIŞTIRILMADI | Provider/cache davranışları otomatik testlerle sınırlı |

Test komutu: `python scripts/project.py test`. Build: `python scripts/project.py release`.
Geliştirme bağımlılıkları build makinesine kurulur; son kullanıcı frozen uygulamayı açar.
Minimal Linux doğrulama hostunda eksik EGL/OpenGL sistem kütüphaneleri ayrı klasöre
çıkarılıp `LD_LIBRARY_PATH` ile sağlandı. Bu işlem Windows dağıtımının testi değildir.

Frozen backend kontrolü ilk çalışmada pyimg4 dağıtım metadata eksikliğini yakaladı.
Spec recursive metadata collection ile düzeltildi; yeniden build ve import geçti.
Windows kaynak incelemesi ayrıca userspace tunnel kullanıldığında bile
`pytun_pmd3` importunun Wintun DLL yüklediğini gösterdi. Spec Windows'ta bu DLL'leri
ve lisansını toplar. DLL Windows hostunda henüz yüklenerek doğrulanmadı. Uygulama
otomatik Apple driver veya kernel adapter kurulum işlemi yapmaz.

Mock testleri gerçek cihaz desteğini ispatlamaz. Transport context testleri kaynak
kodda beklenen API çağrı sırasını, hata temizliğini ve persistence handoff sırasında
`clear()` çağrılmamasını doğrular. İşletim sisteminin location davranışı yalnızca
`test-plan.md` ile fiziksel cihazda kabul edilebilir.

Native CI çalıştıktan sonra çıkan artifact'leri temiz Windows 11/macOS makinelerinde
kurup test edin; yalnızca build exit-code'una dayanarak release yayımlamayın.


## 0.2.1 Walk/Drive regression pass — 2026-09-06

Bu sürümde route scheduler ve routing matematiği yeniden zorlandı. Mevcut çalışma ortamında
PySide6/pymobiledevice3 paketleri kurulu değildi ve dış ağdan pip kurulumu kapalıydı; bu nedenle
tam Qt + adapter test seti burada yeniden çalıştırılamadı. Buna rağmen dependency gerektirmeyen
hareket/state testleri doğrudan çalıştırıldı ve yeni Qt testleri release CI'da çalışacak şekilde
kaynak ağacına eklendi.

- Controller + movement regression: **30 passed**.
- `compileall`: uygulama, test, script ve packaging Python dosyalarında başarılı.
- Koordinat/routing stress: **20,000** rastgele koordinat çifti, finite/range kontrolleri başarılı.
- Control race stress: **50 rota × 10 pause/resume** çevrimi; deadlock yok, tek connect/release dengesi korundu.
- Tek açık CoreDevice service mock'u üzerinde **50 ardışık setLocation** payload çağrısı doğrulandı.
- Uzun tick sırasında Stop/Pause artık wake event ile anında scheduler'ı uyandırıyor.
- CoreDevice invoke I/O'su sürerken gelen Pause/Stop isteğinin kaybolduğu race senaryosu test edildi.
- Routing provider'ın endpoint snap'i exact kullanıcı başlangıç/hedef koordinatlarıyla sarılıyor; ilk/son teleport önlendi.
- ±180° tarih çizgisini geçen segmentlerde longitude interpolation shortest-path olacak şekilde düzeltildi.
- Bozuk/duplicate route geometry, invalid duration, offline fallback ve unsafe provider URL senaryoları test edildi.
- Route lookup sırasında map/search kilitlenir; kullanıcı route hazırlanırken hedefi istemeden değiştiremez.

Eklenen Qt testleri Walk UI start/pause/resume/stop akışını, Drive hız aralığını ve route-lookup input lock'u sınar.
`python scripts/project.py release` zaten tam `pytest -q` çalıştırdığı için Windows/macOS artifact'i bu yeni GUI
testleri geçmeden üretilmez.

**Fiziksel sınır:** tek CoreDevice `setsimulatedlocation` çağrısının iPhone 14 / iOS 18.7.8'de çalıştığı
fiziksel olarak doğrulanmıştır; aynı LocationService oturumunda saniyeler boyunca ardışık Walk/Drive çağrılarının
gerçek cihaz davranışı bu çalışma ortamında fiziksel iPhone'a bağlanarak yeniden doğrulanmadı. Bu yüzden otomatik
testler protokol/state doğruluğunu kanıtlar, gerçek cihazdaki hareket akışının son kabul testi değildir.


## 0.2.2 Walk/Drive CoreDevice channel recovery — 2026-09-06

- Walk/Drive no longer reuses one LocationService XPC channel across coordinates.
- Each coordinate opens and closes a fresh LocationService on the route's userspace RSD tunnel.
- A generic channel/transport failure triggers one full userspace transport rebuild and exact-coordinate retry.
- Regression coverage verifies two coordinates => one tunnel + two fresh services, plus failure => reconnect => retry.
