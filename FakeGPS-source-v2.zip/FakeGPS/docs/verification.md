# Doğrulama kaydı — 2026-09-05

Bu kayıt gerçek çalıştırmaları, hazırlanan fakat çalıştırılmayan hedeflerden ayırır.

| Kontrol | Sonuç | Kapsam |
|---|---|---|
| Unit + adapter integration + Qt GUI | 50 passed | Python 3.12.13, Linux, Qt offscreen |
| Ruff | All checks passed | Uygulama, script ve test Python dosyaları |
| PyInstaller onedir build | Başarılı | Linux ELF; Windows PE veya macOS Mach-O değildir |
| Python wheel + sdist | Başarılı | Geliştirici dağıtımı; standalone uygulama değildir |
| Frozen `--check-backend` | Exit 0 | Gerçek pymobiledevice3 11.3.1, DVT, tunnel ve DDI modüllerinin import edilmesi |
| Frozen `--demo --smoke-test` | Exit 0 | Qt pencere açılışı, mock set/reset akışı |
| Native UI screenshot | Üretildi | `demo-preview.png`; demo haritası gerçek tile değildir |
| Windows installer/portable | ÇALIŞTIRILMADI | Spec, Inno Setup ve native CI hazır |
| macOS .app/.dmg | ÇALIŞTIRILMADI | Native CI ve build script hazır |
| Fiziksel iPhone/Core Location | ÇALIŞTIRILMADI | Donanım erişimi yok |
| Offline persistent 5 dk–24 saat | ÇALIŞTIRILMADI | Hiçbir sürüm tested olarak işaretlenmedi |
| Canlı OSM/Photon uçtan uca GUI | ÇALIŞTIRILMADI | Provider/cache davranışları otomatik testlerle sınırlı |

Test komutu: `python scripts/project.py test`. Build: `python scripts/project.py release`.
Geliştirme bağımlılıkları build makinesine kurulur; son kullanıcı frozen uygulamayı açar.
Minimal Linux doğrulama hostunda eksik EGL/OpenGL sistem kütüphaneleri ayrı klasöre
çıkarılıp `LD_LIBRARY_PATH` ile sağlandı. Bu işlem Windows dağıtımının testi değildir.

Frozen backend kontrolü ilk çalışmada pyimg4 dağıtım metadata eksikliğini yakaladı.
Spec recursive metadata collection ile düzeltildi; yeniden build ve import geçti.
Windows kaynak incelemesi ayrıca userspace tunnel kullanıldığında bile
`pytun_pmd3` importunun Wintun DLL yüklediğini gösterdi. Spec Windows'ta bu DLL'leri
ve lisansını toplar. DLL Windows hostunda henüz yüklenerek doğrulanmadı. Uygulama
otomatik Apple driver veya kernel adapter kurulum işlemi yapmaz.

Mock testleri gerçek cihaz desteğini ispatlamaz. Transport context testleri kaynak
kodda beklenen API çağrı sırasını, hata temizliğini ve persistence handoff sırasında
`clear()` çağrılmamasını doğrular. İşletim sisteminin location davranışı yalnızca
`test-plan.md` ile fiziksel cihazda kabul edilebilir.

Native CI çalıştıktan sonra çıkan artifact'leri temiz Windows 11/macOS makinelerinde
kurup test edin; yalnızca build exit-code'una dayanarak release yayımlamayın.
