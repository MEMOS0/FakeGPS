import asyncio
import json
import time

import pytest

from fakegps.backend.mock import MockBackend
from fakegps.controller import Controller
from fakegps.models import Location, State
from fakegps.routing import Router, cumulative_distances, distance_m, position_at_distance


def test_dateline_interpolation_uses_short_path():
    points = (Location(0, 179.9, "A"), Location(0, -179.9, "B"))
    cumulative = cumulative_distances(points)
    midpoint = position_at_distance(points, cumulative, cumulative[-1] / 2)
    assert abs(abs(midpoint.longitude) - 180.0) < 1e-6
    assert distance_m(points[0], midpoint) == pytest.approx(cumulative[-1] / 2, rel=0.01)


class FakeResponse:
    def __init__(self, payload):
        self.payload = payload
        self.error = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def raise_for_status(self):
        return None

    def iter_content(self, size):
        yield json.dumps(self.payload).encode()


def test_router_preserves_exact_selected_endpoints(monkeypatch):
    start = Location(45.0, 9.0, "Exact start")
    destination = Location(45.001, 9.001, "Exact destination")
    payload = {
        "routes": [{
            "geometry": {"coordinates": [[9.0002, 45.0002], [9.0005, 45.0005], [9.0008, 45.0008]]},
            "distance": 100,
            "duration": 20,
        }]
    }
    monkeypatch.setattr("fakegps.routing.requests.get", lambda *a, **k: FakeResponse(payload))
    route = Router()._request(start, destination, "drive")
    assert route.points[0] == start
    assert route.points[-1] == destination
    assert route.distance_m == pytest.approx(cumulative_distances(route.points)[-1])
    assert route.duration_s == 20


async def test_router_offline_fallback_is_explicit():
    start = Location(45, 9, "Start")
    end = Location(45.001, 9.001, "End")
    route = await Router(offline=True).route(start, end, "walk")
    assert route.source == "straight"
    assert route.warning
    assert route.points == (start, end)


async def test_stop_wakes_long_tick_immediately():
    backend = MockBackend()
    controller = Controller(backend)
    task = asyncio.create_task(
        controller.simulate_route(
            backend.devices[0],
            [Location(0, 0, "A"), Location(0, 0.01, "B")],
            speed_kmh=5,
            mode="walk",
            tick_seconds=2,
        )
    )
    while controller.state != State.ROUTE_ACTIVE:
        await asyncio.sleep(0)
    started = time.monotonic()
    await controller.stop_route()
    await asyncio.wait_for(task, 0.5)
    assert time.monotonic() - started < 0.5
    assert controller.state == State.ACTIVE


async def test_pause_wakes_long_tick_and_resume_does_not_jump():
    backend = MockBackend()
    snapshots = []
    controller = Controller(backend, snapshots.append)
    task = asyncio.create_task(
        controller.simulate_route(
            backend.devices[0],
            [Location(0, 0, "A"), Location(0, 0.01, "B")],
            speed_kmh=5,
            mode="walk",
            tick_seconds=2,
        )
    )
    while controller.state != State.ROUTE_ACTIVE:
        await asyncio.sleep(0)
    await controller.pause_route()
    for _ in range(100):
        if controller.state == State.ROUTE_PAUSED:
            break
        await asyncio.sleep(0.005)
    assert controller.state == State.ROUTE_PAUSED
    paused_location = controller.location
    await asyncio.sleep(0.05)
    assert controller.location == paused_location
    await controller.resume_route()
    for _ in range(100):
        if controller.state == State.ROUTE_ACTIVE:
            break
        await asyncio.sleep(0.005)
    assert controller.location == paused_location
    await controller.stop_route()
    await asyncio.wait_for(task, 0.5)


class BlockingBackend(MockBackend):
    def __init__(self):
        super().__init__()
        self.entered = asyncio.Event()
        self.release_set = asyncio.Event()

    async def set_location(self, location):
        self.entered.set()
        await self.release_set.wait()
        await super().set_location(location)


async def test_pause_request_is_not_lost_while_coredevice_call_is_in_flight():
    backend = BlockingBackend()
    controller = Controller(backend)
    task = asyncio.create_task(
        controller.simulate_route(
            backend.devices[0], [Location(0, 0), Location(0, 0.01)], 5, "walk", tick_seconds=2
        )
    )
    await asyncio.wait_for(backend.entered.wait(), 0.5)
    await controller.pause_route()
    backend.release_set.set()
    for _ in range(100):
        if controller.state == State.ROUTE_PAUSED:
            break
        await asyncio.sleep(0.005)
    assert controller.state == State.ROUTE_PAUSED
    await controller.stop_route()
    await asyncio.wait_for(task, 0.5)


async def test_stop_request_is_not_lost_while_coredevice_call_is_in_flight():
    backend = BlockingBackend()
    controller = Controller(backend)
    task = asyncio.create_task(
        controller.simulate_route(
            backend.devices[0], [Location(0, 0), Location(0, 0.01)], 5, "drive", tick_seconds=2
        )
    )
    await asyncio.wait_for(backend.entered.wait(), 0.5)
    await controller.stop_route()
    backend.release_set.set()
    await asyncio.wait_for(task, 0.5)
    assert controller.state == State.ACTIVE
    assert backend.calls.count("set") == 1


class FailAfterBackend(MockBackend):
    def __init__(self, successful_sets):
        super().__init__()
        self.successful_sets = successful_sets
        self.attempts = 0

    async def set_location(self, location):
        self.attempts += 1
        if self.attempts > self.successful_sets:
            self.failure = "connection"
        await super().set_location(location)


async def test_route_failure_releases_transport_and_preserves_last_successful_point():
    backend = FailAfterBackend(2)
    controller = Controller(backend)
    with pytest.raises(Exception):
        await controller.simulate_route(
            backend.devices[0], [Location(0, 0), Location(0, 0.001)], 20, "drive", tick_seconds=0.1
        )
    assert controller.state == State.ERROR
    assert controller.location is not None
    assert backend.calls[-1] == "release"
    assert backend.calls.count("set") == 2


@pytest.mark.parametrize("mode", ["fly", "", None])
async def test_invalid_route_mode_is_rejected_before_connect(mode):
    backend = MockBackend()
    controller = Controller(backend)
    with pytest.raises(ValueError):
        await controller.simulate_route(backend.devices[0], [Location(0, 0), Location(0, 0.001)], 5, mode)
    assert backend.calls == []


@pytest.mark.parametrize("speed", [0, -1, 251, float("inf"), float("nan")])
async def test_invalid_route_speed_is_rejected_before_connect(speed):
    backend = MockBackend()
    controller = Controller(backend)
    with pytest.raises(ValueError):
        await controller.simulate_route(
            backend.devices[0], [Location(0, 0), Location(0, 0.001)], speed, "walk"
        )
    assert backend.calls == []


def test_router_deduplicates_consecutive_geometry(monkeypatch):
    start = Location(45.0, 9.0, "Start")
    destination = Location(45.001, 9.001, "End")
    payload = {
        "routes": [{
            "geometry": {"coordinates": [[9.0, 45.0], [9.0, 45.0], [9.0005, 45.0005], [9.001, 45.001]]},
            "distance": 1,
            "duration": "bad",
        }]
    }
    monkeypatch.setattr("fakegps.routing.requests.get", lambda *a, **k: FakeResponse(payload))
    route = Router()._request(start, destination, "walk")
    assert len(route.points) == 3
    assert route.duration_s is None
    assert route.distance_m > 100

@pytest.mark.parametrize("endpoint", ["http://example.com/route", "file:///tmp/route", "https://u:p@example.com/route"])
def test_router_provider_requires_safe_https(endpoint):
    with pytest.raises(ValueError):
        Router(drive_endpoint=endpoint)
