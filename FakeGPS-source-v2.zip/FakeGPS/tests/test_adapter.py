"""Protocol boundary tests: CoreDevice calls are mocked, not an iPhone."""

from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

import pytest

from fakegps.backend.device import (
    LOCATION_SERVICE,
    SET_ACTION,
    SIMULATE_FEATURE,
    DeviceBackend,
)
from fakegps.models import Device, Location


class Context:
    def __init__(self, value, events, name):
        self.value, self.events, self.name = value, events, name

    async def __aenter__(self):
        self.events.append("open:" + self.name)
        return self.value

    async def __aexit__(self, *args):
        self.events.append("close:" + self.name)


@pytest.fixture
def protocol(monkeypatch):
    import pymobiledevice3.remote.core_device.location_service as location_module
    import pymobiledevice3.remote.userspace_tunnel as tunnel_module
    import pymobiledevice3.services.mobile_image_mounter as mount

    events = []
    lockdown = SimpleNamespace(
        all_values={"ProductVersion": "18.7.8", "ProductType": "iPhone14,7", "DeviceName": "Phone"},
        get_developer_mode_status=AsyncMock(return_value=True),
    )
    mounter = SimpleNamespace(is_image_mounted=AsyncMock(return_value=True))
    rsd = SimpleNamespace(require_feature=Mock())
    location = SimpleNamespace(invoke=AsyncMock(return_value={}))
    monkeypatch.setattr(tunnel_module, "UserspaceRsdTunnel", lambda **kw: Context(rsd, events, "tunnel"))
    monkeypatch.setattr(mount, "MobileImageMounterService", lambda ld: Context(mounter, events, "mounter"))
    monkeypatch.setattr(location_module, "LocationService", lambda value: Context(location, events, "location"))
    backend = DeviceBackend()
    monkeypatch.setattr(
        backend, "_open_lockdown", AsyncMock(side_effect=lambda device: Context(lockdown, events, "lockdown"))
    )
    return backend, lockdown, mounter, rsd, location, events


async def test_coredevice_chain_payload_and_cleanup(protocol):
    backend, _, _, rsd, location, events = protocol
    await backend.connect(Device("my-device"))
    rsd.require_feature.assert_called_once_with(LOCATION_SERVICE, SIMULATE_FEATURE)
    await backend.set_location(Location(45.46, 9.19))
    location.invoke.assert_awaited_once_with(
        SIMULATE_FEATURE,
        {"latitude": 45.46, "longitude": 9.19},
        action_identifier=SET_ACTION,
    )
    await backend.release()
    assert events[-3:] == ["close:location", "close:tunnel", "close:lockdown"]


async def test_walk_drive_reopens_location_service_for_every_coordinate(protocol):
    backend, _, _, _, location, events = protocol
    await backend.connect(Device("my-device"))
    await backend.set_location(Location(45.46, 9.19))
    await backend.set_location(Location(45.46001, 9.19001))

    assert location.invoke.await_count == 2
    assert events.count("open:tunnel") == 1
    assert events.count("open:location") == 2
    assert events.count("close:location") == 2
    # The shared userspace RSD tunnel is still alive until route completion.
    assert events.count("close:tunnel") == 0
    await backend.release()
    assert events.count("close:tunnel") == 1


async def test_fresh_service_survives_a_server_that_allows_only_one_invoke_per_channel(protocol, monkeypatch):
    import pymobiledevice3.remote.core_device.location_service as location_module

    backend, _, _, _, _, events = protocol
    services = []

    class OneShotLocation:
        def __init__(self):
            self.calls = 0

        async def invoke(self, *args, **kwargs):
            self.calls += 1
            if self.calls > 1:
                raise OSError("server closed one-shot LocationService channel")
            return {}

    def factory(rsd):
        service = OneShotLocation()
        services.append(service)
        return Context(service, events, "location")

    monkeypatch.setattr(location_module, "LocationService", factory)
    await backend.connect(Device("my-device"))
    await backend.set_location(Location(45.46, 9.19))
    await backend.set_location(Location(45.46001, 9.19001))

    assert len(services) == 2
    assert [service.calls for service in services] == [1, 1]
    await backend.release()


async def test_location_channel_failure_rebuilds_transport_and_retries(protocol):
    backend, _, _, _, location, events = protocol
    location.invoke.side_effect = [OSError("stale CoreDevice channel"), {}]
    await backend.connect(Device("my-device"))

    response = await backend.set_location(Location(45.46, 9.19))

    assert response == {}
    assert location.invoke.await_count == 2
    assert events.count("open:tunnel") == 2
    assert events.count("close:tunnel") == 1
    assert events.count("open:location") == 2
    assert events.count("close:location") == 2
    await backend.release()

async def test_adapter_mounts_before_starting_tunnel(protocol):
    backend, _, mounter, _, _, events = protocol
    mounter.is_image_mounted.return_value = False
    mounted = AsyncMock()
    monkeypatch = pytest.MonkeyPatch()
    try:
        import pymobiledevice3.services.mobile_image_mounter as mount

        monkeypatch.setattr(mount, "auto_mount", mounted)
        await backend.connect(Device("my-device"))
    finally:
        monkeypatch.undo()
    mounted.assert_awaited_once()
    assert events.index("open:tunnel") > events.index("close:mounter")
    await backend.release()


async def test_transport_release_never_implicitly_clears(protocol):
    backend, _, _, _, location, _ = protocol
    await backend.connect(Device("my-device"))
    await backend.release()
    location.invoke.assert_not_awaited()


async def test_feature_rejection_is_not_silently_set(protocol):
    backend, _, _, rsd, location, _ = protocol
    rsd.require_feature.side_effect = RuntimeError("feature unavailable")
    with pytest.raises(Exception):
        await backend.connect(Device("my-device"))
    location.invoke.assert_not_awaited()
