"""Integration at the protocol boundary: real adapter, mocked transports (no iPhone)."""

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from fakegps.backend.device import DeviceBackend
from fakegps.models import Device, Location


class Context:
    def __init__(self, value, events, name):
        self.value, self.events, self.name = value, events, name

    async def __aenter__(self):
        self.events.append("open:" + self.name)
        return self.value

    async def __aexit__(self, *args):
        self.events.append("close:" + self.name)


@pytest.fixture
def protocol(monkeypatch):
    import pymobiledevice3.remote.rsd_tunnel as tunnels
    import pymobiledevice3.services.dvt.instruments.dvt_provider as dvt_module
    import pymobiledevice3.services.dvt.instruments.location_simulation as loc_module
    import pymobiledevice3.services.mobile_image_mounter as mount

    events = []
    disconnected = asyncio.Event()
    lockdown = SimpleNamespace(
        all_values={"ProductVersion": "18.7.8", "ProductType": "iPhone14,7", "DeviceName": "Phone"},
        get_developer_mode_status=AsyncMock(return_value=True),
        get_value=AsyncMock(return_value="18.7.8"),
    )
    mounter = SimpleNamespace(is_image_mounted=AsyncMock(return_value=True))
    dvt = SimpleNamespace(dtx=SimpleNamespace(wait_disconnected=disconnected.wait))
    location = SimpleNamespace(set=AsyncMock(), clear=AsyncMock())
    monkeypatch.setattr(tunnels, "PreferredRsdTunnel", lambda **kw: Context(object(), events, "tunnel"))
    monkeypatch.setattr(mount, "MobileImageMounterService", lambda ld: Context(mounter, events, "mounter"))
    monkeypatch.setattr(dvt_module, "DvtProvider", lambda rsd: Context(dvt, events, "dvt"))
    monkeypatch.setattr(loc_module, "LocationSimulation", lambda dvt: Context(location, events, "location"))
    backend = DeviceBackend()
    monkeypatch.setattr(
        backend, "_open_lockdown", AsyncMock(side_effect=lambda device: Context(lockdown, events, "lockdown"))
    )
    return backend, lockdown, mounter, location, events, disconnected


async def test_real_adapter_chain_and_reverse_cleanup(protocol):
    backend, _, _, location, events, _ = protocol
    await backend.connect(Device("my-device"))
    await backend.set_location(Location(45.46, 9.19))
    location.set.assert_awaited_once_with(45.46, 9.19)
    await backend.clear_location()
    location.clear.assert_awaited_once()
    assert await backend.healthy()
    await backend.release()
    assert events[-4:] == ["close:location", "close:dvt", "close:tunnel", "close:lockdown"]


async def test_adapter_partial_connect_failure_closes_resources(protocol):
    backend, _, mounter, _, events, _ = protocol
    mounter.is_image_mounted.return_value = False
    with pytest.raises(Exception) as error:
        await backend.connect(Device("my-device"))
    assert error.value.code == "ddi"
    assert "open:tunnel" not in events
    assert events[-1] == "close:lockdown"


async def test_dvt_disconnect_detected_when_lockdown_still_alive(protocol):
    backend, _, _, _, _, disconnected = protocol
    await backend.connect(Device("my-device"))
    disconnected.set()
    await asyncio.sleep(0)
    assert not await backend.healthy()
    await backend.release()


async def test_transport_release_does_not_implicitly_clear(protocol):
    backend, _, _, location, _, _ = protocol
    await backend.connect(Device("my-device"))
    await backend.release()
    location.clear.assert_not_awaited()
