import asyncio

import pytest
from fakegps.backend.mock import MockBackend
from fakegps.controller import Controller
from fakegps.errors import UserError
from fakegps.models import Device, Location, State


@pytest.fixture
def setup():
    backend = MockBackend()
    snapshots = []
    return backend, Controller(backend, snapshots.append), snapshots


async def active(setup):
    backend, controller, _ = setup
    await controller.set_location(backend.devices[0], Location(45.4642, 9.19, "Milan"))
    return backend, controller


async def test_set_clear_lifecycle(setup):
    backend, controller = await active(setup)
    assert controller.state == State.ACTIVE
    await controller.reset()
    assert controller.state == State.RESET_SENT
    assert backend.location is None
    assert backend.calls == ["connect", "set", "release", "connect", "clear", "release"]


async def test_failed_set_never_reports_active_but_records_uncertainty(setup):
    backend, controller, snapshots = setup
    backend.failure = "connection"
    with pytest.raises(UserError):
        await controller.set_location(backend.devices[0], Location(0, 0))
    assert controller.state == State.ERROR
    assert controller.location is not None
    assert State.ACTIVE not in [s.state for s in snapshots]


async def test_ephemeral_coredevice_set_is_not_misreported_as_disconnected(setup):
    backend, controller = await active(setup)
    backend.devices = []
    await controller.check_health()
    assert controller.state == State.ACTIVE
    assert backend.calls.count("set") == 1
    assert controller.location is not None


async def test_no_switch_to_other_device_with_existing_simulation(setup):
    _, controller = await active(setup)
    with pytest.raises(UserError):
        await controller.set_location(Device("other"), Location(1, 1))


async def test_reset_failure_preserves_uncertain_session(setup):
    backend, controller = await active(setup)
    backend.dev_mode = False
    with pytest.raises(UserError):
        await controller.reset()
    assert controller.state == State.ERROR
    assert controller.location is not None


async def test_close_never_clears_a_coredevice_location(setup):
    backend, controller = await active(setup)
    await controller.shutdown()
    assert "clear" not in backend.calls
    assert controller.location is not None


async def test_serializes_set_and_reset(setup):
    backend, controller, snapshots = setup
    await asyncio.gather(controller.set_location(backend.devices[0], Location(0, 0)), controller.reset())
    assert controller.state == State.RESET_SENT
    assert backend.calls.index("set") < backend.calls.index("clear")


async def test_walk_route_keeps_one_connection_until_complete(setup):
    backend, controller, snapshots = setup
    start = Location(0, 0, "Start")
    end = Location(0, 0.000005, "End")
    await controller.simulate_route(
        backend.devices[0], [start, end], speed_kmh=12, mode="walk", tick_seconds=0.1
    )
    assert controller.state == State.ACTIVE
    assert controller.location.label == "End"
    assert backend.calls[0] == "connect"
    assert backend.calls[-1] == "release"
    assert backend.calls.count("connect") == 1
    assert backend.calls.count("release") == 1
    assert backend.calls.count("set") >= 2
    assert State.ROUTE_ACTIVE in [snapshot.state for snapshot in snapshots]


async def test_route_can_pause_resume_and_stop(setup):
    backend, controller, _ = setup
    start = Location(0, 0, "Start")
    end = Location(0, 0.00002, "End")
    task = asyncio.create_task(
        controller.simulate_route(
            backend.devices[0], [start, end], speed_kmh=12, mode="drive", tick_seconds=0.1
        )
    )
    while controller.route_mode is None:
        await asyncio.sleep(0)
    await controller.pause_route()
    await asyncio.sleep(0.12)
    assert controller.state == State.ROUTE_PAUSED
    await controller.resume_route()
    await asyncio.sleep(0.12)
    await controller.stop_route()
    await task
    assert controller.state == State.ACTIVE
    assert controller.location is not None
    assert backend.calls[-1] == "release"
