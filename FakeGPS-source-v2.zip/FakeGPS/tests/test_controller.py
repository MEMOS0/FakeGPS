import asyncio

import pytest
from fakegps.backend.mock import MockBackend
from fakegps.controller import Controller
from fakegps.errors import UserError
from fakegps.models import Device, Location, State


@pytest.fixture
def setup():
    backend = MockBackend()
    snapshots = []
    return backend, Controller(backend, snapshots.append), snapshots


async def active(setup):
    backend, controller, _ = setup
    await controller.set_location(backend.devices[0], Location(45.4642, 9.19, "Milan"))
    return backend, controller


async def test_set_clear_lifecycle(setup):
    backend, controller = await active(setup)
    assert controller.state == State.ACTIVE
    await controller.reset()
    assert controller.state == State.RESET_SENT
    assert backend.location is None
    assert backend.calls == ["connect", "set", "connect", "clear", "release"]


async def test_failed_set_never_reports_active_but_records_uncertainty(setup):
    backend, controller, snapshots = setup
    backend.failure = "connection"
    with pytest.raises(UserError):
        await controller.set_location(backend.devices[0], Location(0, 0))
    assert controller.state == State.ERROR
    assert controller.location is not None
    assert State.ACTIVE not in [s.state for s in snapshots]


@pytest.mark.parametrize("mode", [False, None])
async def test_persistent_never_claims_verification_and_never_clears(setup, mode):
    backend, controller = await active(setup)
    await controller.start_persistence()
    backend.dev_mode = mode
    await controller.finish_persistence(True, True)
    assert controller.state == State.PERSISTENCE_UNVERIFIED
    await controller.shutdown()
    assert "clear" not in backend.calls
    assert backend.location is not None


async def test_persistence_rejects_still_on_toggle(setup):
    _, controller = await active(setup)
    await controller.start_persistence()
    with pytest.raises(UserError):
        await controller.finish_persistence(True, True)
    assert controller.state == State.PERSISTENCE_SETUP


@pytest.mark.parametrize("maps,toggle", [(False, True), (True, False), (False, False)])
async def test_persistence_requires_two_confirmations(setup, maps, toggle):
    backend, controller = await active(setup)
    await controller.start_persistence()
    backend.dev_mode = False
    with pytest.raises(UserError):
        await controller.finish_persistence(maps, toggle)
    assert "release" not in backend.calls


async def test_disconnect_becomes_unknown_without_reapplying(setup):
    backend, controller = await active(setup)
    backend.devices = []
    await controller.check_health()
    assert controller.state == State.DISCONNECTED
    assert backend.calls.count("set") == 1
    assert controller.location is not None


async def test_no_switch_to_other_device_with_existing_simulation(setup):
    _, controller = await active(setup)
    with pytest.raises(UserError):
        await controller.set_location(Device("other"), Location(1, 1))


async def test_reset_failure_preserves_uncertain_session(setup):
    backend, controller = await active(setup)
    backend.dev_mode = False
    with pytest.raises(UserError):
        await controller.reset()
    assert controller.state == State.ERROR
    assert controller.location is not None


async def test_cancel_after_toggle_does_not_claim_active(setup):
    backend, controller = await active(setup)
    await controller.start_persistence()
    backend.dev_mode = False
    await controller.cancel_persistence()
    assert controller.state == State.ERROR


async def test_normal_shutdown_clears(setup):
    backend, controller = await active(setup)
    await controller.shutdown()
    assert "clear" in backend.calls
    assert controller.location is None


async def test_serializes_set_and_reset(setup):
    backend, controller, snapshots = setup
    await asyncio.gather(controller.set_location(backend.devices[0], Location(0, 0)), controller.reset())
    assert controller.state == State.RESET_SENT
    assert backend.calls.index("set") < backend.calls.index("clear")
