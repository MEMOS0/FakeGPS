import pytest
from fakegps.backend.mock import MockBackend
from fakegps.frontend.window import Window
from fakegps.models import PRESETS, Device, State
from fakegps.storage import Store
from PySide6.QtCore import QPoint, Qt
from PySide6.QtWidgets import QMessageBox


@pytest.fixture
def window(qtbot, tmp_path, monkeypatch):
    monkeypatch.setattr(QMessageBox, "question", lambda *args, **kwargs: QMessageBox.Yes)
    monkeypatch.setattr(QMessageBox, "information", lambda *args, **kwargs: QMessageBox.Ok)
    widget = Window(MockBackend(), Store(tmp_path / "settings.json"), demo=True, start_polling=False)
    qtbot.addWidget(widget)
    widget.show()
    widget.discover()
    qtbot.waitUntil(lambda: "discover" not in widget.jobs)
    yield widget
    widget.poll.stop()
    # Dispose through the real shutdown path, without an interactive test dialog.
    # On Windows, Qt may already have delivered closeEvent while unwinding the
    # fixture, which completes shutdown and closes the worker loop first.
    if widget.runner.thread.is_alive() and not widget.runner.loop.is_closed():
        widget.runner.submit("test_cleanup", widget.controller.shutdown()).result(timeout=5)
    widget.map.shutdown()
    widget.runner.stop()
    widget.allow_close = True
    widget.close()


def test_set_and_reset_complete_flow(qtbot, window):
    assert window.set_button.isEnabled()
    qtbot.mouseClick(window.set_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: window.current.state == State.ACTIVE and "set" not in window.jobs)
    assert window.status.text() == "SPOOFING ACTIVE"
    assert window.store.data["session"]["hardware_verified"] is False
    qtbot.mouseClick(window.reset_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: window.current.state == State.RESET_SENT)
    assert window.store.data["session"] is None


def test_search_marker_coordinates_and_recents(qtbot, window):
    window.search.setText("Tokyo")
    qtbot.mouseClick(window.search_button, Qt.LeftButton)
    assert window.selected == PRESETS[3]
    qtbot.mouseClick(window.map, Qt.LeftButton, pos=QPoint(40, 60))
    assert window.selected != PRESETS[3]
    assert window.lat.value() == pytest.approx(window.selected.latitude, abs=0.000001)
    qtbot.mouseClick(window.set_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: "set" not in window.jobs)
    assert window.store.locations("recent")[0] == window.selected


def test_persistence_wizard_and_offline_state(qtbot, window):
    window.persistent.setChecked(True)
    qtbot.mouseClick(window.set_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: window.wizard is not None)
    wizard = window.wizard
    assert not wizard.confirm.isEnabled()
    wizard.maps.setChecked(True)
    wizard.off.setChecked(True)
    qtbot.mouseClick(wizard.confirm, Qt.LeftButton)
    qtbot.waitUntil(lambda: window.current.state == State.PERSISTENCE_UNVERIFIED and window.wizard is None)
    assert "UNVERIFIED" in window.status.text()
    assert not window.set_button.isEnabled()
    assert "clear" not in window.backend.calls


def test_multiple_devices_require_explicit_selection(qtbot, window):
    window.backend.devices.append(Device("other", "Other iPhone", "iPhone 14", "26.6"))
    # Clear previous selection to model a cold start with multiple phones.
    window.device_box.setCurrentIndex(-1)
    window.discover()
    qtbot.waitUntil(lambda: "discover" not in window.jobs)
    assert window.device_box.currentData() is None
    assert not window.set_button.isEnabled()
    window.device_box.setCurrentIndex(2)
    assert window.device_box.currentData().udid == "other"
    assert window.set_button.isEnabled()


def test_no_device_does_not_fall_back_to_fake_success(qtbot, window):
    window.backend.devices = []
    window.discover()
    qtbot.waitUntil(lambda: "discover" not in window.jobs)
    assert not window.set_button.isEnabled()
    assert window.device_box.currentData() is None
