import pytest
from fakegps.backend.mock import MockBackend
from fakegps.frontend.window import Window
from fakegps.models import PRESETS, Device, Location, State
from fakegps.storage import Store
from PySide6.QtCore import QPoint, Qt
from PySide6.QtWidgets import QMessageBox


@pytest.fixture
def window(qtbot, tmp_path, monkeypatch):
    monkeypatch.setattr(QMessageBox, "question", lambda *args, **kwargs: QMessageBox.Yes)
    monkeypatch.setattr(QMessageBox, "information", lambda *args, **kwargs: QMessageBox.Ok)
    widget = Window(MockBackend(), Store(tmp_path / "settings.json"), demo=True, start_polling=False)
    qtbot.addWidget(widget)
    widget.show()
    widget.discover()
    qtbot.waitUntil(lambda: "discover" not in widget.jobs)
    yield widget
    widget.poll.stop()
    # Dispose through the real shutdown path, without an interactive test dialog.
    # On Windows, Qt may already have delivered closeEvent while unwinding the
    # fixture, which completes shutdown and closes the worker loop first.
    if widget.runner.thread.is_alive() and not widget.runner.loop.is_closed():
        widget.runner.submit("test_cleanup", widget.controller.shutdown()).result(timeout=5)
    widget.map.shutdown()
    widget.runner.stop()
    widget.allow_close = True
    widget.close()


def test_set_and_reset_complete_flow(qtbot, window):
    assert window.set_button.isEnabled()
    qtbot.mouseClick(window.set_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: window.current.state == State.ACTIVE and "set" not in window.jobs)
    assert window.status.text() == "SPOOFING ACTIVE"
    assert window.store.data["session"]["hardware_verified"] is False
    qtbot.mouseClick(window.reset_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: window.current.state == State.RESET_SENT)
    assert window.store.data["session"] is None


def test_completion_does_not_overtake_queued_snapshot(qtbot, window):
    from fakegps.controller import Snapshot

    location = PRESETS[0]
    device = window.devices[0]
    window.jobs.add("set")
    window.runner.snapshot.emit(Snapshot(State.ACTIVE, device, location, "Accepted"))
    # Models add_done_callback executing on the GUI thread for an already
    # completed Future, while its state update is still queued.
    window.runner.done.emit("set", None)
    assert "set" in window.jobs
    qtbot.waitUntil(lambda: "set" not in window.jobs)
    assert window.store.locations("recent")[0] == location


def test_search_marker_coordinates_and_recents(qtbot, window):
    window.search.setText("Tokyo")
    qtbot.mouseClick(window.search_button, Qt.LeftButton)
    assert window.selected == PRESETS[3]
    qtbot.mouseClick(window.map, Qt.LeftButton, pos=QPoint(40, 60))
    assert window.selected != PRESETS[3]
    assert window.lat.value() == pytest.approx(window.selected.latitude, abs=0.000001)
    qtbot.mouseClick(window.set_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: "set" not in window.jobs)
    assert window.store.locations("recent")[0] == window.selected


def test_coredevice_badge_and_disconnect_safe_state(qtbot, window):
    assert window.persistent.isChecked()
    assert not window.persistent.isEnabled()
    qtbot.mouseClick(window.set_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: window.current.state == State.ACTIVE and "set" not in window.jobs)
    assert "disconnect" in window.current.detail.lower()
    assert "clear" not in window.backend.calls


def test_multiple_devices_require_explicit_selection(qtbot, window):
    window.backend.devices.append(Device("other", "Other iPhone", "iPhone 14", "26.6"))
    # Clear previous selection to model a cold start with multiple phones.
    window.device_box.setCurrentIndex(-1)
    window.discover()
    qtbot.waitUntil(lambda: "discover" not in window.jobs)
    assert window.device_box.currentData() is None
    assert not window.set_button.isEnabled()
    window.device_box.setCurrentIndex(2)
    assert window.device_box.currentData().udid == "other"
    assert window.set_button.isEnabled()


def test_no_device_does_not_fall_back_to_fake_success(qtbot, window):
    window.backend.devices = []
    window.discover()
    qtbot.waitUntil(lambda: "discover" not in window.jobs)
    assert not window.set_button.isEnabled()
    assert window.device_box.currentData() is None



def test_walk_ui_pause_resume_stop_flow(qtbot, window):
    window.mode.setCurrentIndex(window.mode.findData("walk"))
    window.speed.setValue(12)
    start = Location(45.4642, 9.19, "Start")
    destination = Location(45.4642, 9.1901, "Destination")
    window.pick(start)
    window.capture_route_start()
    window.pick(destination)
    assert window.set_button.text() == "START WALK"
    qtbot.mouseClick(window.set_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: window.current.state == State.ROUTE_ACTIVE, timeout=2000)
    assert window.pause_button.isVisible()
    assert window.stop_button.isVisible()
    qtbot.mouseClick(window.pause_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: window.current.state == State.ROUTE_PAUSED, timeout=1000)
    assert window.pause_button.text() == "RESUME"
    qtbot.mouseClick(window.pause_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: window.current.state == State.ROUTE_ACTIVE, timeout=1000)
    qtbot.mouseClick(window.stop_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: "route" not in window.jobs, timeout=1000)
    assert window.current.state == State.ACTIVE
    assert window.current.location is not None


def test_drive_ui_uses_drive_speed_range(window):
    window.mode.setCurrentIndex(window.mode.findData("drive"))
    assert window.set_button.text() == "START DRIVE"
    assert window.speed.minimum() == 5
    assert window.speed.maximum() == 180
    window.speed.setValue(73)
    assert window.speed_label.text() == "73 km/h"


def test_route_lookup_temporarily_locks_map_and_search(qtbot, window, monkeypatch):
    import asyncio
    from fakegps.routing import straight_route

    async def slow_route(start, destination, mode):
        await asyncio.sleep(0.15)
        return straight_route(start, destination)

    monkeypatch.setattr(window.router, "route", slow_route)
    window.mode.setCurrentIndex(window.mode.findData("walk"))
    start = Location(45.4642, 9.19, "Start")
    destination = Location(45.4642, 9.1902, "Destination")
    window.pick(start)
    window.capture_route_start()
    window.pick(destination)
    qtbot.mouseClick(window.set_button, Qt.LeftButton)
    assert "route_lookup" in window.jobs
    assert not window.map.isEnabled()
    assert not window.search.isEnabled()
    qtbot.waitUntil(lambda: "route" in window.jobs, timeout=1000)
    assert not window.map.isEnabled()
    qtbot.mouseClick(window.stop_button, Qt.LeftButton)
    qtbot.waitUntil(lambda: "route" not in window.jobs, timeout=1000)
