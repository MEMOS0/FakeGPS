import math

import pytest
from fakegps.compatibility import compatibility
from fakegps.errors import classify
from fakegps.frontend.map_widget import project, unproject
from fakegps.geocoding import Geocoder, https_url
from fakegps.models import Location
from fakegps.routing import cumulative_distances, distance_m, position_at_distance, straight_route
from fakegps.storage import Store


@pytest.mark.parametrize("lat,lon", [(91, 0), (-91, 0), (0, 181), (0, -181), (math.nan, 0), (0, math.inf)])
def test_invalid_coordinates_rejected(lat, lon):
    with pytest.raises(ValueError):
        Location(lat, lon)


@pytest.mark.parametrize("lat,lon", [(0, 0), (45.46, 9.19), (-33.86, 151.2), (85, -179.99)])
def test_map_round_trip(lat, lon):
    assert unproject(*project(lat, lon, 12), 12) == pytest.approx((lat, lon))


def test_dateline_wrap():
    x, y = project(0, 179, 3)
    lat, lon = unproject(x + 256, y, 3)
    assert lat == pytest.approx(0)
    assert lon == pytest.approx(-136)


@pytest.mark.parametrize("version", ["17.0", "26.2", "26.6", "26.99"])
def test_unknown_versions_never_claim_hardware_persistence(version):
    item = compatibility(version)
    assert item["persistent"] == "unverified"


def test_exact_physical_coredevice_result_is_narrowly_scoped():
    item = compatibility("18.7.8")
    assert item["persistent"] == "verified_iPhone14_windows_usb"
    assert "iPhone reboot" in item["not_verified"]
    assert item["hardware_tested"] is True


@pytest.mark.parametrize("version", ["nonsense", "16.7", "27.0"])
def test_unsupported_future_and_legacy(version):
    assert compatibility(version)["normal"] == "unsupported"


def test_saved_locations_atomic_dedupe_and_reopen(tmp_path):
    path = tmp_path / "preferences.json"
    store = Store(path)
    store.add("favorites", Location(0, 0, "İstanbul 東京"))
    store.add("favorites", Location(0, 0, "Home"))
    assert Store(path).locations("favorites") == [Location(0, 0, "Home")]
    assert not path.with_suffix(".tmp").exists()


def test_corrupted_settings_recover(tmp_path):
    path = tmp_path / "preferences.json"
    path.write_text("{broken")
    assert Store(path).locations("favorites") == []


def test_errors_do_not_expose_raw_exception():
    from pymobiledevice3.exceptions import DeveloperModeIsNotEnabledError, InvalidServiceError, PairingError

    assert classify(InvalidServiceError("private protocol dump", "redacted", "18.7.8")).code == "coredevice_service"
    assert "private" not in str(classify(InvalidServiceError("private", "redacted", "18.7.8")))
    assert classify(PairingError()).code == "trust"
    assert classify(DeveloperModeIsNotEnabledError()).code == "developer"


@pytest.mark.parametrize(
    "url",
    ["http://example.com", "file:///tmp/test", "https://user:password@example.com", "javascript:alert(1)"],
)
def test_provider_requires_https(url):
    with pytest.raises(ValueError):
        https_url(url)


async def test_geocoder_submit_cache_and_bad_feature(tmp_path, monkeypatch):
    geocoder = Geocoder(tmp_path / "geo.json")
    calls = []
    payload = {
        "features": [
            {"geometry": {"coordinates": [9.19, 45.46]}, "properties": {"name": "Milan", "country": "Italy"}},
            {"geometry": {"coordinates": [math.inf, 40]}},
        ]
    }

    def request(query):
        calls.append(query)
        return payload

    monkeypatch.setattr(geocoder, "_request", request)
    first = await geocoder.search("Milan")
    second = await geocoder.search("milan")
    assert first == second == [Location(45.46, 9.19, "Milan, Italy")]
    assert len(calls) == 1


def test_route_distance_and_interpolation():
    start = Location(0, 0, "Start")
    end = Location(0, 0.001, "End")
    route = straight_route(start, end)
    assert 110 < route.distance_m < 112
    cumulative = cumulative_distances(route.points)
    halfway = position_at_distance(route.points, cumulative, route.distance_m / 2)
    assert halfway.latitude == pytest.approx(0)
    assert halfway.longitude == pytest.approx(0.0005)
    assert distance_m(start, halfway) == pytest.approx(route.distance_m / 2, rel=0.01)
