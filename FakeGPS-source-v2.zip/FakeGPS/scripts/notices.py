"""Collect actual installed runtime-distribution licenses into the bundled notices."""

import json
import re
from importlib.metadata import PackageNotFoundError, distribution
from pathlib import Path

from packaging.requirements import Requirement

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "packaging" / "notices"
OUTPUT.mkdir(parents=True, exist_ok=True)
queue = ["fakegps-desktop"]
seen = set()
report = []
while queue:
    name = queue.pop()
    normalized = re.sub(r"[-_.]+", "-", name).lower()
    if normalized in seen:
        continue
    seen.add(normalized)
    try:
        dist = distribution(name)
    except PackageNotFoundError:
        continue
    for dependency in dist.requires or []:
        requirement = Requirement(dependency)
        if requirement.marker is None or requirement.marker.evaluate({"extra": ""}):
            queue.append(requirement.name)
    license_files = []
    for file in dist.files or []:
        if any(token in file.name.lower() for token in ("license", "copying", "notice")):
            path = Path(dist.locate_file(file))
            if path.is_file() and path.stat().st_size < 2_000_000:
                target = OUTPUT / normalized / str(file).replace("..", "_")
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(path.read_bytes())
                license_files.append(str(target.relative_to(OUTPUT)))
    report.append(
        {
            "name": dist.metadata["Name"],
            "version": dist.version,
            "license": dist.metadata.get("License-Expression") or dist.metadata.get("License"),
            "license_files": license_files,
        }
    )
(OUTPUT / "distributions.json").write_text(
    json.dumps(sorted(report, key=lambda x: x["name"]), indent=2), "utf-8"
)
print(f"Collected notices for {len(report)} runtime distributions")
