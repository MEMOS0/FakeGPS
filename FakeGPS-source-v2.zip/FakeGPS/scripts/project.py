"""Developer entry point. End users launch the built app, never this script."""

import argparse
import importlib.util
import os
import shutil
import subprocess
import sys
import venv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(args, **kwargs):
    subprocess.run([str(x) for x in args], cwd=ROOT, check=True, **kwargs)


def python_runtime():
    if all(
        importlib.util.find_spec(x)
        for x in ("PySide6", "pymobiledevice3", "pytest", "PyInstaller", "platformdirs")
    ):
        return sys.executable
    folder = ROOT / ".venv"
    executable = folder / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not executable.exists():
        venv.create(folder, with_pip=True)
    run([executable, "-m", "pip", "install", "-e", ".[dev]"])
    return str(executable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["dev", "test", "release", "portable"])
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()
    python = python_runtime()
    if args.command == "dev":
        run([python, "-m", "fakegps"] + (["--demo"] if args.demo else []))
        return
    env = dict(os.environ, QT_QPA_PLATFORM="offscreen")
    run([python, "-m", "pytest", "-q"], env=env)
    if args.command == "test":
        return
    run([python, "scripts/notices.py"])
    portable = args.command == "portable"
    run(
        [
            python,
            "-m",
            "PyInstaller",
            "--noconfirm",
            "--clean",
            "--distpath",
            "dist/portable" if portable else "dist",
            "packaging/FakeGPS.spec",
        ],
        env=dict(os.environ, FAKEGPS_PORTABLE="1" if portable else "0"),
    )
    output = ROOT / "release"
    output.mkdir(exist_ok=True)
    if portable:
        if sys.platform != "win32":
            print("Portable file built for this host OS. It is not a Windows .exe.")
        return
    if sys.platform == "win32":
        candidates = [shutil.which("ISCC"), r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe"]
        iscc = next((p for p in candidates if p and Path(p).exists()), None)
        if not iscc:
            raise SystemExit(
                "Application built in dist/FakeGPS. Installer needs Inno Setup 6 on the BUILD machine. Install it, then rerun release."
            )
        run([iscc, "packaging/windows.iss"])
        shutil.make_archive(str(output / "FakeGPS-0.1.0-windows-x64-folder"), "zip", ROOT / "dist", "FakeGPS")
    elif sys.platform == "darwin":
        run(
            [
                "hdiutil",
                "create",
                "-volname",
                "FakeGPS",
                "-srcfolder",
                "dist/FakeGPS.app",
                "-ov",
                "-format",
                "UDZO",
                output / "FakeGPS-0.1.0-macos.dmg",
            ]
        )
    else:
        shutil.make_archive(str(output / "FakeGPS-0.1.0-linux-validation"), "gztar", ROOT / "dist", "FakeGPS")
    print("Release outputs:", output)


if __name__ == "__main__":
    main()
