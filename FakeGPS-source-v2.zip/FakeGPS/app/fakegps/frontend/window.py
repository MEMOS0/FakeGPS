import logging
import time
from dataclasses import asdict

from PySide6.QtCore import Qt, QTimer, QUrl, Slot
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from ..controller import Controller, Snapshot
from ..errors import MESSAGES
from ..geocoding import Geocoder, https_url
from ..models import PRESETS, Location, State
from ..routing import DEFAULT_DRIVE_ENDPOINT, DEFAULT_WALK_ENDPOINT, Router, distance_m
from ..storage import Store
from .map_widget import MapWidget
from .worker import Runner

STYLE = """
QMainWindow, QDialog { background: #f6f7f2; }
QWidget { color: #223d30; font-family: 'Segoe UI', 'Helvetica Neue', sans-serif; font-size: 13px; }
QLabel#title { font-size: 30px; font-weight: 700; letter-spacing: -1px; }
QLabel#muted { color: #738077; }
QLabel#status { font-size: 18px; font-weight: 700; }
QWidget#deviceCard { background: white; border-radius: 12px; }
QPushButton { background: white; border: 1px solid #d9e1d7; border-radius: 7px; padding: 10px 15px; }
QPushButton:hover { background: #eaf0e7; }
QPushButton:disabled { color: #9ca59d; background: #eff1ec; }
QPushButton#primary { background: #185b40; color: white; border: 0; padding: 14px 30px; font-weight: 700; }
QPushButton#primary:hover { background: #257650; }
QPushButton#primary:disabled { background: #95a99a; }
QLineEdit, QComboBox, QDoubleSpinBox { background: white; border: 1px solid #d9e1d7; border-radius: 6px; padding: 9px; }
QCheckBox { spacing: 9px; padding: 8px 0; }
QCheckBox::indicator { width: 18px; height: 18px; }
QPlainTextEdit { background: #ffffff; border: 1px solid #d9e1d7; }
"""


def label(text, name=None):
    widget = QLabel(text)
    widget.setTextFormat(Qt.PlainText)
    widget.setWordWrap(True)
    if name:
        widget.setObjectName(name)
    return widget


class Window(QMainWindow):
    def __init__(self, backend, store: Store, demo=False, start_polling=True):
        super().__init__()
        self.setWindowTitle("FakeGPS" + (" · DEMO" if demo else ""))
        self.resize(1060, 860)
        self.setMinimumSize(760, 700)
        self.setStyleSheet(STYLE)
        self.store, self.demo, self.backend = store, demo, backend
        self.runner = Runner()
        self.controller = Controller(backend, self.runner.snapshot.emit)
        # A completed Future may invoke its callback synchronously on the GUI
        # thread. Always queue delivery so completion cannot overtake snapshots.
        self.runner.snapshot.connect(self.on_snapshot, Qt.QueuedConnection)
        self.runner.done.connect(self.on_done, Qt.QueuedConnection)
        self.runner.failed.connect(self.on_failure, Qt.QueuedConnection)
        self.jobs = set()
        self.devices = []
        self.current = Snapshot(State.IDLE, None, None, "Connect your iPhone to begin.")
        self.selected = PRESETS[0]
        self.route_start = None
        self.pending_route = None
        self.active_route = None
        self.close_after_route = False
        self._last_session_write = 0.0
        self.last_error = None
        self.closing = False
        self.allow_close = False
        self.wizard = None
        providers = store.data.get("providers", {})
        self.geocoder = Geocoder(
            store.path.parent / "geocoding.json", providers.get("search", "https://photon.komoot.io/api/")
        )
        self.router = Router(
            drive_endpoint=providers.get("drive_route", DEFAULT_DRIVE_ENDPOINT),
            walk_endpoint=providers.get("walk_route", DEFAULT_WALK_ENDPOINT),
            offline=demo,
        )
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(30, 22, 30, 22)
        layout.setSpacing(13)
        header = QHBoxLayout()
        header.addWidget(label("FakeGPS", "title"))
        tagline = label("  /  A different point of view", "muted")
        tagline.setWordWrap(False)
        header.addWidget(tagline)
        header.addStretch()
        settings = QPushButton("Settings")
        settings.clicked.connect(self.settings)
        header.addWidget(settings)
        layout.addLayout(header)
        if demo:
            layout.addWidget(label("DEMO MODE · All device actions are simulated. No iPhone is controlled."))
        self.recovery = label("")
        self.recovery.setVisible(bool(store.data.get("session")))
        if store.data.get("session"):
            self.recovery.setText(
                "Previous simulation recorded — current phone state is unknown. Reconnect the same iPhone to reset, or restart it and check Maps."
            )
        layout.addWidget(self.recovery)
        card = QWidget()
        card.setObjectName("deviceCard")
        row = QHBoxLayout(card)
        row.setContentsMargins(15, 12, 15, 12)
        row.addWidget(label("●  Device"))
        self.device_box = QComboBox()
        self.device_box.setMinimumWidth(260)
        self.device_box.currentIndexChanged.connect(self.device_changed)
        row.addWidget(self.device_box, 1)
        self.device_info = label("Searching…", "muted")
        self.device_info.setWordWrap(False)
        row.addWidget(self.device_info)
        self.refresh = QPushButton("Refresh")
        self.refresh.clicked.connect(self.discover)
        row.addWidget(self.refresh)
        layout.addWidget(card)
        search_row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search a place…  e.g. Duomo di Milano")
        self.search.returnPressed.connect(self.search_places)
        search_row.addWidget(self.search, 1)
        self.search_button = QPushButton("Search")
        self.search_button.clicked.connect(self.search_places)
        search_row.addWidget(self.search_button)
        layout.addLayout(search_row)
        self.results = QComboBox()
        self.results.hide()
        self.results.activated.connect(lambda index: self.pick(self.results.itemData(index)))
        layout.addWidget(self.results)
        map_row = QHBoxLayout()
        self.map = MapWidget(
            store.path.parent / "tiles",
            demo=demo,
            endpoint=providers.get("tiles", "https://tile.openstreetmap.org/{z}/{x}/{y}.png"),
        )
        self.map.picked.connect(self.pick)
        self.map.network_status.connect(lambda text: self.map_note.setText(text))
        map_row.addWidget(self.map, 1)
        zoom = QVBoxLayout()
        plus, minus = QPushButton("+"), QPushButton("−")
        plus.setFixedWidth(42)
        minus.setFixedWidth(42)
        plus.clicked.connect(lambda: self.map.change_zoom(1))
        minus.clicked.connect(lambda: self.map.change_zoom(-1))
        zoom.addWidget(plus)
        zoom.addWidget(minus)
        zoom.addStretch()
        map_row.addLayout(zoom)
        layout.addLayout(map_row, 1)
        self.map_note = label("", "muted")
        layout.addWidget(self.map_note)
        places = QHBoxLayout()
        self.home = QPushButton("Home")
        self.home.clicked.connect(self.go_home)
        places.addWidget(self.home)
        for location in PRESETS:
            button = QPushButton(location.label.split(",")[0])
            button.clicked.connect(lambda checked=False, loc=location: self.pick(loc))
            places.addWidget(button)
        self.saved = QComboBox()
        self.saved.setMinimumWidth(135)
        self.saved.activated.connect(self.saved_selected)
        places.addWidget(self.saved, 1)
        save = QPushButton("☆ Save")
        save.clicked.connect(self.save_favorite)
        places.addWidget(save)
        layout.addLayout(places)
        coords = QHBoxLayout()
        self.place = label(self.selected.label)
        coords.addWidget(self.place, 1)
        coords.addWidget(label("Latitude"))
        self.lat = QDoubleSpinBox()
        self.lat.setDecimals(6)
        self.lat.setRange(-90, 90)
        self.lat.setValue(self.selected.latitude)
        self.lat.editingFinished.connect(self.coordinates_changed)
        coords.addWidget(self.lat)
        coords.addWidget(label("Longitude"))
        self.lon = QDoubleSpinBox()
        self.lon.setDecimals(6)
        self.lon.setRange(-180, 180)
        self.lon.setValue(self.selected.longitude)
        self.lon.editingFinished.connect(self.coordinates_changed)
        coords.addWidget(self.lon)
        layout.addLayout(coords)
        movement = QHBoxLayout()
        movement.addWidget(label("Mode"))
        self.mode = QComboBox()
        self.mode.addItem("Teleport", "teleport")
        self.mode.addItem("Walk", "walk")
        self.mode.addItem("Drive", "drive")
        self.mode.currentIndexChanged.connect(self.mode_changed)
        movement.addWidget(self.mode)
        self.route_start_button = QPushButton("SET START")
        self.route_start_button.clicked.connect(self.capture_route_start)
        movement.addWidget(self.route_start_button)
        self.route_start_label = label("Start: not set", "muted")
        self.route_start_label.setMinimumWidth(180)
        movement.addWidget(self.route_start_label, 1)
        movement.addWidget(label("Speed"))
        self.speed = QSlider(Qt.Horizontal)
        self.speed.setMinimumWidth(130)
        self.speed.valueChanged.connect(self.speed_changed)
        movement.addWidget(self.speed)
        self.speed_label = label("5 km/h", "muted")
        self.speed_label.setMinimumWidth(68)
        movement.addWidget(self.speed_label)
        layout.addLayout(movement)
        actions = QHBoxLayout()
        self.set_button = QPushButton("SET LOCATION")
        self.set_button.setObjectName("primary")
        self.set_button.clicked.connect(self.set_location)
        actions.addWidget(self.set_button, 1)
        self.persistent = QCheckBox("CoreDevice · disconnect-safe")
        self.persistent.setChecked(True)
        self.persistent.setEnabled(False)
        self.persistent.setToolTip("Verified on iPhone 14 / iOS 18.7.8. Other devices are probed at runtime.")
        actions.addWidget(self.persistent)
        self.reset_button = QPushButton("RETURN TO REAL LOCATION")
        self.reset_button.clicked.connect(self.reset_location)
        actions.addWidget(self.reset_button)
        self.pause_button = QPushButton("PAUSE")
        self.pause_button.clicked.connect(self.toggle_pause)
        self.pause_button.hide()
        actions.addWidget(self.pause_button)
        self.stop_button = QPushButton("STOP")
        self.stop_button.clicked.connect(self.stop_route)
        self.stop_button.hide()
        actions.addWidget(self.stop_button)
        layout.addLayout(actions)
        self.status = label("CONNECT YOUR IPHONE", "status")
        layout.addWidget(self.status)
        self.detail = label("Connect → Unlock → Tap Trust → Enable Developer Mode", "muted")
        layout.addWidget(self.detail)
        self.active_place = label("")
        layout.addWidget(self.active_place)
        self.fix = QPushButton("Fix automatically")
        self.fix.hide()
        self.fix.clicked.connect(self.fix_problem)
        layout.addWidget(self.fix)
        self.refresh_saved()
        self.device_box.addItem("No iPhone Found", None)
        self.mode_changed()
        self.sync_buttons()
        self.poll = QTimer(self)
        self.poll.timeout.connect(self.poll_tick)
        if start_polling:
            self.poll.start(4000)
            QTimer.singleShot(100, self.discover)

    def job(self, name, coroutine):
        if name in self.jobs:
            coroutine.close()
            return
        self.jobs.add(name)
        self.sync_buttons()
        self.runner.submit(name, coroutine)

    def sync_buttons(self):
        route_running = "route" in self.jobs
        route_pending = "route_lookup" in self.jobs
        route_busy = route_running or route_pending
        mutation_busy = bool(
            self.jobs
            - {"discover", "health", "search", "route", "pause_route", "resume_route", "stop_route"}
        )
        self.set_button.setEnabled(
            bool(self.device_box.currentData()) and not mutation_busy and not route_busy
        )
        self.reset_button.setEnabled(
            bool(self.current.device or self.store.data.get("session"))
            and not mutation_busy
            and not route_busy
        )
        self.device_box.setEnabled(not mutation_busy and not route_busy and self.current.location is None)
        self.refresh.setEnabled("discover" not in self.jobs and not mutation_busy and not route_busy)
        self.search_button.setEnabled("search" not in self.jobs and not route_busy)
        self.search.setEnabled(not route_busy)
        self.results.setEnabled(not route_busy)
        self.map.setEnabled(not route_busy)
        self.fix.setEnabled(not mutation_busy)
        movement = self.mode.currentData() in {"walk", "drive"}
        self.route_start_button.setVisible(movement)
        self.route_start_label.setVisible(movement)
        self.speed.setVisible(movement)
        self.speed_label.setVisible(movement)
        self.pause_button.setVisible(route_running)
        self.stop_button.setVisible(route_running)
        control_busy = bool(self.jobs & {"pause_route", "resume_route", "stop_route"})
        self.pause_button.setEnabled(route_running and not control_busy)
        self.stop_button.setEnabled(route_running and not control_busy)
        self.mode.setEnabled(not mutation_busy and not route_busy)
        self.route_start_button.setEnabled(not mutation_busy and not route_busy)
        self.speed.setEnabled(not mutation_busy and not route_busy)

    def discover(self):
        if not self.closing:
            self.job("discover", self.backend.discover())

    def poll_tick(self):
        if self.jobs or self.closing:
            return
        self.job("health", self.controller.check_health())
        self.discover()

    @Slot(int)
    def device_changed(self, index):
        device = self.device_box.itemData(index)
        if device:
            self.device_info.setText(f"{device.model} · iOS {device.ios} · {device.transport}")
        else:
            self.device_info.setText("Connect and unlock your iPhone")
        if hasattr(self, "set_button"):
            self.sync_buttons()

    @Slot(object)
    def pick(self, location):
        if not isinstance(location, Location) or self.jobs & {"route", "route_lookup"}:
            return
        self.selected = location
        self.lat.setValue(location.latitude)
        self.lon.setValue(location.longitude)
        self.place.setText(location.label)
        self.map.choose(location)
        if self.mode.currentData() in {"walk", "drive"} and self.route_start:
            self.map.set_route((self.route_start, location), self.route_start)

    def coordinates_changed(self):
        if (self.lat.value(), self.lon.value()) != (self.selected.latitude, self.selected.longitude):
            self.pick(Location(self.lat.value(), self.lon.value()))

    def search_places(self):
        query = self.search.text().strip()
        if self.demo:
            matches = [
                p
                for p in PRESETS
                if query.casefold() in p.label.casefold() or ("duomo" in query.casefold() and p == PRESETS[0])
            ]
            self.show_results(matches)
        else:
            self.job("search", self.geocoder.search(query))

    def show_results(self, places):
        self.results.clear()
        for place in places:
            self.results.addItem(place.label, place)
        self.results.setVisible(bool(places))
        self.map_note.setText("" if places else "No places found. Try another name or enter coordinates.")
        if places:
            self.pick(places[0])

    def mode_changed(self):
        mode = self.mode.currentData()
        if mode == "teleport":
            self.set_button.setText("SET LOCATION")
            self.map.set_route(())
            self.map.set_current_location(None)
        else:
            self.set_button.setText("START WALK" if mode == "walk" else "START DRIVE")
            if mode == "walk":
                self.speed.setRange(1, 12)
                if not 1 <= self.speed.value() <= 12:
                    self.speed.setValue(5)
            else:
                self.speed.setRange(5, 180)
                if not 5 <= self.speed.value() <= 180:
                    self.speed.setValue(50)
            if self.current.location and not self.route_start:
                self.route_start = self.current.location
            self.update_route_start_label()
            if self.route_start:
                self.map.set_route((self.route_start, self.selected), self.route_start)
        self.speed_changed(self.speed.value())
        if hasattr(self, "pause_button"):
            self.sync_buttons()

    def speed_changed(self, value):
        self.speed_label.setText(f"{value} km/h")

    def update_route_start_label(self):
        if self.route_start:
            self.route_start_label.setText(
                f"Start: {self.route_start.label} · {self.route_start.latitude:.5f}, {self.route_start.longitude:.5f}"
            )
        else:
            self.route_start_label.setText("Start: not set")

    def capture_route_start(self):
        self.coordinates_changed()
        self.route_start = self.selected
        self.update_route_start_label()
        self.map.set_route((self.route_start, self.selected), self.route_start)
        self.map_note.setText("Start saved. Now choose the destination on the map or with search.")

    def set_location(self):
        device = self.device_box.currentData()
        if device:
            self.coordinates_changed()
            mode = self.mode.currentData()
            if mode == "teleport":
                self.job("set", self.controller.set_location(device, self.selected))
                return
            if self.route_start is None:
                self.map_note.setText("Choose the route start and press SET START first.")
                return
            if distance_m(self.route_start, self.selected) < 1:
                self.map_note.setText("Choose a destination at least 1 meter away from the start.")
                return
            self.pending_route = {
                "device": device,
                "start": self.route_start,
                "destination": self.selected,
                "mode": mode,
                "speed": float(self.speed.value()),
            }
            self.map_note.setText("Calculating route…")
            self.job("route_lookup", self.router.route(self.route_start, self.selected, mode))

    def toggle_pause(self):
        if self.current.state == State.ROUTE_PAUSED:
            self.job("resume_route", self.controller.resume_route())
        else:
            self.job("pause_route", self.controller.pause_route())

    def stop_route(self):
        self.job("stop_route", self.controller.stop_route())

    def reset_location(self):
        if self.current.device:
            self.job("reset", self.controller.reset())
            return
        recorded = self.store.data.get("session")
        device = self.device_box.currentData()
        if not recorded or not device or device.udid != recorded.get("udid"):
            self.show_error("reset")
            return

        async def recover():
            self.controller.device = device
            await self.controller.reset()

        self.job("reset", recover())

    @Slot(object)
    def on_snapshot(self, snapshot):
        self.current = snapshot
        names = {
            State.IDLE: "CONNECT YOUR IPHONE",
            State.PREPARING: "PREPARING CONNECTION…",
            State.ACTIVE: "SPOOFING ACTIVE",
            State.ROUTE_ACTIVE: "FAKE WALK ACTIVE" if snapshot.mode == "walk" else "FAKE DRIVE ACTIVE",
            State.ROUTE_PAUSED: "FAKE WALK PAUSED" if snapshot.mode == "walk" else "FAKE DRIVE PAUSED",
            State.PERSISTENCE_SETUP: "PERSISTENT MODE · SETUP",
            State.PERSISTENCE_UNVERIFIED: "PERSISTENT HANDOFF · UNVERIFIED",
            State.DISCONNECTED: "DEVICE DISCONNECTED",
            State.RESET_SENT: "RESET REQUEST SENT",
            State.ERROR: "ACTION NEEDED",
        }
        self.status.setText(names[snapshot.state])
        self.detail.setText(snapshot.detail)
        self.active_place.setText(
            f"{snapshot.location.label}  ·  {snapshot.location.latitude:.6f}, {snapshot.location.longitude:.6f}"
            if snapshot.location
            else ""
        )
        if snapshot.state in {State.ROUTE_ACTIVE, State.ROUTE_PAUSED} and snapshot.location:
            self.map.set_current_location(snapshot.location)
            self.pause_button.setText("RESUME" if snapshot.state == State.ROUTE_PAUSED else "PAUSE")
        if snapshot.location and snapshot.device:
            now = time.monotonic()
            if snapshot.state != State.ROUTE_ACTIVE or now - self._last_session_write >= 5:
                self.store.data["session"] = {
                    "udid": snapshot.device.udid,
                    "ios": snapshot.device.ios,
                    "location": asdict(snapshot.location),
                    "state": str(snapshot.state),
                    "hardware_verified": False,
                }
                self.store.save()
                self._last_session_write = now
        if snapshot.state == State.RESET_SENT:
            self.store.data["session"] = None
            self.store.save()
            self.recovery.hide()
            self.persistent.setChecked(False)
        if snapshot.error:
            self.show_error(snapshot.error)
        else:
            self.fix.hide()
        self.sync_buttons()

    @Slot(str, object)
    def on_done(self, name, result):
        self.jobs.discard(name)
        if name == "discover":
            previous = self.device_box.currentData()
            self.devices = result
            self.device_box.blockSignals(True)
            self.device_box.clear()
            if len(result) != 1:
                self.device_box.addItem("Choose an iPhone" if result else "No iPhone Found", None)
            for device in result:
                self.device_box.addItem(device.name, device)
            if previous:
                for index in range(self.device_box.count()):
                    item = self.device_box.itemData(index)
                    if item and item.udid == previous.udid:
                        self.device_box.setCurrentIndex(index)
                        break
            self.device_box.blockSignals(False)
            self.device_changed(self.device_box.currentIndex())
            if self.current.state == State.IDLE:
                self.status.setText(
                    "CHOOSE YOUR IPHONE"
                    if len(result) > 1
                    else ("READY TO PREPARE" if result else "NO IPHONE FOUND")
                )
                self.detail.setText(
                    "Select the iPhone you want to control."
                    if len(result) > 1
                    else "Connect → Unlock → Tap Trust → Enable Developer Mode"
                )
            if result:
                logging.getLogger("fakegps").info("DEVICE_DISCOVERED count=%d", len(result))
        elif name == "search":
            self.show_results(result)
        elif name == "route_lookup":
            if not self.pending_route:
                self.sync_buttons()
                return
            self.active_route = result
            self.map.set_route(result.points, self.pending_route["start"])
            if result.warning:
                self.map_note.setText(result.warning)
            else:
                self.map_note.setText(
                    f"Route ready · {result.distance_m / 1000:.2f} km · starting {self.pending_route['mode']} mode."
                )
            request = self.pending_route
            self.pending_route = None
            self.job(
                "route",
                self.controller.simulate_route(
                    request["device"], result.points, request["speed"], request["mode"]
                ),
            )
        elif name == "set":
            self.store.add("recent", self.current.location)
            self.refresh_saved()
        elif name == "route":
            if self.current.location:
                self.store.add("recent", self.current.location)
                self.refresh_saved()
                self.map.set_current_location(self.current.location)
                self.route_start = self.current.location
                self.update_route_start_label()
            self.pause_button.setText("PAUSE")
            if self.close_after_route:
                self.job("shutdown", self.controller.shutdown())
        elif name == "prepare":
            self.detail.setText("Device support prepared. Press SET LOCATION to continue.")
            self.fix.hide()
        elif name == "reveal":
            self.detail.setText(MESSAGES["developer"][1])
        elif name == "shutdown":
            self.map.shutdown()
            self.runner.stop()
            self.allow_close = True
            self.close()
        self.sync_buttons()

    @Slot(str, str)
    def on_failure(self, name, code):
        self.jobs.discard(name)
        if name == "search":
            self.map_note.setText("Search unavailable. Use coordinates or saved places and try again later.")
        elif name == "route_lookup":
            self.pending_route = None
            self.map_note.setText("Route could not be prepared. Pick a different start and destination.")
        elif name in {"pause_route", "resume_route", "stop_route"}:
            self.map_note.setText("Movement control did not complete. Try again.")
        elif name == "shutdown":
            self.map.shutdown()
            self.runner.stop()
            self.allow_close = True
            QMessageBox.information(self, "Check your iPhone", MESSAGES["reset"][1])
            self.close()
        elif name == "persist_finish" and self.wizard:
            self.wizard.note.setText(self.current.detail)
            self.wizard.confirm.setEnabled(True)
        elif name != "health":
            self.show_error(code)
            if name == "route" and self.close_after_route:
                self.job("shutdown", self.controller.shutdown())
        self.sync_buttons()

    def show_error(self, code):
        self.last_error = code
        title, detail = MESSAGES.get(code, MESSAGES["connection"])
        self.status.setText(title.upper())
        self.detail.setText(detail)
        self.fix.setText(
            {
                "ddi": "Prepare device support automatically",
                "developer": "Show Developer Mode on iPhone",
                "driver": "Open official Apple setup",
                "reset": "Show reset instructions",
            }.get(code, "Retry connection check")
        )
        self.fix.show()

    def fix_problem(self):
        device = self.device_box.currentData()
        if self.last_error == "driver":
            QDesktopServices.openUrl(QUrl("https://support.apple.com/108643"))
        elif self.last_error == "ddi" and device:
            self.detail.setText(
                "Downloading and preparing device support. Keep your iPhone connected and unlocked…"
            )
            self.job("prepare", self.backend.prepare_support(device))
        elif self.last_error == "developer" and device:
            self.job("reveal", self.backend.reveal_developer_mode(device))
        elif self.last_error == "reset":
            QMessageBox.information(
                self,
                "Return to real location",
                "Restart your iPhone and check the blue location dot in Apple Maps.\n\nAlternatively reconnect with Developer Mode on and press RETURN TO REAL LOCATION. The desktop cannot verify an offline phone.",
            )
        else:
            self.discover()

    def refresh_saved(self):
        self.saved.clear()
        self.saved.addItem("Saved & recent", None)
        for key in ("favorites", "recent"):
            for location in self.store.locations(key):
                self.saved.addItem(("☆ " if key == "favorites" else "↶ ") + location.label, location)

    def saved_selected(self, index):
        self.pick(self.saved.itemData(index))

    def save_favorite(self):
        name, ok = QInputDialog.getText(self, "Save a place", "Name", text=self.selected.label)
        if ok and name.strip():
            location = Location(self.selected.latitude, self.selected.longitude, name.strip()[:500])
            self.store.add("favorites", location)
            self.refresh_saved()

    def go_home(self):
        home = self.store.data.get("home")
        if home:
            try:
                self.pick(Location(**home))
                return
            except (TypeError, ValueError):
                pass
        answer = QMessageBox.question(
            self, "Save Home", "Save the selected point as Home? It stays on this computer."
        )
        if answer == QMessageBox.Yes:
            self.store.data["home"] = asdict(
                Location(self.selected.latitude, self.selected.longitude, "Home")
            )
            self.store.save()

    def settings(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Settings → Advanced")
        dialog.resize(620, 480)
        layout = QVBoxLayout(dialog)
        layout.addWidget(label("Advanced", "title"))
        layout.addWidget(
            label(
                "Map, search and routing providers receive the map areas, search text or route endpoints needed for the request. Saved places stay on this computer. Free public servers have limited capacity; use your own provider for a larger rollout."
            )
        )
        form = QFormLayout()
        tiles = QLineEdit(self.map.endpoint)
        search = QLineEdit(self.geocoder.endpoint)
        drive_route = QLineEdit(self.router.drive_endpoint)
        walk_route = QLineEdit(self.router.walk_endpoint)
        form.addRow("HTTPS tile URL", tiles)
        form.addRow("Photon API URL", search)
        form.addRow("Drive routing URL", drive_route)
        form.addRow("Walk routing URL", walk_route)
        layout.addLayout(form)
        compatibility_label = label(str(self.controller.compatibility()), "muted")
        layout.addWidget(compatibility_label)
        ddi = QPushButton("Use a local personalized DDI folder…")

        def local_ddi():
            device = self.device_box.currentData()
            if device:
                folder = QFileDialog.getExistingDirectory(
                    dialog, "Select folder containing Image.dmg and BuildManifest.plist"
                )
                if folder:
                    self.job("prepare", self.backend.prepare_support(device, folder))
                    dialog.accept()

        ddi.clicked.connect(local_ddi)
        layout.addWidget(ddi)
        logs = QPushButton("Show Logs")

        def show_logs():
            log_dialog = QDialog(dialog)
            log_dialog.resize(740, 440)
            log_layout = QVBoxLayout(log_dialog)
            text = QPlainTextEdit()
            text.setReadOnly(True)
            path = self.store.path.parent / "logs" / "fakegps.log"
            text.setPlainText(path.read_text("utf-8")[-150000:] if path.exists() else "No logs yet.")
            log_layout.addWidget(text)
            log_dialog.exec()

        logs.clicked.connect(show_logs)
        layout.addWidget(logs)
        attribution = QPushButton("OpenStreetMap attribution & usage policies")
        attribution.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl("https://www.openstreetmap.org/copyright"))
        )
        layout.addWidget(attribution)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)

        def save():
            try:
                tile_url, search_url = https_url(tiles.text()), https_url(search.text())
                drive_url, walk_url = https_url(drive_route.text()), https_url(walk_route.text())
                if not all(token in tile_url for token in ("{z}", "{x}", "{y}")):
                    raise ValueError("Tile URL needs {z}, {x} and {y} placeholders.")
                # Validate formatting before saving arbitrary user input.
                tile_url.format(z=1, x=1, y=1)
                self.store.data["providers"] = {
                    "tiles": tile_url,
                    "search": search_url,
                    "drive_route": drive_url.rstrip("/"),
                    "walk_route": walk_url.rstrip("/"),
                }
                self.store.save()
                QMessageBox.information(dialog, "Saved", "Provider changes apply when FakeGPS is reopened.")
                dialog.accept()
            except (ValueError, KeyError) as error:
                QMessageBox.information(dialog, "Check provider URL", str(error))

        buttons.accepted.connect(save)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        dialog.exec()

    def closeEvent(self, event):
        if self.allow_close:
            event.accept()
            return
        event.ignore()
        if self.closing:
            return
        if "route" in self.jobs:
            if QMessageBox.question(
                self,
                "Stop movement and close?",
                "Fake Walk/Drive is active. Stop movement at the current simulated point and close FakeGPS?",
            ) != QMessageBox.Yes:
                return
            self.closing = True
            self.close_after_route = True
            self.poll.stop()
            self.job("stop_route", self.controller.stop_route())
            return
        if self.jobs - {"discover", "health", "search"}:
            QMessageBox.information(
                self,
                "Finishing an action",
                "Please wait for the current device action to finish, then close FakeGPS.",
            )
            return
        if self.current.location:
            message = "FakeGPS will close without clearing the CoreDevice location. Use RETURN TO REAL LOCATION when you want to reset. Close?"
            if QMessageBox.question(self, "Close FakeGPS", message) != QMessageBox.Yes:
                return
        self.closing = True
        self.poll.stop()
        self.job("shutdown", self.controller.shutdown())
