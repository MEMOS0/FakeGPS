"""Native raster slippy map. No JavaScript, WebView, localhost or device privileges."""

import hashlib
import math
import time
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QPixmap, QPolygonF
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest
from PySide6.QtWidgets import QWidget

from ..models import Location

MAX_LAT = 85.05112878


def project(lat, lon, zoom):
    size = 256 * 2**zoom
    lat = max(-MAX_LAT, min(MAX_LAT, lat))
    return ((lon + 180) / 360 * size, (1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * size)


def unproject(x, y, zoom):
    size = 256 * 2**zoom
    y = max(0, min(size, y))
    return (math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / size)))), (x / size * 360) % 360 - 180)


class MapWidget(QWidget):
    picked = Signal(object)
    network_status = Signal(str)

    def __init__(self, cache: Path, demo=False, endpoint="https://tile.openstreetmap.org/{z}/{x}/{y}.png"):
        super().__init__()
        self.setMinimumHeight(280)
        self.setMouseTracking(True)
        self.setCursor(Qt.OpenHandCursor)
        self.cache = cache
        cache.mkdir(parents=True, exist_ok=True)
        self.demo = demo
        self.endpoint = endpoint
        self.zoom = 12
        self.center = project(45.4642, 9.19, self.zoom)
        self.selected = Location(45.4642, 9.19, "Milan, Italy")
        self.route_points = ()
        self.route_start = None
        self.current_location = None
        self.images = {}
        self.pending = {}
        self.failed_until = {}
        self.network = QNetworkAccessManager(self)
        self.drag_start = None
        self.drag_origin = None
        self.dragged = False
        self.fetch_timer = QTimer(self)
        self.fetch_timer.setSingleShot(True)
        self.fetch_timer.timeout.connect(self.load_visible)

    def tile_path(self, key):
        identity = self.endpoint + "/" + "/".join(map(str, key))
        return self.cache / (hashlib.sha256(identity.encode()).hexdigest() + ".png")

    def visible(self):
        left = self.center[0] - self.width() / 2
        top = self.center[1] - self.height() / 2
        size = 2**self.zoom
        for y in range(math.floor(top / 256), math.floor((top + self.height()) / 256) + 1):
            if not 0 <= y < size:
                continue
            for x in range(math.floor(left / 256), math.floor((left + self.width()) / 256) + 1):
                yield (self.zoom, x % size, y), x * 256 - left, y * 256 - top

    def load_visible(self):
        if self.demo or not self.isVisible():
            return
        for key, _, _ in self.visible():
            if key in self.images or key in self.pending or self.failed_until.get(key, 0) > time.time():
                continue
            path = self.tile_path(key)
            if path.exists() and time.time() - path.stat().st_mtime < 7 * 86400:
                image = QPixmap(str(path))
                if not image.isNull():
                    self.images[key] = image
                    continue
            if len(self.pending) >= 4:
                break
            z, x, y = key
            request = QNetworkRequest(QUrl(self.endpoint.format(z=z, x=x, y=y)))
            request.setRawHeader(b"User-Agent", b"FakeGPS-Desktop/0.2.1")
            request.setTransferTimeout(10000)
            reply = self.network.get(request)
            self.pending[key] = reply
            reply.finished.connect(lambda k=key, r=reply: self.tile_ready(k, r))
        self.update()

    def tile_ready(self, key, reply):
        self.pending.pop(key, None)
        data = bytes(reply.readAll())
        image = QPixmap()
        if reply.error() == QNetworkReply.NoError and len(data) < 2_000_000 and image.loadFromData(data):
            self.images[key] = image
            self.tile_path(key).write_bytes(data)
            # Bound memory; disk entries retain at least the policy's seven days.
            if len(self.images) > 160:
                self.images.pop(next(iter(self.images)))
            self.network_status.emit("")
        else:
            self.failed_until[key] = time.time() + 30
            self.network_status.emit("Map unavailable — coordinates and saved places still work.")
        reply.deleteLater()
        self.update()
        self.fetch_timer.start(80)

    def choose(self, location, center=True):
        self.selected = location
        if center:
            self.center = project(location.latitude, location.longitude, self.zoom)
        self.update()
        self.fetch_timer.start(120)

    def set_route(self, points=(), start=None):
        self.route_points = tuple(points or ())
        self.route_start = start
        self.update()

    def set_current_location(self, location):
        self.current_location = location
        self.update()

    def _screen_point(self, location):
        mx, my = project(location.latitude, location.longitude, self.zoom)
        world = 256 * 2**self.zoom
        dx = (mx - self.center[0] + world / 2) % world - world / 2
        return QPointF(dx + self.width() / 2, my - self.center[1] + self.height() / 2)

    def change_zoom(self, delta, anchor=None):
        new = min(18, max(2, self.zoom + delta))
        anchor = anchor or QPointF(self.width() / 2, self.height() / 2)
        offset = (anchor.x() - self.width() / 2, anchor.y() - self.height() / 2)
        factor = 2 ** (new - self.zoom)
        self.center = (
            (self.center[0] + offset[0]) * factor - offset[0],
            (self.center[1] + offset[1]) * factor - offset[1],
        )
        self.zoom = new
        self.update()
        self.fetch_timer.start(160)

    def wheelEvent(self, event):
        self.change_zoom(1 if event.angleDelta().y() > 0 else -1, event.position())
        event.accept()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_start, self.drag_origin = event.position(), self.center
            self.dragged = False
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, event):
        if self.drag_start is not None:
            delta = event.position() - self.drag_start
            self.dragged |= delta.manhattanLength() > 4
            size = 256 * 2**self.zoom
            self.center = (
                (self.drag_origin[0] - delta.x()) % size,
                max(0, min(size, self.drag_origin[1] - delta.y())),
            )
            self.update()

    def mouseReleaseEvent(self, event):
        if self.drag_start is None:
            return
        if not self.dragged:
            lat, lon = unproject(
                self.center[0] + event.position().x() - self.width() / 2,
                self.center[1] + event.position().y() - self.height() / 2,
                self.zoom,
            )
            location = Location(lat, lon)
            self.choose(location, center=False)
            self.picked.emit(location)
        self.drag_start = None
        self.setCursor(Qt.OpenHandCursor)
        self.fetch_timer.start(150)

    def resizeEvent(self, event):
        self.fetch_timer.start(150)

    def showEvent(self, event):
        self.fetch_timer.start(150)

    def paintEvent(self, event):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#e9eee7"))
        for key, x, y in self.visible():
            if key in self.images:
                p.drawPixmap(int(x), int(y), self.images[key])
            else:
                p.setPen(QPen(QColor("#d8dfd4"), 1))
                p.drawRect(QRectF(x, y, 256, 256))
        if self.demo:
            p.setPen(QPen(QColor("#ffffff"), 12))
            for x in range(-200, self.width() + 250, 95):
                p.drawLine(x, 0, x + 160, self.height())
            for y in range(35, self.height(), 85):
                p.drawLine(0, y, self.width(), y + 35)
            p.setPen(QColor("#536957"))
            p.drawText(20, 30, "DEMO MAP · illustrative grid, no live map data")
        p.setRenderHint(QPainter.Antialiasing)
        if len(self.route_points) >= 2:
            polygon = QPolygonF([self._screen_point(item) for item in self.route_points])
            p.setPen(QPen(QColor("#2f7f5d"), 4, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            p.setBrush(Qt.NoBrush)
            p.drawPolyline(polygon)
        if self.route_start:
            start_point = self._screen_point(self.route_start)
            p.setPen(QPen(QColor("#ffffff"), 2))
            p.setBrush(QColor("#344b40"))
            p.drawEllipse(start_point, 7, 7)

        point = self._screen_point(self.selected)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(23, 90, 60, 35))
        p.drawEllipse(point, 26, 26)
        p.setBrush(QColor("#165d40"))
        p.drawEllipse(point, 11, 11)
        p.setPen(QPen(Qt.white, 3))
        p.drawEllipse(point, 11, 11)
        if self.current_location:
            current = self._screen_point(self.current_location)
            p.setPen(QPen(QColor("#ffffff"), 3))
            p.setBrush(QColor("#1d6fa5"))
            p.drawEllipse(current, 8, 8)
        attribution = "© OpenStreetMap contributors" if not self.demo else "DEMO · no iPhone is controlled"
        rect = QRectF(self.width() - 270, self.height() - 28, 270, 28)
        p.fillRect(rect, QColor(255, 255, 255, 225))
        p.setPen(QColor("#31453b"))
        p.drawText(rect, Qt.AlignCenter, attribution)

    def shutdown(self):
        self.fetch_timer.stop()
        for reply in list(self.pending.values()):
            reply.finished.disconnect()
            reply.abort()
            reply.deleteLater()
        self.pending.clear()
