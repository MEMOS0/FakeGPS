import asyncio
import threading

from PySide6.QtCore import QObject, Signal

from ..errors import classify


class Runner(QObject):
    done = Signal(str, object)
    failed = Signal(str, str)
    snapshot = Signal(object)

    def __init__(self):
        super().__init__()
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self.run, name="FakeGPS device loop", daemon=True)
        self.thread.start()

    def run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()
        pending = asyncio.all_tasks(self.loop)
        for task in pending:
            task.cancel()
        self.loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        self.loop.run_until_complete(self.loop.shutdown_asyncgens())
        self.loop.close()

    def submit(self, name, coroutine):
        future = asyncio.run_coroutine_threadsafe(coroutine, self.loop)

        def finished(result):
            try:
                self.done.emit(name, result.result())
            except Exception as error:
                self.failed.emit(name, classify(error).code)

        future.add_done_callback(finished)
        return future

    def stop(self):
        if not self.thread.is_alive() or self.loop.is_closed():
            return
        self.loop.call_soon_threadsafe(self.loop.stop)
        self.thread.join(timeout=3)
