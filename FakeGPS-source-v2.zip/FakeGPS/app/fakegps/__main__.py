import argparse
import logging
import sys
from logging.handlers import RotatingFileHandler

from PySide6.QtCore import QLockFile, QTimer
from PySide6.QtWidgets import QApplication, QMessageBox

from .storage import Store, data_dir


def main():
    parser = argparse.ArgumentParser(description="FakeGPS desktop")
    parser.add_argument(
        "--demo", action="store_true", help="Explicit fake device and offline illustrative map"
    )
    parser.add_argument("--smoke-test", action="store_true", help="Offline GUI launch check; requires --demo")
    parser.add_argument("--screenshot", help="Developer screenshot path; requires --demo")
    parser.add_argument("--check-backend", action="store_true", help="Developer import check; no device access")
    args = parser.parse_args()
    if args.check_backend:
        import importlib
        from importlib.metadata import version
        for module in (
            "pymobiledevice3.usbmux", "pymobiledevice3.lockdown",
            "pymobiledevice3.remote.rsd_tunnel", "pymobiledevice3.remote.userspace_tunnel",
            "pymobiledevice3.services.dvt.instruments.dvt_provider",
            "pymobiledevice3.services.dvt.instruments.location_simulation",
            "pymobiledevice3.services.mobile_image_mounter", "pymobiledevice3.services.amfi",
        ):
            importlib.import_module(module)
        if version("pymobiledevice3") != "11.3.1":
            raise RuntimeError("Unexpected device-library version")
        return 0
    if (args.smoke_test or args.screenshot) and not args.demo:
        parser.error("Automation options require --demo; no implicit real-device actions.")
    app = QApplication(sys.argv)
    app.setApplicationName("FakeGPS")
    folder = data_dir()
    if args.demo:
        folder = folder / "demo"  # demo must not overwrite real-device recovery journal
        folder.mkdir(parents=True, exist_ok=True)
    lock = QLockFile(str(folder / "app.lock"))
    lock.setStaleLockTime(0)
    if not lock.tryLock(100):
        QMessageBox.information(None, "FakeGPS", "FakeGPS is already running for this user.")
        return 1
    logs = folder / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(logs / "fakegps.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    logger = logging.getLogger("fakegps")
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)
    # Upstream protocol logs may contain pairing material; don't collect those by default.
    logging.getLogger("pymobiledevice3").setLevel(logging.CRITICAL)
    if args.demo:
        from .backend.mock import MockBackend

        backend = MockBackend()
    else:
        from .backend.device import DeviceBackend

        backend = DeviceBackend()
    from .frontend.window import Window

    window = Window(backend, Store(folder / "settings.json"), demo=args.demo)
    window.show()
    if args.screenshot:
        QTimer.singleShot(900, lambda: window.grab().save(args.screenshot))
    if args.smoke_test:
        QTimer.singleShot(1400, window.close)
    result = app.exec()
    lock.unlock()
    return result


if __name__ == "__main__":
    raise SystemExit(main())
