import asyncio
import logging
from dataclasses import dataclass

from .compatibility import compatibility
from .errors import UserError, classify
from .models import Backend, Device, Location, State

log = logging.getLogger("fakegps.controller")


@dataclass(frozen=True)
class Snapshot:
    state: State
    device: Device | None
    location: Location | None
    detail: str
    error: str | None = None


class Controller:
    """Serialized state machine; physical location is never inferred from a button click."""

    def __init__(self, backend: Backend, notify=lambda snapshot: None):
        self.backend = backend
        self.notify = notify
        self.state = State.IDLE
        self.device = None
        self.location = None
        self.detail = "Connect your iPhone to begin."
        self.error = None
        self.lock = asyncio.Lock()

    def emit(self, state, detail, error=None):
        self.state, self.detail, self.error = state, detail, error
        self.notify(Snapshot(state, self.device, self.location, detail, error))

    async def set_location(self, device: Device, location: Location):
        async with self.lock:
            if self.location is not None and self.device is not None and self.device.udid != device.udid:
                raise UserError("reset")  # don't abandon another phone's simulation
            self.emit(State.PREPARING, "Preparing your iPhone…")
            try:
                self.device = await self.backend.connect(device)
                self.location = location
                self.emit(State.PREPARING, "Setting location through CoreDevice…")
                await self.backend.set_location(location)
                # CoreDevice set is device-side. Closing the temporary RSD tunnel
                # is part of the verified workflow, not a reset operation.
                await self.backend.release()
                self.location = location
                log.info("LOCATION_SET")
                self.emit(
                    State.ACTIVE,
                    "Location active — you may disconnect your iPhone and close FakeGPS.",
                )
            except Exception as error:
                try:
                    await self.backend.release()
                except Exception:
                    pass
                log.warning("SET_FAILED %s", type(error).__name__)
                self.emit(
                    State.ERROR,
                    "Location could not be set. Any previous simulation may still exist.",
                    classify(error).code,
                )
                raise classify(error) from error

    async def reset(self):
        async with self.lock:
            if self.device is None:
                raise UserError("no_device")
            try:
                await self.backend.connect(self.device)
                await self.backend.clear_location()
                log.info("LOCATION_CLEARED")
                self.location = None
                self.emit(
                    State.RESET_SENT,
                    "Stop request sent. Confirm your real location in Apple Maps; allow time for a fresh GPS fix.",
                )
                await self.backend.release()
            except Exception as error:
                self.emit(
                    State.ERROR,
                    "Reset not confirmed. Restart your iPhone, or reconnect with Developer Mode on.",
                    "reset",
                )
                raise UserError("reset") from error

    async def check_health(self):
        if getattr(self.backend, "ephemeral_location_session", False):
            return
        if self.lock.locked() or self.state != State.ACTIVE:
            return
        async with self.lock:
            if not await self.backend.healthy():
                log.info("DEVICE_DISCONNECTED")
                self.emit(
                    State.DISCONNECTED,
                    "Connection lost. The phone's current location is unknown. Reconnect to reset or restart iPhone.",
                    "disconnected",
                )
                try:
                    await self.backend.release()
                except Exception:
                    pass

    async def shutdown(self):
        async with self.lock:
            # Never turn a successful CoreDevice location back into real GPS just
            # because the desktop app is closed. Reset is an explicit action.
            await self.backend.release()

    def compatibility(self):
        return compatibility(self.device.ios if self.device else "Unknown")
