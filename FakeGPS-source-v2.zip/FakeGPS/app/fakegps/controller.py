import asyncio
import logging
from dataclasses import dataclass

from .compatibility import compatibility
from .errors import UserError, classify
from .models import Backend, Device, Location, State

log = logging.getLogger("fakegps.controller")


@dataclass(frozen=True)
class Snapshot:
    state: State
    device: Device | None
    location: Location | None
    detail: str
    error: str | None = None


class Controller:
    """Serialized state machine; physical location is never inferred from a button click."""

    def __init__(self, backend: Backend, notify=lambda snapshot: None):
        self.backend = backend
        self.notify = notify
        self.state = State.IDLE
        self.device = None
        self.location = None
        self.detail = "Connect your iPhone to begin."
        self.error = None
        self.lock = asyncio.Lock()

    def emit(self, state, detail, error=None):
        self.state, self.detail, self.error = state, detail, error
        self.notify(Snapshot(state, self.device, self.location, detail, error))

    async def set_location(self, device: Device, location: Location):
        async with self.lock:
            if self.state in (State.PERSISTENCE_SETUP, State.PERSISTENCE_UNVERIFIED):
                raise UserError("reset")
            if self.location is not None and self.device is not None and self.device.udid != device.udid:
                raise UserError("reset")  # don't abandon another phone's simulation
            self.emit(State.PREPARING, "Preparing your iPhone…")
            try:
                self.device = await self.backend.connect(device)
                self.location = location
                self.emit(State.PREPARING, "Sending location request… Its outcome is not yet known.")
                await self.backend.set_location(location)
                self.location = location
                log.info("LOCATION_SET")
                self.emit(
                    State.ACTIVE,
                    "Simulation request accepted. Check the blue location dot in Apple Maps on your iPhone.",
                )
            except Exception as error:
                log.warning("SET_FAILED %s", type(error).__name__)
                self.emit(
                    State.ERROR,
                    "Location could not be set. Any previous simulation may still exist.",
                    classify(error).code,
                )
                raise classify(error) from error

    async def start_persistence(self):
        async with self.lock:
            if self.state != State.ACTIVE:
                raise UserError("connection")
            log.info("PERSISTENCE_FLOW_STARTED")
            self.emit(
                State.PERSISTENCE_SETUP,
                "Confirm the selected location in Apple Maps before changing Developer Mode.",
            )

    async def cancel_persistence(self):
        async with self.lock:
            # After a possible toggle, do not revert to a misleading ACTIVE state.
            if self.state == State.PERSISTENCE_SETUP:
                mode = await self.backend.developer_mode()
                if mode is True:
                    self.emit(
                        State.ACTIVE, "Keep Developer Mode on. If you changed it, reset and check Maps."
                    )
                else:
                    self.emit(
                        State.ERROR,
                        "Developer Mode state changed or is unknown. Reset and check Apple Maps.",
                        "reset",
                    )

    async def finish_persistence(self, maps_confirmed: bool, toggle_confirmed: bool):
        async with self.lock:
            if self.state != State.PERSISTENCE_SETUP or not maps_confirmed or not toggle_confirmed:
                raise UserError("persistence")
            status = await self.backend.developer_mode()
            if status is True:
                self.emit(
                    State.PERSISTENCE_SETUP,
                    "Developer Mode still reports ON. Its displayed switch may not be applied yet.",
                )
                raise UserError("persistence")
            suffix = (
                "Developer Mode reports OFF."
                if status is False
                else "Developer Mode state could not be read."
            )
            # Never clear here. Do not keep reapplying after a deliberate detach.
            self.emit(
                State.PERSISTENCE_UNVERIFIED,
                suffix
                + " Persistence is unverified. Disconnect and check Maps on the phone. Restart iPhone to recover real location.",
            )
            try:
                await self.backend.release()
            except Exception as error:
                log.warning("DETACH_CLEANUP_FAILED %s", type(error).__name__)
            log.info("PERSISTENCE_HANDOFF_UNVERIFIED")

    async def reset(self):
        async with self.lock:
            if self.device is None:
                raise UserError("no_device")
            try:
                await self.backend.connect(self.device)
                await self.backend.clear_location()
                log.info("LOCATION_CLEARED")
                self.location = None
                self.emit(
                    State.RESET_SENT,
                    "Stop request sent. Confirm your real location in Apple Maps; allow time for a fresh GPS fix.",
                )
                await self.backend.release()
            except Exception as error:
                self.emit(
                    State.ERROR,
                    "Reset not confirmed. Restart your iPhone, or reconnect with Developer Mode on.",
                    "reset",
                )
                raise UserError("reset") from error

    async def check_health(self):
        if self.lock.locked() or self.state != State.ACTIVE:
            return
        async with self.lock:
            if not await self.backend.healthy():
                log.info("DEVICE_DISCONNECTED")
                self.emit(
                    State.DISCONNECTED,
                    "Connection lost. The phone's current location is unknown. Reconnect to reset or restart iPhone.",
                    "disconnected",
                )
                try:
                    await self.backend.release()
                except Exception:
                    pass

    async def shutdown(self):
        async with self.lock:
            # Intentional experimental handoff must not send stopLocationSimulation.
            if self.location and self.state != State.PERSISTENCE_UNVERIFIED:
                try:
                    await self.backend.clear_location()
                    self.location = None
                    log.info("LOCATION_CLEARED")
                    self.emit(
                        State.RESET_SENT,
                        "Stop request sent while closing; confirm your real location on the phone.",
                    )
                except Exception as error:
                    log.warning("SHUTDOWN_RESET_UNCONFIRMED %s", type(error).__name__)
                    self.emit(State.ERROR, "Restart your iPhone if simulation remains active.", "reset")
            await self.backend.release()

    def compatibility(self):
        return compatibility(self.device.ios if self.device else "Unknown")
