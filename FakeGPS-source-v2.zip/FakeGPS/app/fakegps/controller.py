import asyncio
import logging
import math
from dataclasses import dataclass

from .compatibility import compatibility
from .errors import UserError, classify
from .models import Backend, Device, Location, State
from .routing import cumulative_distances, position_at_distance

log = logging.getLogger("fakegps.controller")


@dataclass(frozen=True)
class Snapshot:
    state: State
    device: Device | None
    location: Location | None
    detail: str
    error: str | None = None
    mode: str | None = None
    progress: float | None = None


class Controller:
    """Serialized state machine; physical location is never inferred from a button click."""

    def __init__(self, backend: Backend, notify=lambda snapshot: None):
        self.backend = backend
        self.notify = notify
        self.state = State.IDLE
        self.device = None
        self.location = None
        self.detail = "Connect your iPhone to begin."
        self.error = None
        self.lock = asyncio.Lock()
        self.route_paused = False
        self.route_stop_requested = False
        self.route_mode = None
        self._route_wake: asyncio.Event | None = None

    def emit(self, state, detail, error=None, mode=None, progress=None):
        self.state, self.detail, self.error = state, detail, error
        self.notify(Snapshot(state, self.device, self.location, detail, error, mode, progress))

    async def set_location(self, device: Device, location: Location):
        async with self.lock:
            if self.location is not None and self.device is not None and self.device.udid != device.udid:
                raise UserError("reset")  # don't abandon another phone's simulation
            self.emit(State.PREPARING, "Preparing your iPhone…")
            try:
                self.device = await self.backend.connect(device)
                self.location = location
                self.emit(State.PREPARING, "Setting location through CoreDevice…")
                await self.backend.set_location(location)
                # CoreDevice set is device-side. Closing the temporary RSD tunnel
                # is part of the verified workflow, not a reset operation.
                await self.backend.release()
                self.location = location
                log.info("LOCATION_SET")
                self.emit(
                    State.ACTIVE,
                    "Location active — you may disconnect your iPhone and close FakeGPS.",
                )
            except Exception as error:
                try:
                    await self.backend.release()
                except Exception:
                    pass
                log.warning("SET_FAILED %s", type(error).__name__)
                self.emit(
                    State.ERROR,
                    "Location could not be set. Any previous simulation may still exist.",
                    classify(error).code,
                )
                raise classify(error) from error

    async def reset(self):
        async with self.lock:
            if self.device is None:
                raise UserError("no_device")
            try:
                await self.backend.connect(self.device)
                await self.backend.clear_location()
                log.info("LOCATION_CLEARED")
                self.location = None
                self.emit(
                    State.RESET_SENT,
                    "Stop request sent. Confirm your real location in Apple Maps; allow time for a fresh GPS fix.",
                )
                await self.backend.release()
            except Exception as error:
                self.emit(
                    State.ERROR,
                    "Reset not confirmed. Restart your iPhone, or reconnect with Developer Mode on.",
                    "reset",
                )
                raise UserError("reset") from error

    async def simulate_route(
        self,
        device: Device,
        points,
        speed_kmh: float,
        mode: str,
        tick_seconds: float = 0.5,
    ):
        """Keep one CoreDevice session open while moving along a prepared route."""
        if mode not in {"walk", "drive"}:
            raise ValueError("Unsupported movement mode.")
        if not math.isfinite(speed_kmh) or not 0.5 <= speed_kmh <= 250:
            raise ValueError("Speed is outside the supported range.")
        points = tuple(points)
        if len(points) < 2:
            raise ValueError("A route needs at least two points.")
        cumulative = cumulative_distances(points)
        total = cumulative[-1]
        if total < 0.5:
            raise ValueError("Route is too short.")
        speed_mps = speed_kmh / 3.6
        tick_seconds = min(2.0, max(0.1, float(tick_seconds)))
        action = "Walking" if mode == "walk" else "Driving"

        async with self.lock:
            if self.location is not None and self.device is not None and self.device.udid != device.udid:
                raise UserError("reset")
            self.route_paused = False
            self.route_stop_requested = False
            self.route_mode = mode
            self._route_wake = asyncio.Event()
            self.emit(State.PREPARING, f"Preparing {action.lower()} route through CoreDevice…", mode=mode)
            traveled = 0.0
            try:
                self.device = await self.backend.connect(device)
                loop = asyncio.get_running_loop()
                last_advance_at = loop.time()
                first_update = True
                while True:
                    if self.route_stop_requested:
                        break
                    if self.route_paused:
                        progress = min(1.0, traveled / total)
                        if self.state != State.ROUTE_PAUSED:
                            self.emit(
                                State.ROUTE_PAUSED,
                                f"{action} paused · location remains at the current point.",
                                mode=mode,
                                progress=progress,
                            )
                        # Do not busy-poll while paused. Resume/Stop wake this
                        # wait immediately, and paused wall time never advances
                        # the simulated distance.
                        wake = self._route_wake
                        if wake is not None:
                            wake.clear()
                            await wake.wait()
                        last_advance_at = loop.time()
                        first_update = True
                        continue

                    now = loop.time()
                    if not first_update:
                        # Advance from actual elapsed active time rather than
                        # assuming CoreDevice calls are instantaneous. This
                        # keeps the requested km/h accurate when USB/tunnel
                        # latency varies.
                        traveled = min(total, traveled + speed_mps * max(0.0, now - last_advance_at))
                    first_update = False
                    last_advance_at = now

                    location = position_at_distance(points, cumulative, traveled, f"{action} route")
                    await self.backend.set_location(location)
                    self.location = location
                    remaining = max(0.0, total - traveled)
                    eta = remaining / speed_mps
                    progress = min(1.0, traveled / total)
                    self.emit(
                        State.ROUTE_ACTIVE,
                        (
                            f"{action} · {speed_kmh:.1f} km/h · "
                            f"{remaining / 1000:.2f} km remaining · ETA {self._format_eta(eta)}"
                        ),
                        mode=mode,
                        progress=progress,
                    )
                    if traveled >= total:
                        break
                    # A pause/stop can arrive while the CoreDevice invoke is
                    # awaiting I/O. Re-check before clearing the wake event so
                    # that control requests are never lost.
                    if self.route_stop_requested or self.route_paused:
                        continue

                    wake = self._route_wake
                    if wake is None:
                        await asyncio.sleep(tick_seconds)
                    else:
                        wake.clear()
                        try:
                            await asyncio.wait_for(wake.wait(), tick_seconds)
                        except TimeoutError:
                            pass

                await self.backend.release()
                if self.route_stop_requested:
                    self.emit(
                        State.ACTIVE,
                        "Movement stopped — the current simulated location remains active.",
                    )
                else:
                    destination = points[-1]
                    self.location = Location(destination.latitude, destination.longitude, destination.label)
                    self.emit(
                        State.ACTIVE,
                        f"{action} complete — destination remains active and disconnect-safe.",
                    )
                return self.location
            except Exception as error:
                try:
                    await self.backend.release()
                except Exception:
                    pass
                log.warning("ROUTE_FAILED %s", type(error).__name__)
                self.emit(
                    State.ERROR,
                    "Movement simulation stopped because the CoreDevice session failed.",
                    classify(error).code,
                )
                raise classify(error) from error
            finally:
                self.route_paused = False
                self.route_stop_requested = False
                self.route_mode = None
                self._route_wake = None

    @staticmethod
    def _format_eta(seconds: float) -> str:
        seconds = max(0, int(round(seconds)))
        if seconds < 60:
            return f"{seconds}s"
        minutes = seconds // 60
        if minutes < 60:
            return f"{minutes}m"
        hours, minutes = divmod(minutes, 60)
        return f"{hours}h {minutes:02d}m"

    async def pause_route(self):
        if self.route_mode:
            self.route_paused = True
            if self._route_wake is not None:
                self._route_wake.set()

    async def resume_route(self):
        if self.route_mode:
            self.route_paused = False
            if self._route_wake is not None:
                self._route_wake.set()

    async def stop_route(self):
        if self.route_mode:
            self.route_stop_requested = True
            if self._route_wake is not None:
                self._route_wake.set()

    async def check_health(self):
        if getattr(self.backend, "ephemeral_location_session", False):
            return
        if self.lock.locked() or self.state != State.ACTIVE:
            return
        async with self.lock:
            if not await self.backend.healthy():
                log.info("DEVICE_DISCONNECTED")
                self.emit(
                    State.DISCONNECTED,
                    "Connection lost. The phone's current location is unknown. Reconnect to reset or restart iPhone.",
                    "disconnected",
                )
                try:
                    await self.backend.release()
                except Exception:
                    pass

    async def shutdown(self):
        async with self.lock:
            # Never turn a successful CoreDevice location back into real GPS just
            # because the desktop app is closed. Reset is an explicit action.
            await self.backend.release()

    def compatibility(self):
        return compatibility(self.device.ios if self.device else "Unknown")
