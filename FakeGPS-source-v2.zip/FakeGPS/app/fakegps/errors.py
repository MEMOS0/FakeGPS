from dataclasses import dataclass

MESSAGES = {
    "no_device": ("No iPhone Found", "Connect your iPhone with a data cable, unlock it, then try again."),
    "locked": ("iPhone Locked", "Unlock your iPhone and keep it unlocked during setup."),
    "trust": ("Trust Required", "Unlock your iPhone, tap Trust and enter your passcode on the phone."),
    "developer": (
        "Developer Mode Required",
        "Settings → Privacy & Security → Developer Mode → On. Restart and confirm on your iPhone.",
    ),
    "ddi": (
        "Device Support Setup Required",
        "Prepare device support automatically, or select your Xcode personalized image folder.",
    ),
    "connection": (
        "Location Service Connection Failed",
        "Developer connection could not be started. Reconnect and unlock your iPhone, then retry.",
    ),
    "unsupported": (
        "Unsupported iOS Version",
        "This build targets iOS 17, 18 and 26. No compatible transport is promised for this version.",
    ),
    "driver": (
        "Apple Device Connection Unavailable",
        "Install or repair Apple Devices from Apple's official page. Then reconnect your iPhone.",
    ),
    "disconnected": (
        "Device Disconnected",
        "Location is no longer observable. Reconnect to reset, or restart your iPhone and check Maps.",
    ),
    "persistence": (
        "Persistent Mode Not Verified",
        "This iOS version has no FakeGPS hardware persistence test. Use the experimental steps and verify on your iPhone.",
    ),
    "reset": (
        "Reset Could Not Be Confirmed",
        "Reconnect with Developer Mode on to retry, or restart your iPhone and check Apple Maps.",
    ),
}


@dataclass
class UserError(Exception):
    code: str

    def __str__(self):
        return MESSAGES.get(self.code, MESSAGES["connection"])[0]


def classify(error: Exception) -> UserError:
    if isinstance(error, UserError):
        return error
    name = type(error).__name__
    if name in {"PasswordRequiredError", "PasscodeRequiredError", "DeviceHasPasscodeSetError"}:
        return UserError("locked")
    if any(word in name for word in ("Pair", "Trust", "HostID")):
        return UserError("trust")
    if "DeveloperMode" in name:
        return UserError("developer")
    if any(word in name for word in ("NotMounted", "DiskImage", "Manifest")):
        return UserError("ddi")
    if name in {"NoDeviceConnectedError", "DeviceNotFoundError"}:
        return UserError("no_device")
    if "Usbmuxd" in name:
        return UserError("driver")
    return UserError("connection")
