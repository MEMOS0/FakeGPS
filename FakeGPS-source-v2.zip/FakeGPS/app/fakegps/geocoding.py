import asyncio
import json
import time
from pathlib import Path
from urllib.parse import urlparse

import requests

from .models import Location


def https_url(url: str) -> str:
    parsed = urlparse(url)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.fragment
    ):
        raise ValueError("Use an HTTPS provider URL without credentials or fragments.")
    return url


class Geocoder:
    def __init__(self, cache_file: Path, endpoint="https://photon.komoot.io/api/"):
        self.endpoint = https_url(endpoint)
        self.path = cache_file
        self.cache = {}
        try:
            value = json.loads(cache_file.read_text("utf-8"))
            if isinstance(value, dict):
                self.cache = value
        except (OSError, ValueError):
            pass
        self.lock = asyncio.Lock()
        self.last_request = 0.0

    def _request(self, query):
        with requests.get(
            self.endpoint,
            params={"q": query, "limit": 6},
            timeout=(5, 10),
            headers={"User-Agent": "FakeGPS-Desktop/0.1", "Accept": "application/json"},
            stream=True,
        ) as response:
            response.raise_for_status()
            content = bytearray()
            for chunk in response.iter_content(65536):
                content.extend(chunk)
                if len(content) > 2_000_000:
                    raise ValueError("Search response is too large.")
            return json.loads(content)

    @staticmethod
    def parse(payload):
        result = []
        for feature in payload.get("features", [])[:6]:
            try:
                lon, lat = feature["geometry"]["coordinates"][:2]
                properties = feature.get("properties", {})
                label = ", ".join(
                    dict.fromkeys(
                        str(properties[k]) for k in ("name", "city", "country") if properties.get(k)
                    )
                )
                result.append(Location(float(lat), float(lon), label[:500] or "Search result"))
            except (KeyError, ValueError, TypeError):
                continue
        return result

    async def search(self, query):
        query = query.strip()
        if not 2 <= len(query) <= 200:
            return []
        async with self.lock:
            key = self.endpoint + "|" + query.casefold()
            entry = self.cache.get(key)
            if entry and time.time() - entry["time"] < 86400 * 7:
                return self.parse(entry["data"])
            await asyncio.sleep(max(0, 1.1 - (time.monotonic() - self.last_request)))
            self.last_request = time.monotonic()
            payload = await asyncio.to_thread(self._request, query)
            self.cache[key] = {"time": time.time(), "data": payload}
            self.cache = dict(list(self.cache.items())[-150:])
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temp = self.path.with_suffix(".tmp")
            temp.write_text(json.dumps(self.cache), "utf-8")
            temp.replace(self.path)
            return self.parse(payload)
