import json
from importlib.resources import files

from packaging.version import InvalidVersion, Version


def compatibility(ios: str) -> dict:
    database = json.loads(files("fakegps").joinpath("data/compatibility.json").read_text("utf-8"))
    try:
        version = Version(ios)
    except InvalidVersion:
        return database["unknown"].copy()
    result = database["families"].get(str(version.major), database["unknown"]).copy()
    result.update(database["versions"].get(str(version), {}))
    return result
