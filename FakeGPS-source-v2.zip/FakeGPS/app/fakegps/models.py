import math
from dataclasses import dataclass
from enum import StrEnum
from typing import Protocol


@dataclass(frozen=True)
class Location:
    latitude: float
    longitude: float
    label: str = "Selected location"

    def __post_init__(self):
        if not math.isfinite(self.latitude) or not -90 <= self.latitude <= 90:
            raise ValueError("Latitude must be between -90 and 90.")
        if not math.isfinite(self.longitude) or not -180 <= self.longitude <= 180:
            raise ValueError("Longitude must be between -180 and 180.")
        if not isinstance(self.label, str) or len(self.label) > 500:
            raise ValueError("Invalid location label.")


@dataclass(frozen=True)
class Device:
    udid: str
    name: str = "iPhone"
    model: str = "iPhone"
    ios: str = "Unknown"
    transport: str = "USB"
    error: str | None = None


class State(StrEnum):
    IDLE = "idle"
    PREPARING = "preparing"
    ACTIVE = "active"
    ROUTE_ACTIVE = "route_active"
    ROUTE_PAUSED = "route_paused"
    PERSISTENCE_SETUP = "persistence_setup"
    PERSISTENCE_UNVERIFIED = "persistence_unverified"
    DISCONNECTED = "disconnected"
    RESET_SENT = "reset_sent"
    ERROR = "error"


class Backend(Protocol):
    async def discover(self) -> list[Device]: ...
    async def connect(self, device: Device) -> Device: ...
    async def set_location(self, location: Location) -> None: ...
    async def clear_location(self) -> None: ...
    async def developer_mode(self) -> bool | None: ...
    async def release(self) -> None: ...
    async def prepare_support(self, device: Device, folder: str | None = None) -> None: ...
    async def reveal_developer_mode(self, device: Device) -> None: ...
    async def healthy(self) -> bool: ...


PRESETS = [
    Location(45.4642, 9.1900, "Milan, Italy"),
    Location(51.5074, -0.1278, "London, UK"),
    Location(40.7128, -74.0060, "New York, USA"),
    Location(35.6586, 139.7454, "Tokyo Tower, Japan"),
]
