import json
import os
from dataclasses import asdict
from pathlib import Path

from platformdirs import user_data_path

from .models import Location


def data_dir() -> Path:
    path = user_data_path("FakeGPS", appauthor=False)
    path.mkdir(parents=True, exist_ok=True)
    return path


class Store:
    """GUI-thread owned local preferences; replace-on-write, private user directory."""

    def __init__(self, path: Path | None = None):
        self.path = path or data_dir() / "settings.json"
        self.data = {"favorites": [], "recent": [], "session": None, "providers": {}}
        if self.path.exists():
            try:
                loaded = json.loads(self.path.read_text("utf-8"))
                if isinstance(loaded, dict):
                    self.data.update(loaded)
            except (ValueError, OSError):
                pass

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), "utf-8")
        os.chmod(temp, 0o600)
        temp.replace(self.path)

    def locations(self, key: str) -> list[Location]:
        result = []
        for item in self.data.get(key, [])[:100]:
            try:
                result.append(Location(**item))
            except (TypeError, ValueError):
                continue
        return result

    def add(self, key: str, location: Location):
        old = [
            x
            for x in self.locations(key)
            if (x.latitude, x.longitude) != (location.latitude, location.longitude)
        ]
        self.data[key] = [asdict(x) for x in [location, *old]][:30]
        self.save()
