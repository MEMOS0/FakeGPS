import asyncio

from ..errors import UserError
from ..models import Device, Location


class MockBackend:
    """Explicit demo; never selected on real-backend failure."""

    def __init__(self):
        self.devices = [Device("DEMO-ONLY", "Emre's iPhone · DEMO", "iPhone 14", "18.7.8")]
        self.connected = False
        self.dev_mode: bool | None = True
        self.location: Location | None = None
        self.calls = []
        self.failure: str | None = None

    async def discover(self):
        await asyncio.sleep(0.02)
        return self.devices[:]

    async def connect(self, device):
        if device not in self.devices:
            raise UserError("no_device")
        if not self.dev_mode:
            raise UserError("developer")
        self.connected = True
        self.calls.append("connect")
        return device

    async def set_location(self, location):
        if self.failure:
            raise UserError(self.failure)
        if not self.connected:
            raise UserError("disconnected")
        self.location = location
        self.calls.append("set")

    async def clear_location(self):
        if self.failure or not self.connected or not self.dev_mode:
            raise UserError("reset")
        self.location = None
        self.calls.append("clear")

    async def developer_mode(self):
        return self.dev_mode

    async def release(self):
        self.connected = False
        self.calls.append("release")

    async def prepare_support(self, device, folder=None):
        self.calls.append("prepare")

    async def reveal_developer_mode(self, device):
        self.calls.append("reveal")

    async def healthy(self):
        return self.connected and bool(self.devices)
