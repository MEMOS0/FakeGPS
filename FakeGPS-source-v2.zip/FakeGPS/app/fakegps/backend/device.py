"""pymobiledevice3 11.3.1 adapter. All device objects stay on ONE asyncio loop."""

import asyncio
import logging
import plistlib
import sys
import time
from contextlib import AsyncExitStack
from pathlib import Path

from packaging.version import Version

from ..errors import UserError, classify
from ..models import Device, Location
from ..storage import data_dir

log = logging.getLogger("fakegps.device")
MODEL_NAMES = {
    "iPhone14,7": "iPhone 14",
    "iPhone14,8": "iPhone 14 Plus",
    "iPhone15,2": "iPhone 14 Pro",
    "iPhone15,3": "iPhone 14 Pro Max",
    "iPhone17,2": "iPhone 16 Pro Max",
}


def download_ddi() -> tuple[Path, Path, Path]:
    """Bounded downloads via the upstream repository abstraction; no Apple bytes shipped."""
    import requests
    from developer_disk_image.repo import (
        DEVELOPER_DISK_IMAGE_REPO_RAW_URL_FORMAT,
        DeveloperDiskImageRepository,
    )
    from pymobiledevice3.services.mobile_image_mounter import LATEST_DDI_BUILD_ID

    class BoundedRepository(DeveloperDiskImageRepository):
        def _get_blob(self, path):
            url = DEVELOPER_DISK_IMAGE_REPO_RAW_URL_FORMAT.format(ref=self.ref, path=path)
            start = time.monotonic()
            chunks = []
            size = 0
            with requests.get(
                url, timeout=(10, 20), stream=True, headers={"User-Agent": "FakeGPS-Desktop/0.1"}
            ) as response:
                response.raise_for_status()
                for chunk in response.iter_content(1024 * 1024):
                    size += len(chunk)
                    if size > 1024 * 1024 * 1024 or time.monotonic() - start > 180:
                        raise UserError("ddi")
                    chunks.append(chunk)
            return b"".join(chunks)

    root = data_dir() / "device-support" / LATEST_DDI_BUILD_ID
    root.mkdir(parents=True, exist_ok=True)
    paths = tuple(root / p for p in ("Image.dmg", "BuildManifest.plist", "Image.dmg.trustcache"))
    if all(p.exists() and p.stat().st_size > 0 for p in paths):
        return paths
    image = BoundedRepository.create().get_personalized_disk_image()
    if plistlib.loads(image.build_manifest).get("ProductBuildVersion") != LATEST_DDI_BUILD_ID:
        raise UserError("ddi")  # refuse unexpected upstream moving-branch assets
    for path, value in zip(paths, (image.image, image.build_manifest, image.trustcache)):
        if not value:
            raise UserError("ddi")
        temp = path.with_suffix(path.suffix + ".part")
        temp.write_bytes(value)
        temp.replace(path)
    return paths


class DeviceBackend:
    def __init__(self):
        self.stack: AsyncExitStack | None = None
        self.lockdown = None
        self.rsd = None
        self.dvt = None
        self.location_service = None
        self.device: Device | None = None
        self.disconnect_watch = None

    async def discover(self) -> list[Device]:
        from pymobiledevice3.lockdown import create_using_usbmux
        from pymobiledevice3.usbmux import list_devices

        try:
            raw = await asyncio.wait_for(list_devices(), 5)
        except (OSError, ConnectionError) as error:
            if sys.platform == "win32":
                raise UserError("driver") from error
            raise
        result = {}
        for item in sorted(raw, key=lambda x: x.connection_type != "USB"):
            if item.serial in result:
                continue
            transport = "USB" if item.is_usb else "Wi-Fi"
            try:
                async with await asyncio.wait_for(
                    create_using_usbmux(
                        serial=item.serial, connection_type=item.connection_type, autopair=False
                    ),
                    4,
                ) as lockdown:
                    values = lockdown.all_values
                    model = values.get("ProductType", "iPhone")
                    result[item.serial] = Device(
                        item.serial,
                        values.get("DeviceName", "iPhone"),
                        MODEL_NAMES.get(model, model),
                        values.get("ProductVersion", "Unknown"),
                        transport,
                    )
            except Exception as error:
                result[item.serial] = Device(item.serial, transport=transport, error=classify(error).code)
        return list(result.values())

    async def _open_lockdown(self, device):
        from pymobiledevice3.lockdown import create_using_usbmux

        return await asyncio.wait_for(
            create_using_usbmux(
                serial=device.udid,
                autopair=True,
                connection_type="USB" if device.transport == "USB" else "Network",
                pair_timeout=1,
                label="FakeGPS",
            ),
            8,
        )

    async def connect(self, device: Device) -> Device:
        from pymobiledevice3.remote.rsd_tunnel import PreferredRsdTunnel
        from pymobiledevice3.services.dvt.instruments.dvt_provider import DvtProvider
        from pymobiledevice3.services.dvt.instruments.location_simulation import LocationSimulation
        from pymobiledevice3.services.mobile_image_mounter import MobileImageMounterService

        if self.device and self.device.udid == device.udid and self.location_service is not None:
            if await self.healthy():
                return self.device
        await self.release()
        stack = AsyncExitStack()
        try:
            lockdown = await stack.enter_async_context(await self._open_lockdown(device))
            values = lockdown.all_values
            ios = values.get("ProductVersion", device.ios)
            if Version(ios).major not in (17, 18, 26):
                raise UserError("unsupported")
            if not await lockdown.get_developer_mode_status():
                raise UserError("developer")
            log.info("PAIRED")
            async with MobileImageMounterService(lockdown) as mounter:
                mounted = await mounter.is_image_mounted("Personalized")
            if not mounted:
                raise UserError("ddi")
            tunnel = PreferredRsdTunnel(serial=device.udid, autopair=False)
            rsd = await asyncio.wait_for(stack.enter_async_context(tunnel), 35)
            log.info("TUNNEL_STARTED")
            dvt = await asyncio.wait_for(stack.enter_async_context(DvtProvider(rsd)), 15)
            service = await asyncio.wait_for(stack.enter_async_context(LocationSimulation(dvt)), 10)
            log.info("DVT_CONNECTED")
            self.stack, self.lockdown, self.rsd, self.dvt, self.location_service = (
                stack,
                lockdown,
                rsd,
                dvt,
                service,
            )
            self.disconnect_watch = asyncio.create_task(dvt.dtx.wait_disconnected())
            model = values.get("ProductType", device.model)
            self.device = Device(
                device.udid,
                values.get("DeviceName", device.name),
                MODEL_NAMES.get(model, model),
                ios,
                device.transport,
            )
            return self.device
        except BaseException:
            await stack.aclose()
            raise

    async def set_location(self, location: Location):
        if self.location_service is None:
            raise UserError("connection")
        await asyncio.wait_for(self.location_service.set(location.latitude, location.longitude), 10)

    async def clear_location(self):
        if self.location_service is None:
            raise UserError("reset")
        # Upstream clear is fire-and-forget. This is NOT a Core Location readback.
        await asyncio.wait_for(self.location_service.clear(), 10)

    async def developer_mode(self) -> bool | None:
        if self.device is None:
            return None
        try:
            async with await self._open_lockdown(self.device) as lockdown:
                return await asyncio.wait_for(lockdown.get_developer_mode_status(), 4)
        except Exception:
            return None  # lost transport is not proof the toggle is OFF

    async def healthy(self):
        if self.lockdown is None or self.dvt is None:
            return False
        try:
            await asyncio.wait_for(self.lockdown.get_value(key="ProductVersion"), 3)
            return self.disconnect_watch is not None and not self.disconnect_watch.done()
        except Exception:
            return False

    async def reveal_developer_mode(self, device):
        from pymobiledevice3.services.amfi import AmfiService

        async with await self._open_lockdown(device) as lockdown:
            await asyncio.wait_for(AmfiService(lockdown).reveal_developer_mode_option_in_ui(), 8)

    async def prepare_support(self, device, folder=None):
        from pymobiledevice3.exceptions import AlreadyMountedError
        from pymobiledevice3.services.mobile_image_mounter import PersonalizedImageMounter

        if folder:
            root = Path(folder)
            paths = (root / "Image.dmg", root / "BuildManifest.plist", root / "Image.dmg.trustcache")
            if not paths[2].exists():
                paths = (*paths[:2], root / "Image.trustcache")
            if not all(p.is_file() for p in paths):
                raise UserError("ddi")
        else:
            paths = await asyncio.to_thread(download_ddi)
        async with await self._open_lockdown(device) as lockdown:
            async with PersonalizedImageMounter(lockdown) as mounter:
                try:
                    await asyncio.wait_for(mounter.mount(*paths), 120)
                except AlreadyMountedError:
                    pass

    async def release(self):
        stack, self.stack = self.stack, None
        self.location_service = self.dvt = self.rsd = self.lockdown = None
        self.device = None
        if self.disconnect_watch:
            self.disconnect_watch.cancel()
            await asyncio.gather(self.disconnect_watch, return_exceptions=True)
            self.disconnect_watch = None
        if stack:
            await asyncio.wait_for(stack.aclose(), 12)
