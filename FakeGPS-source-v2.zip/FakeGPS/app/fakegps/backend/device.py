"""CoreDevice location adapter for current iOS developer devices.

CoreDevice location simulation with a one-request LocationService channel.
Teleport tears down the full host transport after success. Walk/Drive can keep
the userspace RSD tunnel open, while each coordinate gets a fresh service XPC
channel and an automatic full-transport retry if that channel goes stale.
"""

import asyncio
import logging
import sys
from contextlib import AsyncExitStack

from packaging.version import Version

from ..errors import UserError, classify
from ..models import Device, Location

log = logging.getLogger("fakegps.device")

LOCATION_SERVICE = "com.apple.coredevice.locationservice"
SIMULATE_FEATURE = "com.apple.coredevice.feature.simulatelocation"
SET_ACTION = "com.apple.coredevice.action.setsimulatedlocation"

MODEL_NAMES = {
    "iPhone14,7": "iPhone 14",
    "iPhone14,8": "iPhone 14 Plus",
    "iPhone15,2": "iPhone 14 Pro",
    "iPhone15,3": "iPhone 14 Pro Max",
    "iPhone17,2": "iPhone 16 Pro Max",
}


class DeviceBackend:
    """Primary CoreDevice backend.

    Teleport uses a short-lived userspace RSD tunnel. Walk/Drive may keep that
    tunnel alive for efficiency, but every simulated coordinate is sent through
    a fresh CoreDevice LocationService XPC channel. The device-side simulated
    location survives host-side service/tunnel teardown after a successful set.
    """

    ephemeral_location_session = True

    def __init__(self):
        self.stack: AsyncExitStack | None = None
        self.lockdown = None
        self.rsd = None
        self.tunnel = None
        # LocationService itself is deliberately NOT held open across updates.
        # On the real iPhone path a single service channel is reliable for one
        # setsimulatedlocation request, while reusing that XPC channel for a
        # Walk/Drive stream can die after the first update. Keep the RSD tunnel
        # alive, but create a fresh LocationService channel per coordinate.
        self.location_service = None
        self.device: Device | None = None
        self.last_backend = "coredevice"

    async def discover(self) -> list[Device]:
        from pymobiledevice3.lockdown import create_using_usbmux
        from pymobiledevice3.usbmux import list_devices

        try:
            raw = await asyncio.wait_for(list_devices(), 5)
        except (OSError, ConnectionError) as error:
            if sys.platform == "win32":
                raise UserError("driver") from error
            raise

        result: dict[str, Device] = {}
        for item in sorted(raw, key=lambda x: x.connection_type != "USB"):
            if item.serial in result:
                continue
            transport = "USB" if item.is_usb else "Wi-Fi"
            try:
                async with await asyncio.wait_for(
                    create_using_usbmux(
                        serial=item.serial, connection_type=item.connection_type, autopair=False
                    ),
                    4,
                ) as lockdown:
                    values = lockdown.all_values
                    model = values.get("ProductType", "iPhone")
                    result[item.serial] = Device(
                        item.serial,
                        values.get("DeviceName", "iPhone"),
                        MODEL_NAMES.get(model, model),
                        values.get("ProductVersion", "Unknown"),
                        transport,
                    )
            except Exception as error:
                result[item.serial] = Device(item.serial, transport=transport, error=classify(error).code)
        return list(result.values())

    async def _open_lockdown(self, device: Device):
        from pymobiledevice3.lockdown import create_using_usbmux

        return await asyncio.wait_for(
            create_using_usbmux(
                serial=device.udid,
                autopair=True,
                connection_type="USB" if device.transport == "USB" else "Network",
                pair_timeout=1,
                label="FakeGPS",
            ),
            10,
        )

    async def _ensure_personalized_ddi(self, lockdown) -> None:
        """Run pymobiledevice3's own ``mounter auto-mount`` implementation."""
        from pymobiledevice3.exceptions import AlreadyMountedError
        from pymobiledevice3.services.mobile_image_mounter import MobileImageMounterService, auto_mount

        async with MobileImageMounterService(lockdown) as mounter:
            if await mounter.is_image_mounted("Personalized"):
                return
        try:
            # Caches public DDI assets locally for this Windows user. FakeGPS
            # ships no Apple image, device record, certificate, or private key.
            await asyncio.wait_for(auto_mount(lockdown), 180)
        except AlreadyMountedError:
            return

    async def connect(self, device: Device) -> Device:
        from pymobiledevice3.remote.userspace_tunnel import UserspaceRsdTunnel

        if self.device and self.device.udid == device.udid and self.rsd is not None:
            return self.device
        await self.release()
        stack = AsyncExitStack()
        try:
            lockdown = await stack.enter_async_context(await self._open_lockdown(device))
            values = lockdown.all_values
            ios = values.get("ProductVersion", device.ios)
            if Version(ios).major < 17:
                raise UserError("unsupported")
            if not await lockdown.get_developer_mode_status():
                raise UserError("developer")
            log.info("PAIRED")
            await self._ensure_personalized_ddi(lockdown)

            # This owns a no-admin in-process tunnel and has a deterministic
            # aclose(). It replaces the old PreferredRsdTunnel + DVT set path.
            tunnel = UserspaceRsdTunnel(serial=device.udid, autopair=True)
            rsd = await asyncio.wait_for(stack.enter_async_context(tunnel), 40)
            log.info("TUNNEL_STARTED transport=userspace")
            rsd.require_feature(LOCATION_SERVICE, SIMULATE_FEATURE)
            # Do not open LocationService here. A fresh service channel is
            # opened for every set_location() call. The long-lived resource for
            # Walk/Drive is the userspace RSD tunnel, not the service XPC stream.
            log.info("COREDEVICE_LOCATION_TRANSPORT_READY")

            model = values.get("ProductType", device.model)
            self.stack, self.lockdown, self.rsd, self.tunnel, self.location_service = (
                stack,
                lockdown,
                rsd,
                tunnel,
                None,
            )
            self.device = Device(
                device.udid,
                values.get("DeviceName", device.name),
                MODEL_NAMES.get(model, model),
                ios,
                device.transport,
            )
            return self.device
        except BaseException:
            await stack.aclose()
            raise

    async def _invoke_location_once(self, location: Location) -> dict:
        """Send one coordinate over a fresh CoreDevice LocationService channel."""
        if self.rsd is None:
            raise UserError("connection")
        from pymobiledevice3.remote.core_device.location_service import LocationService

        payload = {"latitude": float(location.latitude), "longitude": float(location.longitude)}
        service_stack = AsyncExitStack()
        try:
            service = await asyncio.wait_for(
                service_stack.enter_async_context(LocationService(self.rsd)),
                12,
            )
            response = await asyncio.wait_for(
                service.invoke(SIMULATE_FEATURE, payload, action_identifier=SET_ACTION),
                15,
            )
        except Exception as error:
            log.warning(
                "COREDEVICE_LOCATION_CHANNEL_FAILED type=%s error=%r",
                type(error).__name__,
                error,
            )
            try:
                await asyncio.wait_for(service_stack.aclose(), 5)
            except Exception:
                log.warning("COREDEVICE_LOCATION_CHANNEL_CLEANUP_FAILED", exc_info=True)
            raise
        try:
            await asyncio.wait_for(service_stack.aclose(), 5)
        except Exception:
            # The device request already returned successfully. A host-side XPC
            # close fault must not turn a successful location change into an
            # apparent failure. The next update gets a brand-new service anyway.
            log.warning("COREDEVICE_LOCATION_CHANNEL_CLEANUP_FAILED", exc_info=True)
        if response is None:
            raise UserError("set_location")
        return response

    async def set_location(self, location: Location) -> dict:
        if self.rsd is None:
            raise UserError("connection")
        try:
            response = await self._invoke_location_once(location)
        except Exception as first_error:
            first = classify(first_error)
            # A channel/transport fault is recoverable. Rebuild the physically
            # verified userspace CoreDevice path once and retry this exact
            # coordinate. Feature/DDI/developer failures are never hidden.
            if first.code != "connection" or self.device is None:
                raise first from first_error
            device = self.device
            log.info("COREDEVICE_LOCATION_RECONNECT retry=1")
            try:
                await self.release()
                await self.connect(device)
                response = await self._invoke_location_once(location)
            except Exception as retry_error:
                log.warning(
                    "COREDEVICE_LOCATION_RETRY_FAILED type=%s error=%r",
                    type(retry_error).__name__,
                    retry_error,
                )
                raise classify(retry_error) from retry_error
        log.info("LOCATION_SET backend=coredevice fresh_service=1")
        return response

    async def clear_location(self) -> None:
        """Known DVT stop fallback for reset only; no CoreDevice clear is guessed."""
        if self.rsd is None:
            raise UserError("reset")
        from pymobiledevice3.services.dvt.instruments.dvt_provider import DvtProvider
        from pymobiledevice3.services.dvt.instruments.location_simulation import LocationSimulation

        try:
            async with DvtProvider(self.rsd) as dvt:
                async with LocationSimulation(dvt) as service:
                    await asyncio.wait_for(service.clear(), 12)
            log.info("LOCATION_CLEAR_SENT backend=dvt_fallback")
        except Exception as error:
            raise UserError("reset") from error

    async def developer_mode(self) -> bool | None:
        if self.device is None:
            return None
        try:
            async with await self._open_lockdown(self.device) as lockdown:
                return await asyncio.wait_for(lockdown.get_developer_mode_status(), 4)
        except Exception:
            return None

    async def healthy(self) -> bool:
        # Teleport deliberately releases its transport, while movement owns its
        # connection inside the serialized route job. There is no background
        # health probe that can safely infer the phone's physical GPS state.
        return True

    async def reveal_developer_mode(self, device: Device) -> None:
        from pymobiledevice3.services.amfi import AmfiService

        async with await self._open_lockdown(device) as lockdown:
            await asyncio.wait_for(AmfiService(lockdown).reveal_developer_mode_option_in_ui(), 8)

    async def prepare_support(self, device: Device, folder=None) -> None:
        async with await self._open_lockdown(device) as lockdown:
            await self._ensure_personalized_ddi(lockdown)

    async def release(self) -> None:
        stack, self.stack = self.stack, None
        self.location_service = self.tunnel = self.rsd = self.lockdown = None
        self.device = None
        if stack:
            try:
                await asyncio.wait_for(stack.aclose(), 15)
            except Exception:
                # The device-side request already returned; do not represent a
                # host teardown fault as an imaginary device-side clear.
                log.warning("COREDEVICE_CLEANUP_FAILED", exc_info=True)
