"""Small routing helpers for Walk/Drive simulation.

Road geometry is requested from public OSRM-compatible endpoints. If a provider
is unavailable, FakeGPS falls back to a straight line so movement simulation
still works instead of pretending that routing succeeded.
"""

import asyncio
import bisect
import json
import math
from dataclasses import dataclass

import requests

from .geocoding import https_url
from .models import Location

EARTH_RADIUS_M = 6_371_000.0
DEFAULT_DRIVE_ENDPOINT = "https://routing.openstreetmap.de/routed-car/route/v1/driving"
DEFAULT_WALK_ENDPOINT = "https://routing.openstreetmap.de/routed-foot/route/v1/driving"


@dataclass(frozen=True)
class Route:
    points: tuple[Location, ...]
    distance_m: float
    duration_s: float | None
    source: str = "road"
    warning: str | None = None


def distance_m(a: Location, b: Location) -> float:
    lat1, lat2 = math.radians(a.latitude), math.radians(b.latitude)
    dlat = lat2 - lat1
    dlon = math.radians(b.longitude - a.longitude)
    value = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 2 * EARTH_RADIUS_M * math.asin(min(1.0, math.sqrt(value)))


def cumulative_distances(points) -> tuple[float, ...]:
    values = [0.0]
    for first, second in zip(points, points[1:]):
        values.append(values[-1] + distance_m(first, second))
    return tuple(values)


def position_at_distance(points, cumulative, meters: float, label="Moving location") -> Location:
    if not points:
        raise ValueError("Route has no points.")
    if len(points) == 1 or meters <= 0:
        first = points[0]
        return Location(first.latitude, first.longitude, label)
    if meters >= cumulative[-1]:
        last = points[-1]
        return Location(last.latitude, last.longitude, last.label)
    index = max(0, bisect.bisect_right(cumulative, meters) - 1)
    start, end = points[index], points[index + 1]
    segment = cumulative[index + 1] - cumulative[index]
    fraction = 0.0 if segment <= 0 else (meters - cumulative[index]) / segment
    longitude_delta = (end.longitude - start.longitude + 180.0) % 360.0 - 180.0
    longitude = start.longitude + longitude_delta * fraction
    if longitude > 180.0:
        longitude -= 360.0
    elif longitude < -180.0:
        longitude += 360.0
    return Location(
        start.latitude + (end.latitude - start.latitude) * fraction,
        longitude,
        label,
    )


def straight_route(start: Location, destination: Location, warning=None) -> Route:
    distance = distance_m(start, destination)
    return Route((start, destination), distance, None, "straight", warning)


class Router:
    def __init__(
        self,
        drive_endpoint=DEFAULT_DRIVE_ENDPOINT,
        walk_endpoint=DEFAULT_WALK_ENDPOINT,
        offline=False,
    ):
        self.drive_endpoint = https_url(drive_endpoint).rstrip("/")
        self.walk_endpoint = https_url(walk_endpoint).rstrip("/")
        self.offline = offline
        self._request_lock = asyncio.Lock()
        self._last_request_at = 0.0

    def _request(self, start: Location, destination: Location, mode: str) -> Route:
        endpoint = self.walk_endpoint if mode == "walk" else self.drive_endpoint
        url = (
            f"{endpoint}/{start.longitude:.7f},{start.latitude:.7f};"
            f"{destination.longitude:.7f},{destination.latitude:.7f}"
        )
        with requests.get(
            url,
            params={"overview": "full", "geometries": "geojson", "steps": "false"},
            timeout=(5, 18),
            headers={"User-Agent": "FakeGPS-Desktop/0.2.2", "Accept": "application/json"},
            stream=True,
        ) as response:
            response.raise_for_status()
            content = bytearray()
            for chunk in response.iter_content(65536):
                content.extend(chunk)
                if len(content) > 4_000_000:
                    raise ValueError("Route response is too large.")
        payload = json.loads(content)
        routes = payload.get("routes") or []
        if not routes:
            raise ValueError("No route returned.")
        item = routes[0]
        coordinates = item.get("geometry", {}).get("coordinates") or []
        points = []
        for coordinate in coordinates:
            try:
                lon, lat = coordinate[:2]
                points.append(Location(float(lat), float(lon), "Route point"))
            except (TypeError, ValueError):
                continue
        if len(points) < 2:
            raise ValueError("Route geometry is incomplete.")
        # Routing providers usually snap endpoints to the nearest routable way.
        # Preserve the exact user-selected coordinates so starting a Walk/Drive
        # never begins with an unexplained teleport to the snapped road point.
        if distance_m(start, points[0]) > 0.25:
            points.insert(0, start)
        else:
            points[0] = start
        if distance_m(points[-1], destination) > 0.25:
            points.append(destination)
        else:
            points[-1] = destination

        # Remove effectively duplicate consecutive coordinates. Apart from
        # making the map cleaner, this prevents zero-length geometry segments
        # from accumulating around provider-snapped endpoints.
        cleaned = [points[0]]
        for point in points[1:]:
            if distance_m(cleaned[-1], point) >= 0.01:
                cleaned.append(point)
        if len(cleaned) < 2:
            raise ValueError("Route geometry is incomplete.")

        distance = cumulative_distances(cleaned)[-1]
        duration = item.get("duration")
        try:
            duration = float(duration) if duration is not None else None
            if duration is not None and (not math.isfinite(duration) or duration < 0):
                duration = None
        except (TypeError, ValueError):
            duration = None
        return Route(tuple(cleaned), distance, duration)

    async def route(self, start: Location, destination: Location, mode: str) -> Route:
        if mode not in {"walk", "drive"}:
            raise ValueError("Route mode must be walk or drive.")
        if distance_m(start, destination) < 1:
            raise ValueError("Start and destination are too close.")
        if self.offline:
            return straight_route(start, destination, "Demo mode uses a straight-line route.")
        async with self._request_lock:
            # The default public FOSSGIS/OSM router asks clients to stay at or
            # below one request per second. Serialize and pace route lookups so
            # quick stop/restart actions do not hammer the free service.
            loop = asyncio.get_running_loop()
            delay = 1.05 - (loop.time() - self._last_request_at)
            if delay > 0:
                await asyncio.sleep(delay)
            try:
                return await asyncio.to_thread(self._request, start, destination, mode)
            except Exception:
                return straight_route(
                    start,
                    destination,
                    "Road routing is unavailable; using a straight-line movement fallback.",
                )
            finally:
                self._last_request_at = loop.time()
