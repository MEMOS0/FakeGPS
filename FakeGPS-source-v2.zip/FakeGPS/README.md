# FakeGPS desktop — geliştirici README

Native masaüstü iPhone konum simülasyonu MVP'si. Harita, cihaz seçimi, yer arama, koordinatlar, favoriler, Home, geçmiş, normal DVT set/reset ve deneysel persistence sihirbazı implement edildi. Gerçek backend, `pymobiledevice3==11.3.1` Python API'lerini çağırır; demo backend tamamen ayrıdır.

**Teslim durumu:** kaynak ve otomatik testler mevcut. Linux üzerinde native Qt arayüzü çalıştırıldı ve PyInstaller paketi oluşturuldu. Fiziksel iPhone, Windows 11 veya macOS test makinesi bu geliştirme ortamında yok. Windows `.exe`/installer ve macOS `.app` üreten betikler ile CI tanımı mevcut; bu platformların üretilmiş veya cihaz üzerinde doğrulanmış binary'leri bu teslimde yok. Ayrıntılı gerçek sonuçlar `docs/verification.md` içindedir. Bu sürüm, donanım kabul testinden geçmiş bir son kullanıcı release'i olarak tanımlanmamalıdır.

**Temel ürün sınırı:** bilgisayar kapandıktan sonra iPhone'un Milano'da kalması garanti edilemiyor. Bu bir arayüz veya paketleme meselesi değil; iOS'un belgesiz cihaz içi state davranışı. Hiçbir iOS satırı FakeGPS tarafından `persistent: tested` işaretlenmedi. UI bu nedenle “PERSISTENT HANDOFF · UNVERIFIED” gösterir. “Persistent Location Active / güvenle bilgisayarı kapat” şeklinde doğrulanmamış başarı mesajı yoktur.

## Hızlı geliştirme

Build/geliştirme makinesinde Python 3.12 gerekir. **Aşağıdaki komutlar son kullanıcı için değildir.** Betik gerekli geliştirme ortamını yoksa oluşturur. Proje dizininde:

```bash
python scripts/project.py dev --demo
```

Gerçek cihaz backend'iyle:

```bash
python scripts/project.py dev
```

Testler:

```bash
python scripts/project.py test
```

Hedef işletim sisteminin üzerinde release:

```bash
python scripts/project.py release
```

Windows üzerinde isteğe bağlı tek portable executable:

```bash
python scripts/project.py portable
```

Son kullanıcı dağıtılmış `FakeGPS.exe` veya `.app` dosyasını açar. Python/Node kurulumu, terminal, localhost sayfası gerekmez. Apple cihaz sürücüleri uygulama bağımlılıklarından ayrıdır; Apple'ın sistem sürücüsünü yetkisiz olarak pakete koymuyoruz.

## Neden Python + native Qt?

| Seçenek | Değerlendirme |
| --- | --- |
| Python + PySide6 + PyInstaller | Seçildi. Python API doğrudan, tek süreç, Qt haritası, web kontrol katmanı yok. |
| Tauri + Python helper | Daha küçük frontend olabilir; iki runtime, IPC ve helper lifecycle maliyeti. |
| Electron + Python | Chromium ve Python birlikte paketlenir; bu MVP için gereksiz boyut. |
| Tam Swift/Rust/C++ | Protokol adaptörünü yeniden yazma maliyeti; iki masaüstü platformunu ortak geliştirmek zorlaşır. |

PySide6-Essentials kullanılıyor; WebEngine yüklenmiyor. Harita `QPainter` ile OpenStreetMap raster tile'larını çizer. MapLibre yerine native raster seçimi aynı pan/zoom/click ihtiyaçlarını bir browser runtime olmadan karşılar. Dağıtım boyutu sıfır değildir: Python, Qt, kriptografi ve tunnel ağ katmanı gerekir. Ölçülmemiş Windows açılış süresi veya installer boyutu vaat edilmez.

Önerilen Windows ürün paketi **onedir PyInstaller çıktısını taşıyan tek Inno Setup installer**. Kullanıcı bir installer indirir, kurulumdan sonra bir exe açar. Klasörün `_internal` içeriği uygulamanın parçasıdır. `portable` tek exe her açılışta geçici dizine açıldığı için daha yavaş başlayabilir; varsayılan dağıtım değildir.

## Protokol ve uygulama akışı

1. `usbmux.list_devices()` bağlı cihazları listeler. Aynı UDID USB ve Network olarak iki kez görünürse USB tercih edilir. Birden fazla fiziksel cihaz varsa seçim yapılmadan set gönderilmez.
2. Keşifte `autopair=False`. İşlem başlatılırken `create_using_usbmux(serial=..., autopair=True, pair_timeout=1)` pairing oturumunu doğrular/başlatır. Telefonda Trust ve passcode girişi kullanıcıya aittir.
3. Lockdown üzerinden cihaz adı, model, iOS ve Developer Mode sorgulanır. Developer Mode kapalıysa menüyü gösterme seçeneği sunulur; cihaz passcode'unu kaldırma akışı yoktur.
4. `MobileImageMounterService.is_image_mounted('Personalized')` kontrol edilir. Eksikse GUI'deki hazırlama düğmesi image dosyalarını alır ve `PersonalizedImageMounter.mount(...)` çağırır. Yerel Xcode image klasörü de seçilebilir.
5. `PreferredRsdTunnel(serial=udid)` macOS native yolunu, diğer sistemlerde userspace tunnel'ı kullanır. Tunnel ve RSD, DVT oturumu boyunca açık kalır.
6. `DvtProvider(rsd)` ve `LocationSimulation(dvt)` async context'leri açılır. Set için `await service.set(lat, lon)`, stop için `await service.clear()` kullanılır.
7. Uygulama normal modda bağlantıyı korur. Bağlantı kaybında bilinmeyen cihaz durumu gösterir. Otomatik yeniden konum uygulamaz.

Kodla sabitlenmiş servis isimleri, selectors, sürüm farkları ve kaynaklar: [ios-research.md](docs/ios-research.md). Tasarım: [architecture.md](docs/architecture.md).

## First run ve hata kurtarma

İstenen sırayla: bağla → kilidi aç → Trust → Developer Mode'u aç/restart/telefonda onayla → gerekiyorsa device support hazırla → set. Developer Mode menüsü yoksa “Show Developer Mode on iPhone” AMFI reveal çağrısını kullanır. Etkinleştirmeyi sessizce yapmaz.

| Durum | Kullanıcıya gösterilen çözüm |
| --- | --- |
| Cihaz yok | Veri taşıyabilen USB kablosuyla bağla, kilidi aç. |
| Birden fazla cihaz | Açılır listeden açık seçim. |
| Kilitli / passcode gerekli | Telefonda kilidi aç; masaüstüne passcode yazma. |
| Pairing / Trust gerekli | Telefonda Trust ve passcode; sonra tekrar dene. |
| Developer Mode kapalı | Menü yönergesi ve menüyü gösterme düğmesi. |
| DDI eksik | Otomatik hazırlama veya yerel image klasörü seçimi. |
| Apple bağlantısı yok | Resmî Apple kurulum/sürücü sorun giderme sayfası. |
| DVT kurulamadı | Basit mesaj, yeniden bağlanma; protokol dump'ı yok. |
| Reset başarısız | Developer Mode açıkken tekrar bağlan; alternatif manuel restart. |
| Bilinmeyen iOS ana sürümü | Destek iddiası yapmadan işlemi durdur. |

Polling her dört saniyede yapılır; cihaz mutasyonu sırasında arka arkaya setup komutu kuyruğu oluşturulmaz. Ağ ve cihaz işleri GUI thread'inde çalışmaz. Kullanıcı araması yalnızca Search/Enter ile başlar.

## Persistent Mode

Normal mode ve persistence farklı state'lerdir. Kalıcılık sihirbazı yalnızca normal set başarılı olduktan sonra açılır. Önce Apple Maps'teki **mavi mevcut konum noktasını** kontrol et; aranan Milano pinini görmek doğrulama değildir. Sonra telefondaki Developer Mode switch'ini kapatıp yeniden başlatmadığını işaretle. Mümkünse Developer Mode tekrar sorgulanır; bağlantı kaybı OFF kanıtı sayılmaz.

Sihirbazdan çıkışta `stopLocationSimulation` gönderilmez. DVT ve tunnel context'leri kapatılır; bu cleanup'ın iOS tarafında konumu temizleyip temizlemeyeceği fiziksel test konusudur. Bilgisayar kapandıktan sonra uygulama telefondaki GPS'i okuyamaz. Kullanıcının checkbox'ı laboratuvar testi değildir.

Normal reset DVT stop isteği gönderir. Bu selector upstream'de reply beklemiyor; UI “reset isteği gönderildi” der ve gerçek konumu Maps'te doğrulatır. Developer Mode kapalı/cihaz erişilemezse en basit kurtarma manuel iPhone restart'tır; otomatik restart veya location daemon müdahalesi yoktur. Yeniden açılışta önceki denemenin yerel kaydı gösterilir, otomatik yeniden spoof yapılmaz.

Tüm araştırma sorularının yanıtları: [persistent-mode.md](docs/persistent-mode.md).

## Windows 11 önkoşulları

Build makinesi: Python 3.12 x64, proje geliştirme bağımlılıkları; installer için Inno Setup 6. CI bunları kurar. Kullanıcı makinesi: Apple Devices uygulaması ve işleyen Apple Mobile Device USB/usbmux katmanı; bazı mevcut iTunes kurulumlarında da bulunabilir. Bonjour/iTunes Wi-Fi sync ile görünürlük, USB'den farklı bir önkoşuldur.

Uygulama usbmux bağlantısını gerçekten dener. Bağlantının açılamaması “sürücü kesin yok” diye yorumlanmaz: servis kapalı, sürücü eksik veya kurulum bozuk olabilir. Ekran resmî [Apple sorun giderme](https://support.apple.com/108643) sayfasını açar. Kayıt defteri değerlerini değiştirip, sürücü silip, üçüncü taraf driver paketi kurmaz.

iOS 17.4+ USB userspace yolunda uygulamanın yönetici olarak açılması tasarım gereği gerekmez. Eski kernel tunnel tariflerini Windows 18/26 yoluna körlemesine uygulamadık. Windows'ta bunu doğrulayan fiziksel test bu teslimde yapılmadı.

## macOS önkoşulları

Build hedefi `.github/workflows/release.yml` içinde macOS 14 runner; mimari runner'a bağlıdır. Universal2 binary otomatik üretilmez. Normal kullanımda Apple cihaz servisleri işletim sisteminden gelir. Xcode, yasal olarak edinilmiş yerel DDI için bir seçenek olabilir; uygulamanın CLI'si veya kullanıcıya açılan bir terminal değildir. `PreferredRsdTunnel` native remoted yolunu tercih eder ve gerekirse userspace'e düşer.

Kod imzalama, Developer ID ve notarization için gerçek yayıncı hesabı gerekir. Bu depoda sertifika veya uydurma imza yoktur. Public release öncesi hedef mimarilerde doğrulama ve gerçek imza/notarization yapılmalıdır.

## Harita, arama ve veri

OpenStreetMap tile attribution görünürdür; tile'lar en az yedi gün cache'lenir, yalnızca görünür viewport yüklenir, bulk/offline indirme özelliği yoktur. Demo/test modu canlı tile istemez; `docs/demo-preview.png` içindeki grid açıkça temsili demo haritasıdır.

Arama için Photon'un public demo endpoint'i, düşük trafikli geliştirme/MVP kullanımıyla sınırlıdır. Submit başına istek, tek eşzamanlı arama, 1.1 saniye aralık, yedi gün cache, timeout ve sonuç sınırı bulunur. Yüksek kullanıcı sayısında self-hosted veya kapasitesi sözleşmeyle sağlanan sağlayıcıya geçilmelidir; ücretsiz demo sunucusu bir SLA değildir. Nominatim public endpoint'i kullanılmadı. Settings → Advanced üzerinden HTTPS tile ve Photon adresleri değiştirilebilir; yeniden açılışta etkinleşir.

Tercihler, favorites/history, recovery kaydı ve cache kullanıcıya özel FakeGPS uygulama verisi dizinindedir. Demo ayrı alt dizin kullanır. Yeni konum kayıtları disk üzerinde hassas kullanıcı verisidir; sunucuya gönderilmez. Harita sağlayıcısı viewport isteklerini, geocoder ise kullanıcının arama metnini görebilir. Pairing kayıtları upstream/Apple katmanında yönetilir; uygulama bunları loglara veya release paketine kopyalamaz.

## Repository

| Yol | Sorumluluk |
| --- | --- |
| `app/fakegps/backend/device.py` | Gerçek cihaz, tunnel, DDI, DVT adapter. |
| `app/fakegps/backend/mock.py` | Açık demo ve otomatik test backend'i. |
| `app/fakegps/controller.py` | Seri state machine, set/reset/persistence/shutdown. |
| `app/fakegps/frontend/` | Native pencere, native map, asyncio worker köprüsü. |
| `app/fakegps/data/compatibility.json` | Yerel, kanıt düzeyi ayrı uyumluluk verisi. |
| `tests/` | Domain, state machine, gerçek adapter/mock transport ve Qt UI testleri. |
| `packaging/` | PyInstaller spec, Inno Setup, runtime lisans bildirimleri. |
| `scripts/project.py` | Tek komut dev/test/release/portable. |
| `docs/test-plan.md` | Donanım kabul kriterleri ve A–F testleri. |
| `docs/manual-results.csv` | Boş fiziksel test kayıt matrisi. |

## Test stratejisi ve release sınırı

Otomatik testler koordinat matematiğini, state geçişlerini, hata sonrası belirsizliğin korunmasını, persistence'de clear gönderilmemesini, DVT context sırasını, normal reset'i, farklı cihaza yanlışlıkla geçişin engellenmesini, arama cache'ini ve gerçek Qt kontrollerini sınar. Cihaz testleri taklit edilmez: transport fixture'ları **mock** olarak isimlendirilir.

Frozen `--demo --smoke-test` arayüzü açıp kapatır; `--check-backend` gerçek adapter'ın runtime import zincirini cihaz erişimi olmadan yükler. Bunlar fiziksel konum değişikliği kanıtı değildir. Windows/macOS CI YAML'ının depoda bulunması, CI çalışmasının gerçekleştiği anlamına gelmez.

## Lisans ve dağıtım

Proje `GPL-3.0-or-later` olarak sağlanır. İncelenen güncel pymobiledevice3 ve pmd-pytcp metadata'sı da GPL-3.0-or-later'dır. Qt/PySide ve diğer bağımlılıkların kendi koşulları korunur. `scripts/notices.py`, gerçekten kurulu runtime dağıtımlarının lisans dosyalarını paketlemek üzere toplar. Binary dağıtımında karşılık gelen kaynak ve build talimatlarını aynı sürümle birlikte sun; kaynak yayın planı olmadan bunu kapalı kaynak ticari binary diye yeniden etiketleme. Apple driver ve DDI payload'ları kaynak arşivinin veya installer'ın parçası değildir.

## Sonraki sürüm

Öncelik Windows 11 + fiziksel iPhone testleri, exact patch/build matrix ve 24 saatlik persistence ölçümleridir. GPX/speed/looping sonradan `Backend` protokolü üzerinde bir route scheduler olarak eklenebilir. MVP aynı anda bir cihazı yönetir; pure RemotePairing Wi-Fi onboarding, otomatik reconnect/reapply, birden fazla eşzamanlı tunnel, remote compatibility güncellemesi ve imzalı otomatik updater implement edilmemiştir.
